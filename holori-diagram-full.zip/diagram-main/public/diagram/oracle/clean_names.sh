# remove png
rm -f *.png
