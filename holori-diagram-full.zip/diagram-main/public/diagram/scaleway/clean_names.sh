# remove shit
find ./* -type f -iname '.DS_Store' -exec rm {} \;

# remove png
rm -f ./**/**/*.png

# remove -white
rm -f ./**/**/*-white.svg
rm -f ./**/**/*-White.svg

# remove -border
rm -f ./**/**/*-borders.svg
rm -f ./**/**/*-Borders.svg

# move svg out of their folder (which has the same name as the file)
for myfile in ./**/**/*.svg; do
    target=$(echo $myfile | sed -E 's/(.*\/).*\/(.*\.svg)/\1\2/g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done


# remove folder number prefix
for myfolder in ./*/; do
    target=$(echo $myfolder | sed -e 's/[0-9]-//g')
    if [[ "$target" != "$myfolder" ]]
    then
        mv "$myfolder" "$target"
    fi
done

# remove folders
find ./**/* -type d -exec rmdir "{}" ";"
