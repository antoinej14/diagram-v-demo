#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json

# move run folder to this script folder
abspath = os.path.abspath(__file__)
dir_name = os.path.dirname(abspath)
os.chdir(dir_name)

entries = []

for (root, _, files) in os.walk('.'):
    path = 'hetzner' + root.replace('./', '/', 1).replace('/', '.')

    for file in files:
        if not file.endswith('.svg'):
            continue
        entries.append(
            {
                'name': path + file[:-4],  # -4 to remove ".svg"
                'alias': []
            }
        )

print(json.dumps(entries, indent=2))
