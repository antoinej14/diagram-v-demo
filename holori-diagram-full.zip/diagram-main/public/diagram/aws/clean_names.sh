# TODO

# remove ressources as it's too detailled ?
rm -rf ressources

# remove shit
find ./* -type f -iname '.DS_Store' -exec rm {} \;

# merge categories icons as icons for the services
mv categories/*.svg "architecture services"/

rm -rf categories

mv "architecture services"/* ./

rm -rf "architecture services"
