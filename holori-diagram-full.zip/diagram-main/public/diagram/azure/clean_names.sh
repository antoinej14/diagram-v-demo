# remove number prefix and "icon-service"
for myfile in **/*.svg; do
    target=$(echo $myfile | sed -e 's/[0-9]*-icon-service-//g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done
