# remove png
rm -f **/*.png

# move svg out of their folder
for myfile in **/*.svg; do
    target=$(echo $myfile | sed -e 's/.*\///g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done

# remove folders
find ./* -type d -exec rmdir "{}" ";"
