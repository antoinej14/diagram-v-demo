# remove prefix
for myfile in *.svg; do
    target=$(echo $myfile | sed -e 's/digitalocean-product-icon-//g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done
for myfile in ./*/*.svg; do
    target=$(echo $myfile | sed -e 's/digitalocean-product-icon-//g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done

# replace "_-" and "-_" by "-" in file names
for myfile in *.svg; do
    target=$(echo $myfile | sed -e 's/\_-/-/g')
    target=$(echo $target | sed -e 's/-\_/-/g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done
for myfile in ./*/*.svg; do
    target=$(echo $myfile | sed -e 's/\_-/-/g')
    target=$(echo $target | sed -e 's/-\_/-/g')
    if [[ "$target" != "$myfile" ]]
    then
        mv "$myfile" "$target"
    fi
done
