# remove shit
rm -f .DS_Store ._.DS_Store
find ./* -type f -iname '.DS_Store' -exec rm {} \;
find ./* -type f -iname '._.DS_Store' -exec rm {} \;

rm -rf **/Untitled
rm -rf **/Concepts
rm -rf **/Deprecated*
rm -rf **/Old
rm -rf **/**/__MACOSX
rm -rf **/*test.svg

# remove png
rm -f *.png
rm -f **/*.png

# remove tmp
rm -rf **/._*

# remove zip
rm -f **/*.zip

# remove ai
rm -f **/*.ai

# remove pdf
rm -f **/*.pdf

# remove eps
rm -f **/*.eps
