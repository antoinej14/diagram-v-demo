#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json

# move run folder to this script folder
abspath = os.path.abspath(__file__)
dir_name = os.path.dirname(abspath)
os.chdir(dir_name)

map = {}

for (root, folders, files) in os.walk('.'):
    cur = map
    if root != '.':
        for e in root.replace('./', '', 1).split('/'):
            if not e in cur:
                cur[e] = {}
            cur = cur[e]

    cur['name'] = root.replace('./', '', 1).split('/')[-1] if root != '.' else "ovh"
    cur['entries'] = []

    for folder in folders:
        cur[folder] = {}

    for file in files:
        if not file.endswith('.svg'):
            continue
        cur['entries'].append(
            {
                "name": file.replace('.svg', ''),
            }
        )


def rec_entries(entry):
    out = {
        'name': entry['name'],
    }
    if 'entries' in entry:
        out['entries'] = entry['entries']

    keys = entry.keys() - ('name', 'entries')

    if keys and not 'entries' in out:
        out['entries'] = []

    for k in keys:
        out['entries'].append(rec_entries(entry[k]))

    return out

map = rec_entries(map)
map['company'] = map['name']

print(json.dumps(map, indent=2))
