import axios from 'axios'
import axiosRetry from 'axios-retry'
import qs from 'qs'

import { isCancellable } from '@/api/interceptor.js'

/**
 * Controller in which requests are stored or not to be flagged as cancelled
 */
window.abortController = new AbortController()

/**
 * Intance used to perform static file request (without Authorization header)
 */
export const anonymous_instance = axios.create({
  baseURL: '/',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  },
  paramsSerializer: {
    serialize: (params) => qs.stringify(params, { skipNulls: true, indices: false }) // to get: param=value1&param=value2
  }
})

/**
 * Intance used to perform API requests
 */
export const instance = axios.create({
  baseURL: '/',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  },
  paramsSerializer: {
    serialize: (params) => qs.stringify(params, { skipNulls: true, indices: false }) // to get: param=value1&param=value2
  }
})

/**
 * Interceptor that handle the request cancellation
 */
instance.interceptors.request.use((config) => {
  if (isCancellable(config)) {
    const url = axios.getUri(config)

    const abortController = new AbortController()
    window.abortControllers[url] = abortController
    config.signal = abortController.signal
  }
  return config
})

/**
 * Interceptor that handle HTTP status code 202 to initiate the retry
 */
instance.interceptors.response.use(async (response) => {
  const { status, config } = response

  if (status === 202 && !config.skip202) {
    // this request need polling
    const err = new Error('Pending response')
    err.config = config
    err.response = response

    throw err
  }

  return response
})

/**
 * Interceptor that handle resolved requests
 */
instance.interceptors.response.use(async (response) => {
  if (response.status !== 202) {
    // this request is done, remove it from the abortController
    const url = axios.getUri(response.config)
    delete window.abortControllers[url]
  }

  return response
})

/**
 * Handle the HTTP polling when encountering status code 202
 */
axiosRetry(instance, {
  // 120 retries every 500ms, give around 60s of retries
  retries: 120,
  retryDelay: () => 500,
  shouldResetTimeout: true,
  retryCondition(error) {
    const url = axios.getUri(error.config)
    const stillNecessary = url in window.abortControllers
    const isPending = error.message === 'Pending response'
    return stillNecessary && isPending
  }
})

export default instance
