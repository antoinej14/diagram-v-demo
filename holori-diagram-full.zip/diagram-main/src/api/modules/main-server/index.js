const mainServerUrl = 'api/main-server/'

export default mainServerUrl
