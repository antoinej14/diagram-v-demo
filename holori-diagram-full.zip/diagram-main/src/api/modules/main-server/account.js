import { instance } from '@/api'
import mainServerUrl from '@/api/modules/main-server'

export const accountApiUrl = mainServerUrl + 'account'

// this one need to be exported because it is used in the interceptor
export const loginUrl = mainServerUrl + 'token'

export default {
  /**
   * TODO
   *
   * @returns
   */
  renewToken() {
    return instance.get(loginUrl)
  },

  /**
   * TODO
   *
   * @returns
   */
  getDetails() {
    return instance.get(accountApiUrl)
  }
}
