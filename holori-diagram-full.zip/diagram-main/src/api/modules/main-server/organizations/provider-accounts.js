import instance from '@/api'
import { organizationsApiUrl } from '@/api/modules/main-server/organizations/index'

import { COST_TYPES } from '@/common/enums.js'
import { extractFulfilledValues } from '@/common/utils.js'

/**
 * TODO
 *
 * @param {*} parameters
 * @returns
 */
const serializedParameters = (parameters) => {
  const result = {}

  for (const filter in parameters) {
    const value = parameters[filter]

    if (value == null) {
      continue
    }

    result[filter] = typeof value !== 'string' ? JSON.stringify(value) : value
  }

  return result
}

/**
 * TODO
 *
 * @param {*} rules
 * @param {*} call
 * @returns
 */
function handleRequestWithRules(rules, call) {
  if (Array.isArray(rules)) {
    return new Promise((resolve) => {
      const promises = rules.map((rulesEntry) => call(rulesEntry))

      Promise.allSettled(promises).then((results) => {
        const { allData } = extractFulfilledValues(results)

        const flattenData = allData.map(({ data }) => data).flat()

        resolve({ data: flattenData })
      })
    })
  }

  return call(rules)
}

export default {
  /**
   * Get a list of provider accounts in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Object} filters `name`, `provider_name`, `enabled`, `created_since`, `created_until`, `offset`, `limit`
   * @returns {Promise<AxiosResponse>}
   */
  getProviderAccounts(organizationID, filters = {}) {
    return instance.get(organizationsApiUrl + '/' + organizationID + '/provider_accounts', {
      params: filters
    })
  },

  /**
   * Get a provider account in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The provider account ID.
   * @returns {Promise<AxiosResponse>}
   */
  getProviderAccount(organizationID, projectID) {
    return instance.get(
      organizationsApiUrl + '/' + organizationID + '/provider_accounts/' + projectID
    )
  },

  /**
   * Get synchronizations for provider account.
   * @param {Number} organizationID The organization ID.
   * @param {Number} accountID The provider account ID.
   * @param {{ offset: Number, limit: Number}} params Offset/limit.
   * @returns {Promise<AxiosResponse>}
   */
  getSynchronizations(organizationID, accountID, params) {
    return instance.get(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations',
      {
        params: {
          ...params,
          sort_by: 'desc(id)'
        }
      }
    )
  },

  /**
   * Get last synchronization for provider account.
   * @param {Number} organizationID
   * @param {Number} accountID
   * @returns {Promise<AxiosResponse<any>>}
   */
  getLastSynchronization(organizationID, accountID) {
    return instance.get(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations',
      {
        params: {
          limit: 1,
          sort_by: 'desc(id)'
        }
      }
    )
  },

  /**
   * Get a synchronization entry.
   * @param {Number} organizationID
   * @param {Number} accountID
   * @param {Number} synchronizationID
   * @returns {Promise<AxiosResponse<any>>}
   */
  getSynchronization(organizationID, accountID, synchronizationID) {
    return instance.get(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations/' +
        synchronizationID
    )
  },

  /**
   * Get the diagram for a synchronization.
   * @param {Number} organizationID
   * @param {Number} accountID
   * @param {Number} synchronizationID
   * @returns {Promise<AxiosResponse<any>>}
   */
  getSynchronizationDiagram(organizationID, accountID, synchronizationID) {
    return instance.get(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations/' +
        synchronizationID +
        '/diagram'
    )
  },

  /**
   * Get the thumbnail for a synchronization.
   * @param {Number} organizationID
   * @param {Number} accountID
   * @param {Number} synchronizationID
   * @returns {Promise<AxiosResponse<any>>}
   */
  getSynchronizationThumbnail(organizationID, accountID, synchronizationID) {
    return instance.get(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations/' +
        synchronizationID +
        '/thumbnail'
    )
  },

  /**
   * Edit a synchronization.
   * @param {Number} organizationID
   * @param {Number} accountID
   * @param {Number} synchronizationID
   * @param {{ thumbnail: String, diagram: String }} payload
   * @returns {Promise<AxiosResponse<any>>}
   */
  editSynchronization(organizationID, accountID, synchronizationID, payload) {
    return instance.put(
      organizationsApiUrl +
        '/' +
        organizationID +
        '/provider_accounts/' +
        accountID +
        '/synchronizations/' +
        synchronizationID,
      payload
    )
  },

  /**
   * Get cost
   * @param {Number} organizationID The organization ID.
   * @param {Number} accountID The provider account ID.
   * @param {Object} parameters `granularity`, `filters`, `group_by`, `start_date`, `end_date`, `cost_type`
   * @param {Object} filterRules TODO
   * @returns {Promise<AxiosResponse>}
   */
  getCost(organizationID, accountID, parameters, filterRules) {
    const requestParameters = serializedParameters(parameters)

    if (!requestParameters.cost_type) {
      requestParameters.cost_type = COST_TYPES.UNBLENDED
    }

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        organizationsApiUrl +
          '/' +
          organizationID +
          '/provider_accounts/' +
          accountID +
          '/costs' +
          (requestParameters.granularity ? '/granular' : ''),
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  },

  /**
   * Get usage
   * @param {Number} organizationID The organization ID.
   * @param {Number} accountID The provider account ID.
   * @param {Object} parameters `granularity`, `filters`, `group_by`, `start_date`, `end_date`
   * @param {Object} filterRules TODO
   * @returns {Promise<AxiosResponse>}
   */
  getUsage(organizationID, accountID, parameters, filterRules) {
    const requestParameters = serializedParameters(parameters)

    delete requestParameters.group_by
    delete requestParameters.cost_type

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        organizationsApiUrl +
          '/' +
          organizationID +
          '/provider_accounts/' +
          accountID +
          '/usages' +
          (requestParameters.granularity ? '/granular' : ''),
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  },

  /**
   * TODO
   *
   * @param {*} organizationID
   * @param {*} accountID
   * @param {*} dimension
   * @param {*} parameters
   * @param {*} filterRules
   * @returns
   */
  getDimension(organizationID, accountID, dimension, parameters, filterRules) {
    const url =
      organizationsApiUrl +
      '/' +
      organizationID +
      '/provider_accounts/' +
      accountID +
      '/dimensions/' +
      dimension

    const requestParameters = serializedParameters(parameters)

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        url,
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  },

  /**
   * TODO
   *
   * @param {*} organizationID
   * @param {*} accountID
   * @param {*} dimension
   * @param {*} groupBy
   * @param {*} parameters
   * @param {*} filterRules
   * @returns
   */
  getDimensionCount(organizationID, accountID, dimension, groupBy, parameters, filterRules) {
    const url =
      organizationsApiUrl +
      '/' +
      organizationID +
      '/provider_accounts/' +
      accountID +
      '/dimensions/' +
      dimension +
      '/count' +
      (groupBy != null ? '/' + groupBy : '')

    const requestParameters = serializedParameters(parameters)

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        url,
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  },

  /**
   * Get commitment discounts
   * @param {Number} organizationID The organization ID.
   * @param {Number} accountID The provider account ID.
   * @param {Object} parameters `granularity`, `filters`, `group_by`, `start_date`, `end_date`
   * @param {Object} filterRules TODO
   * @returns {Promise<AxiosResponse>}
   */
  getCommitmentDiscounts(organizationID, accountID, parameters, filterRules) {
    const requestParameters = serializedParameters(parameters)

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        organizationsApiUrl +
          '/' +
          organizationID +
          '/provider_accounts/' +
          accountID +
          '/discounts' +
          (requestParameters.granularity ? '/granular' : ''),
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  },

  /**
   * Get reservations
   * @param {Number} organizationID The organization ID.
   * @param {Number} accountID The provider account ID.
   * @param {Object} parameters `granularity`, `filters`, `start_date`, `end_date`
   * @param {Object} filterRules TODO
   * @returns {Promise<AxiosResponse>}
   */
  getReservations(organizationID, accountID, parameters, filterRules) {
    const requestParameters = serializedParameters(parameters)

    return handleRequestWithRules(filterRules, (rulesEntry) =>
      instance.post(
        organizationsApiUrl +
          '/' +
          organizationID +
          '/provider_accounts/' +
          accountID +
          '/reservations' +
          (requestParameters.granularity ? '/granular' : ''),
        rulesEntry
          ? {
              name: '',
              rules: rulesEntry
            }
          : null,
        {
          params: requestParameters
        }
      )
    )
  }
}
