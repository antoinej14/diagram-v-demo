import instance from '@/api'
import mainServerUrl from '@/api/modules/main-server'

export const organizationsApiUrl = mainServerUrl + 'organizations'

export default {
  /**
   * Get a list of organizations.
   * @param {Number|undefined} offset Minimum 0.
   * @param {Number|undefined} limit Minimum 1 Maximum 100.
   * @param {Object} filters `name`, `created_since`, `created_until`.
   * @returns {Promise<AxiosResponse>}
   */
  getPage(offset, limit, filters) {
    return instance.get(organizationsApiUrl, {
      params: {
        ...filters,
        offset,
        limit
      }
    })
  },

  /**
   * Get details of an organization.
   * @param {Number} organizationID The organization ID.
   * @returns {Promise<AxiosResponse>}
   */
  get(organizationID) {
    return instance.get(organizationsApiUrl + '/' + organizationID)
  }
}
