import instance from '@/api'
import { organizationsApiUrl } from '.'

export default {
  /**
   * Get a list of projects in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Number} offset
   * @param {Number} limit
   * @param {Object} filters
   * @returns {Promise<AxiosResponse>}
   */
  getProjects(organizationID, offset, limit, filters) {
    return instance.get(organizationsApiUrl + '/' + organizationID + '/projects', {
      params: {
        ...filters,
        offset,
        limit
      }
    })
  },

  /**
   * Create a new project in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Object} data `diagram`, `thumbnail`, `name`, `notes`
   * @returns {Promise<AxiosResponse>}
   */
  createProject(organizationID, data) {
    return instance.post(organizationsApiUrl + '/' + organizationID + '/projects', data)
  },

  /**
   * Get a project in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @returns {Promise<AxiosResponse>}
   */
  getProject(organizationID, projectID) {
    return instance.get(organizationsApiUrl + '/' + organizationID + '/projects/' + projectID)
  },

  /**
   * Edit a project in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @param {Object} data `diagram`, `thumbnail`, `name`, `notes`
   * @returns {Promise<AxiosResponse>}
   */
  editProject(organizationID, projectID, data) {
    return instance.put(organizationsApiUrl + '/' + organizationID + '/projects/' + projectID, data)
  },

  /**
   * Delete a project in this organization.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @returns {Promise<AxiosResponse>}
   */
  deleteProject(organizationID, projectID) {
    return instance.delete(organizationsApiUrl + '/' + organizationID + '/projects/' + projectID)
  },

  /**
   * Get the project thumbnail.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @returns {Promise<AxiosResponse>}
   */
  getProjectThumbnail(organizationID, projectID) {
    return instance.get(
      organizationsApiUrl + '/' + organizationID + '/projects/' + projectID + '/thumbnail'
    )
  },

  /**
   * Get the project diagram.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @returns {Promise<AxiosResponse>}
   */
  getProjectDiagram(organizationID, projectID) {
    return instance.get(
      organizationsApiUrl + '/' + organizationID + '/projects/' + projectID + '/diagram'
    )
  },

  /**
   * Get the project history.
   * @param {Number} organizationID The organization ID.
   * @param {Number} projectID The project ID.
   * @param {Object} filters `offset`, `limit`.
   * @returns {Promise<AxiosResponse>}
   */
  getProjectHistory(organizationID, projectID, filters) {
    return instance.get(
      organizationsApiUrl + '/' + organizationID + '/projects/' + projectID + '/history',
      {
        params: {
          sort_by: 'desc(date)',
          ...filters
        }
      }
    )
  }
}
