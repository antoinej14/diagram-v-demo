import axios from 'axios'

/**
 * Read-only access to the Scaleway VM pricing catalog crawled and maintained by
 * the cloud-price-crawl project. The `vm_pricing` table is exposed publicly
 * (RLS policy allows anonymous SELECT) through Supabase's PostgREST API, so no
 * dedicated backend endpoint is needed on our side.
 */
const SUPABASE_URL = import.meta.env.VITE_SCALEWAY_PRICING_SUPABASE_URL
const SUPABASE_ANON_KEY = import.meta.env.VITE_SCALEWAY_PRICING_SUPABASE_ANON_KEY

const instance = axios.create({
  baseURL: `${SUPABASE_URL}/rest/v1/`,
  timeout: 15000,
  headers: {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`
  }
})

let pricingPromise = null

/**
 * Fetch the full Scaleway instance pricing catalog (all instance types, regions
 * and operating systems). The result is cached for the lifetime of the page
 * since the catalog is small and changes infrequently.
 * @returns {Promise<Array>}
 */
function getScalewayInstancePricing() {
  if (!pricingPromise) {
    pricingPromise = instance
      .get('vm_pricing', {
        params: {
          provider: 'eq.scaleway',
          select:
            'instance_type,region,vcpu,memory,operating_system,hourly_price_usd,monthly_price_usd,last_updated',
          order: 'instance_type.asc',
          limit: 5000
        }
      })
      .then(({ data }) => data)
      .catch((error) => {
        pricingPromise = null
        throw error
      })
  }
  return pricingPromise
}

export default {
  getScalewayInstancePricing
}
