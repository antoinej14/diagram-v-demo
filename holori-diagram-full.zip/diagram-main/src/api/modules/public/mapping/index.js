import { anonymous_instance } from '@/api'

export const mappingUrl = 'diagram/mapping/'

export default {
  get(path) {
    return anonymous_instance.get(mappingUrl + path)
  },

  getPublic(path, options = {}) {
    return anonymous_instance.get(`/${path}`, options)
  }
}
