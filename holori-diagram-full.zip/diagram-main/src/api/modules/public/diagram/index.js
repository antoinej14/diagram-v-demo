import { anonymous_instance } from '@/api'

export const diagramUrl = 'diagram/diagram/'

export default {
  get(path) {
    return anonymous_instance.get(diagramUrl + path)
  }
}
