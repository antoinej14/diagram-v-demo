import axios from 'axios'

import axiosInstance from '@/api'
import accountApi from '@/api/modules/main-server/account'

import EventBus from '@/common/eventBus'

import { useAccountStore } from '@/store/account'
import { useOrganizationStore } from '@/store/organization'

/**
 * URLs that should not be cancelled
 */
const doNotCancel = [/providers\.json$/, /organizations\/[0-9]+\/members\/[0-9]+$/]

/**
 * Checks if an axios request is cancellable.
 * @param {axios.InternalAxiosRequestConfig} config
 * @returns {Boolean}
 */
export const isCancellable = (config) => {
  const { url } = config

  for (const pattern of doNotCancel) {
    if (url.match(pattern)) {
      return false
    }
  }

  return true
}

/**
 * Interceptor that handle Authorization, tokens and logout
 */
export const setupInterceptor = () => {
  const accountStore = useAccountStore()

  /**
   *
   */
  axiosInstance.interceptors.request.use(
    (config) => {
      const accessToken = accountStore.getAccessToken
      if (accessToken) {
        // inject the token in request headers
        config.headers.Authorization = `Bearer ${accessToken}`
      }

      if (isCancellable(config)) {
        const url = axios.getUri(config)
        const abortController = new AbortController()
        config.signal = abortController.signal
        window.abortControllers[url] = abortController
      }

      return config
    },
    (error) => Promise.reject(error)
  )

  // ensure we have an Authentication header (access token)
  axiosInstance.interceptors.response.use(
    (result) => {
      return result
    },
    (error) => {
      // request got cancelled
      if (axios.isCancel(error)) {
        return Promise.reject(error)
      }

      // error because we are missing the Authentication header
      //   or it is there but the token is invalid

      // remember the initial request configuration then the error ocurred
      const originalConfig = error.config || {}

      // trying to refresh token if possible as the Access Token was maybe expired

      // set a flag to not loop infinitely, only attempt once
      originalConfig._retry = true

      if (error?.response == null) {
        // not an API error
        //   the network, the browser or something else may have rejected the request
        return Promise.reject(error)
      }

      if (error.response.status !== 401) {
        // not an API authentication error
        //   but maybe some permission missing or some bug in the API
        return Promise.reject(error)
      }

      if (originalConfig.url === accountApi.loginUrl) {
        // error during a login or a token refresh attempt
        //   send the "logout" event through the entire app
        EventBus.dispatch('logout')
        return Promise.reject(error)
      }

      if (originalConfig._retry) {
        // an attempt to refresh the token was already made and failed.
        //   so from there, we know we are not logged in anymore
        return Promise.reject(error)
      }

      accountStore.renewToken().then(
        () => {
          // continue and retry now that we got a fresh token
          return Promise.resolve(axiosInstance(originalConfig))
        },
        (refreshError) => {
          // user might have been disconnected
          //   send the "logout" event through the entire app
          EventBus.dispatch('logout')
          return Promise.reject(refreshError)
        }
      )
    }
  )
}

/**
 * Load the current user
 * @returns
 */
export const setupCurrentUser = async () => {
  const accountStore = useAccountStore()
  const organizationStore = useOrganizationStore()

  // load expected current user if any
  await accountStore.setup()

  if (!accountStore.isLoggedIn) {
    // no user or not authenticated anymore
    console.log('user is not logged in')
    return
  }

  if (import.meta.env.PROD && location.hostname === 'app.holori.com') {
    await import('crisp-sdk-web').then(({ Crisp }) => {
      Crisp.user.setEmail(accountStore.account.email)
      Crisp.user.setNickname(accountStore.account.name)
    })
  }

  // load other relative data about the user
  await organizationStore.getOrganizations()
}
