<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { storeToRefs } from 'pinia'
import { ODropdown, OIcon, OLoading, OTooltip, useOruga } from '@oruga-ui/oruga-next'

import projectsApi from '@/api/modules/main-server/organizations/projects.js'

import { useMixins } from '@/common/mixins'
import EventBus from '@/common/eventBus'
import { useOrganizationMembership } from '@/common/organization-membership.js'

import { useProjectStore } from '@/store/project'

import ConfirmationModal from '@/components/modal/Confirmation.vue'

const emit = defineEmits(['click', 'delete'])

const oruga = useOruga()
const { toast, navigate } = useMixins()

const props = defineProps({
  project: {
    type: Object,
    required: true
  },
  hideFooter: {
    type: Boolean,
    required: false,
    default: false
  },
  noTitle: {
    type: Boolean,
    required: false,
    default: false
  },
  selected: {
    type: Boolean,
    required: false,
    default: false
  },
  openOnClick: {
    type: Boolean,
    required: false,
    default: true
  },
  template: {
    type: Boolean,
    required: false,
    default: false
  }
})

const { organizationID } = useOrganizationMembership(false)

const refreshImportingTimeout = ref(null)
const thumbnailLoading = ref(true)
const thumbnail = ref(null)

const cardRef = ref(null)
const dropdownTriggerRef = ref(null)

const projectStore = useProjectStore()

const { comparingProjectID } = storeToRefs(projectStore)

const isSelected = computed(
  () => props.selected || (props.project.id && props.project.id === comparingProjectID.value)
)
const isDeleted = computed(() => props.project?.deleted)
const isImporting = computed(() => props.project?.importing && !isDeleted.value)
const isImported = computed(() => props.project?.imported)

watch(isImporting, (newV) => {
  if (newV === false && refreshImportingTimeout.value) {
    clearInterval(refreshImportingTimeout.value)
  }
})

onMounted(() => {
  if (isImporting.value) {
    // refresh project from time to time
    refreshImportingTimeout.value = setInterval(() => {
      projectStore.refreshProject(props.project.id).catch(
        ({
          response: {
            data: { detail }
          }
        }) => {
          toast({
            message: `Error while importing project.<br>${detail}`,
            variant: 'danger'
          })
          clearInterval(refreshImportingTimeout.value)
        }
      )
    }, 5000)
  }
})

onBeforeUnmount(() => {
  if (refreshImportingTimeout.value) {
    clearInterval(refreshImportingTimeout.value)
  }
})

function onClick(e) {
  if (!props.openOnClick) {
    e.preventDefault()

    emit('click', props.project.id)
  }
}

async function confirmDeleteProject() {
  const { name, deleted } = props.project
  const message = deleted
    ? `The project "${name}" will be deleted for good.`
    : `The project "${name}" will be moved to your bin.`

  const instance = oruga.modal.open({
    component: ConfirmationModal,
    props: {
      title: 'Deleting project',
      message,
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Delete',
      yesIcon: 'delete',
      invertColors: true
    },
    trapFocus: true
  })
  const result = await instance.promise
  if (result === true) {
    deleteProject()
  }
}

function deleteProject() {
  projectStore.deleteProject(organizationID, props.project.id).then(
    () => {
      emit('delete', props.project.name)
    },
    () => {
      toast({
        message: `Project "${props.project.name}" can not be deleted`,
        variant: 'danger'
      })
    }
  )
}

function restoreProject() {
  projectStore.restore(props.project.id).then(
    () => {},
    () => {
      toast({
        message: `Project "${props.project.name}" can not be restored`,
        variant: 'danger'
      })
    }
  )
}

function duplicateProject() {
  EventBus.dispatch('startGlobalLoading')

  projectsApi
    .getProject(organizationID, props.project.id)
    .then(async ({ data }) => {
      const { name } = data

      const { data: thumbnailData } = await projectsApi.getProjectThumbnail(
        organizationID,
        props.project.id
      )

      const { data: diagramData } = await projectsApi.getProjectDiagram(
        organizationID,
        props.project.id
      )

      const newProject = {
        ...data,
        name: `${name} - copy`,
        thumbnail: thumbnailData.thumbnail,
        diagram: diagramData.diagram
      }

      const { data: newProjectData } = await projectsApi.createProject(organizationID, newProject)

      // go directly to project page
      navigate('ProjectDesign', {
        params: {
          id: newProjectData.id
        }
      })

      EventBus.dispatch('stopGlobalLoading')
    })
    .catch((err) => {
      // TODO toast the error ?

      console.error(err)

      EventBus.dispatch('stopGlobalLoading')
    })
}

function contextMenu() {
  const { dropdownTrigger } = this.$refs
  if (dropdownTrigger) {
    dropdownTrigger.$el.click()
  }
}

function stopComparing(e) {
  if (e.key === 'Escape') {
    projectStore.setComparingProjectID(null)
    window.removeEventListener('mouseup', stopComparing)
  }
}

function startComparing() {
  projectStore.setComparingProjectID(props.project.id)
  window.addEventListener('keydown', stopComparing)
  toast({
    variant: 'info',
    message: 'Press Escape to stop project selection for comparison.'
  })
}

// We got a project ID, no thumbnail (it's not a template)
if (props.project.id && !props.project.thumbnail) {
  projectStore
    .getProjectThumbnail(props.project.organization_id, props.project.id)
    .then(({ data }) => {
      thumbnail.value = data.thumbnail
      thumbnailLoading.value = false
    })
} else {
  // Not necessary to make them wait longer.
  thumbnailLoading.value = false

  // Set the thumbnail if available
  thumbnail.value = props.project.thumbnail || null
}
</script>

<template>
  <router-link
    ref="cardRef"
    :to="{ name: 'ProjectDesign', params: { id: props.project.id } }"
    @contextmenu.prevent="contextMenu"
    v-slot="{ href }"
  >
    <a
      :href="href"
      class="card is-flex is-flex-direction-column is-border-radius-xl is-clickable"
      :class="{ 'card--selected': isSelected }"
      :title="!noTitle && project.name"
      @click="onClick"
    >
      <div
        class="card-header is-flex is-align-items-center is-justify-content-center px-4 py-2 has-text-weight-medium is-size-6"
        :class="{ 'card-header--selected': isSelected }"
      >
        <img
          v-if="props.template"
          :src="`/diagram/${project.provider}.svg`"
          :alt="project.provider"
          width="30"
          height="30"
          class="pr-2"
        />
        <span class="ellipsis">{{ project.name }}</span>
      </div>
      <div class="card-content p-1 is-flex-grow-1 is-clipped is-relative" role="link">
        <div
          class="card-content-preview full-height is-flex is-flex-grow-1 is-justify-content-center is-align-items-center is-clipped"
        >
          <img v-if="thumbnail" class="thumbnail" :src="thumbnail" alt="" width="200" />
          <img v-else :src="`/diagram/unknown.svg`" alt="Holori icon" width="100" />
        </div>
        <div v-if="!props.template" class="project-icons">
          <o-icon v-if="isImported" icon="cloud-download" title="Imported" class="pr-2" />
        </div>
        <o-loading :active="isImporting || thumbnailLoading" :full-page="false" />
      </div>
      <footer v-if="!props.hideFooter" class="card-footer">
        <o-tooltip label="Duplicate this project" class="card-footer-item p-2 footer-action">
          <div class="is-flex is-justify-content-center" @click.prevent="duplicateProject">
            <o-icon icon="content-copy" />
          </div>
        </o-tooltip>
        <div
          class="card-footer-item dropdown p-0 footer-action"
          title="More actions"
          aria-controls="dropdown-menu"
          @click.prevent
        >
          <o-dropdown
            aria-role="list"
            menu-class="project-card-dropdown"
            class="is-flex-grow-1 is-justify-content-center full-height"
            trigger-class="is-flex-grow-1 is-inline-flex is-justify-content-center p-2"
            teleport
          >
            <template #trigger>
              <o-icon ref="dropdownTriggerRef" icon="dots-horizontal" role="button" />
            </template>

            <o-dropdown-item
              aria-role="listitem"
              class="is-flex is-align-items-center"
              title="Compare this project to another project"
              @click="startComparing"
            >
              <o-icon icon="compare" class="mr-2" />
              Compare to another project
            </o-dropdown-item>

            <o-dropdown-item
              aria-role="listitem"
              class="is-flex has-text-danger is-align-items-center"
              title="Delete this project"
              @click="confirmDeleteProject"
            >
              <o-icon icon="delete" class="mr-2" />
              Delete
            </o-dropdown-item>

            <o-dropdown-item
              v-if="isDeleted"
              aria-role="listitem"
              class="is-flex is-align-items-center"
              title="Restore this project"
              :disabled="isImporting"
              @click="restoreProject"
            >
              <o-icon icon="delete-restore" class="mr-2" />
              Restore Project
            </o-dropdown-item>
          </o-dropdown>
        </div>
      </footer>
    </a>
  </router-link>
</template>

<style scoped>
.card {
  width: 260px;
  max-width: 260px;
  min-width: 260px;

  height: 260px;
  min-height: 260px;
  max-height: 260px;

  border: 1px solid var(--secondary-light-lightgray2);
}
.card--selected {
  background-color: var(--primary);
  border-color: transparent;
}
.card--selected :deep(.card-footer) {
  border-top-color: transparent;
}
.card--selected :deep(.card-footer-item:not(:last-child)) {
  border-right-color: transparent;
}
:deep(.card-header) {
  border-bottom: 1px solid var(--secondary-light-lightgray2);
  box-shadow: none;
  flex: 0 0 40px;
}
:deep(.card-header--selected) {
  border-bottom-color: var(--primary);
  color: #fff;
}
.project-icons {
  position: absolute;
  bottom: 5px;
  right: 5px;
  opacity: 0.5;
}
.thumbnail {
  flex: 0;
  max-height: 100%;
}
.footer-action {
  color: var(--primary);
  transition:
    background-color 0.2s ease,
    color 0.2s ease;
}
.card--selected .footer-action {
  color: #fff;
}
.footer-action:first-child {
  border-bottom-left-radius: 20px;
}
.footer-action:last-child {
  border-bottom-right-radius: 20px;
}
.footer-action[disabled] {
  opacity: 0.5;
  pointer-events: none;
}
.footer-action:not([disabled]):hover {
  background-color: var(--primary);
  color: #fff;
}
:deep(.project-card-dropdown) {
  z-index: 30;
  position: fixed;
  transform: translateX(-100%);
}
</style>
