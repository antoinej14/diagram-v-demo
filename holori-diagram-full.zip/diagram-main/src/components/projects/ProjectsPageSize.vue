<script setup>
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { OButton, OField, OSelect } from '@oruga-ui/oruga-next'

import { debounce } from '@/common/utils'
import { useMixins } from '@/common/mixins'
import { useOrganizationMembership } from '@/common/organization-membership'

import { useProjectStore } from '@/store/project'

const { organizationID } = useOrganizationMembership(false)
const { updateQuery } = useMixins()

const route = useRoute()

const pageSizes = [10, 20, 50]

const projectStore = useProjectStore()

if (route.query.size) {
  projectStore.setPageSize(+route.query.size)
}

const pageSize = ref(projectStore.pagination.limit)

const updatePageSize = debounce((newPageSize) => {
  projectStore.setPageSize(newPageSize)
  updateQuery({ size: newPageSize }).then(() => projectStore.getProjects(organizationID))
}, 500)

watch(pageSize, updatePageSize)
</script>

<template>
  <o-field class="ml-4 mb-0">
    <o-button variant="secondary" class="is-pointer-events-none" rounded>
      Results per page
    </o-button>
    <o-select v-model="pageSize" expanded rounded>
      <option v-for="option in pageSizes" :key="option" :value="option">
        {{ option }}
      </option>
    </o-select>
  </o-field>
</template>
