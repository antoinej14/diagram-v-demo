<script setup>
import { computed, onBeforeUnmount } from 'vue'
import { storeToRefs } from 'pinia'
import { OIcon, OLoading, ONotification, OTooltip } from '@oruga-ui/oruga-next'

import { useMixins } from '@/common/mixins'

import { useProjectStore } from '@/store/project'

import ProjectCard from '@/components/ProjectCard.vue'

const emit = defineEmits(['delete'])

const { navigate, toast } = useMixins()

const projectStore = useProjectStore()

const { projects, pagination, filters, comparingProjectID, loading } = storeToRefs(projectStore)

const noProject = computed(() => pagination.value.total === 0)

onBeforeUnmount(() => projectStore.setProjects([]))

function projectCardClick(e) {
  if (e !== comparingProjectID.value) {
    navigate('ProjectCompare', {
      params: {
        left: comparingProjectID.value,
        right: e
      }
    })
    projectStore.setComparingProjectID(null)

    toast({
      variant: 'info',
      message: 'Comparing two projects…'
    })
  }
}
</script>

<template>
  <section
    class="is-flex is-flex-wrap-wrap is-gap-5 pb-5 px-5"
    :class="{ 'is-align-items-center is-justify-content-center': noProject }"
  >
    <o-tooltip label="Create a new project" position="right">
      <router-link
        id="new-project-button"
        class="has-background-white import-card is-flex is-flex-direction-column is-align-items-center is-justify-content-center is-border-radius-xl is-clickable is-flex-1 project-type"
        role="button"
        :to="{ name: 'NewProject' }"
      >
        <o-icon icon="plus-thick" />
        New project
      </router-link>
    </o-tooltip>
    <ProjectCard
      v-for="project in projects"
      :key="project.id"
      :project="project"
      :open-on-click="!comparingProjectID"
      @click="projectCardClick"
      @delete="emit('delete', $event)"
    />
    <slot v-if="noProject && !loading" name="empty">
      <o-notification
        type="info"
        variant="info"
        class="is-align-self-center"
        content-class="is-align-self-center"
      >
        <template v-if="!filters.name">
          No projects here,
          <router-link :to="{ name: 'NewProject' }">create one</router-link>
        </template>
        <template v-else>
          No results found! Please verify what you are looking for and please try another way.
        </template>
      </o-notification>
    </slot>
    <o-loading :active="loading" icon-size="large" full-page />
  </section>
</template>

<style scoped>
.import-card {
  color: var(--text-color);

  width: 260px;
  max-width: 260px;
  min-width: 260px;

  height: 260px;
  min-height: 260px;
  max-height: 260px;

  border: 1px solid var(--secondary-light-lightgray2);
}
</style>
