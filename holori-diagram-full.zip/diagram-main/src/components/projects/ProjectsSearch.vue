<script setup>
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import { OButton, ODropdown, OField, OIcon, OInput } from '@oruga-ui/oruga-next'

import { debounce } from '@/common/utils'
import { useOrganizationMembership } from '@/common/organization-membership'
import { useMixins } from '@/common/mixins'

import { useProjectStore } from '@/store/project'

const route = useRoute()
const { organizationID } = useOrganizationMembership(false)
const { updateQuery } = useMixins()

const sortBys = {
  'desc(last_modified)': {
    label: 'Activity date (desc)',
    icon: 'sort-clock-descending'
  },
  'asc(last_modified)': {
    label: 'Activity date (asc)',
    icon: 'sort-clock-ascending'
  },
  'desc(imported)': {
    label: 'Import date (desc)',
    icon: 'sort-calendar-descending'
  },
  'asc(imported)': {
    label: 'Import date (asc)',
    icon: 'sort-calendar-ascending'
  }
}

const searchItem = ref(route.query.name || '')

const projectStore = useProjectStore()

const { filters, pagination } = storeToRefs(projectStore)

const sortBy = ref(pagination.value.sortBy)

const search = debounce(function (value) {
  const searchQuery = value.trim()

  projectStore.setFilters({
    ...filters.value,
    name: searchQuery
  })

  updateQuery({ search: searchQuery }).then(() => projectStore.getProjects(organizationID))
}, 300)

watch(searchItem, search)

watch(sortBy, (newSortBy) => {
  projectStore.setSortBy(newSortBy)
  projectStore.getProjects(organizationID)
})
</script>

<template>
  <o-field class="mb-0 is-flex-grow-1">
    <o-input
      v-model="searchItem"
      placeholder="Search projects"
      type="search"
      icon="magnify"
      rounded
      clearable
      expanded
    />
    <o-dropdown v-model="sortBy" scrollable aria-role="list" position="bottom-left">
      <template #trigger="{ active }">
        <o-button
          variant="primary"
          :icon-left="sortBys[sortBy].icon"
          :icon-right="active ? 'chevron-up' : 'chevron-down'"
          :title="`Sort by ${sortBys[sortBy].label}`"
          rounded
        >
          {{ sortBys[sortBy].label }}
        </o-button>
      </template>
      <o-dropdown-item
        v-for="(opt, value) in sortBys"
        :key="value"
        :value="value"
        aria-role="listitem"
        class="is-flex is-align-items-center"
      >
        <o-icon :icon="opt.icon" class="mr-2" />
        {{ opt.label }}
      </o-dropdown-item>
    </o-dropdown>
  </o-field>
</template>
