<script setup>
import { useRoute } from 'vue-router'
import { OPagination } from '@oruga-ui/oruga-next'
import { storeToRefs } from 'pinia'

import { useMixins } from '@/common/mixins'
import { debounce } from '@/common/utils'
import { useOrganizationMembership } from '@/common/organization-membership'

import { useProjectStore } from '@/store/project'

const route = useRoute()

const { organizationID } = useOrganizationMembership(false)
const { updateQuery } = useMixins()

const projectStore = useProjectStore()

if (route.query.page) {
  projectStore.changePage(+route.query.page)
}

const { projects, pagination } = storeToRefs(projectStore)

const updateCurrentPage = debounce(function (page) {
  if (page !== pagination.value.current) {
    projectStore.changePage(page)
    updateQuery({ page }).then(() => {
      projectStore.getProjects(organizationID)
    })
  }
}, 500)
</script>

<template>
  <div class="mt-auto p-5 has-background-white">
    <o-pagination
      variant="primary"
      :disabled="pagination.total < 1 && !projects"
      :total="pagination.total"
      :current="pagination.current"
      :range-before="2"
      :range-after="2"
      :order="'centered'"
      :per-page="pagination.limit"
      :icon-prev="'arrow-left'"
      :icon-next="'arrow-right'"
      aria-next-label="Next page"
      aria-previous-label="Previous page"
      aria-page-label="Page"
      aria-current-label="Current page"
      @change="updateCurrentPage"
    />
  </div>
</template>

<style scoped>
.pagination {
  background-color: #fffdfd;
  margin-top: auto;
}

.results-per-page {
  order: 0;
}
</style>
