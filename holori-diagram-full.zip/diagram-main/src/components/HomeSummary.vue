<script setup>
import { OButton, OCarousel, OCarouselItem } from '@oruga-ui/oruga-next'
</script>

<template>
  <div
    class="summary has-text-white p-5 is-flex is-flex-direction-column is-justify-content-center is-flex-1"
  >
    <o-button
      class="compare-button is-block ml-auto"
      variant="primary"
      size="large"
      tag="a"
      href="https://calculator.holori.com"
      target="_blank"
    >
      Go to calculator
    </o-button>
    <o-carousel items-class="carousel-height" autoplay pause-hover repeat :interval="5000">
      <o-carousel-item
        class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center"
      >
        <span class="is-size-3 mb-5 has-text-centered has-text-weight-bold">
          Visualize and monitor your
          <br />
          cloud infrastructure
        </span>

        <div
          class="carousel-image"
          title="Visualize and manage your cloud costs"
          style="background-image: url(/login-carousel/slide1.png)"
        />
      </o-carousel-item>
      <o-carousel-item
        class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center"
      >
        <span class="is-size-3 mb-5 has-text-centered has-text-weight-bold">
          Visualize and manage your
          <br />
          cloud costs
        </span>

        <div
          class="carousel-image"
          title="Visualize and monitor your cloud infrastructure"
          style="background-image: url(/login-carousel/slide2.png)"
        />
      </o-carousel-item>
    </o-carousel>
  </div>
</template>

<style scoped>
.summary {
  background: linear-gradient(261.15deg, #3333ea 0%, #7e4bed 100%);
  height: 100vh;
  max-width: 50vw;
}
.compare-button {
  background: var(--secondary-button-color) !important;
  color: var(--secondary-text-color) !important;
}

.compare-button:hover {
  background: var(--secondary-button-hover-color) !important;
}

:deep(.carousel-height) {
  height: calc(100vh - 5rem);
}

.summary :deep(.carousel-arrow) {
  background: #fff !important;
  border: 1px solid var(--primary) !important;
  color: var(--primary) !important;
  height: 2.5rem !important;
  width: 2.5rem !important;
}

.summary :deep(.carousel-arrow:hover) {
  background: var(--primary) !important;
  color: #fff !important;
}

.summary :deep(.indicator-style) {
  border: none !important;
  height: 1rem !important;
  width: 1rem !important;
}

.summary :deep(.indicator-style.is-active) {
  background-color: #f817e2 !important;
}

.summary :deep(.indicator-style:not(.is-active):hover) {
  background: var(--primary);
}
.carousel-image {
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
  flex: 1;
  max-height: 50vh;
  width: 100%;
}
@media screen and (max-width: 1024px) {
  .summary {
    display: none !important;
  }
}
</style>
