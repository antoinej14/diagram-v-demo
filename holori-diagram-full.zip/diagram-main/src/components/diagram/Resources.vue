<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import { OIcon, OInput, OSwitch, OTooltip, useOruga } from '@oruga-ui/oruga-next'

import EventBus from '@/common/eventBus'
import { filterNoise, performLayout } from '@/common/diagram/options/methods/layout.js'
import exportData from '@/common/diagram/options/methods/export.js'
import { useZoom } from '@/components/diagram/hooks/zoom.js'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import ScrollToTop from '@/components/ScrollToTop.vue'
import { useTagsViews } from '@/components/diagram/hooks/tags-view.js'

defineOptions({
  name: 'DiagramResources'
})

const route = useRoute()
const oruga = useOruga()

const search = ref('')
const expandResults = ref(true)
const showTags = ref(false)
const loaded = ref(false)

const resources = ref({})
const regions = ref({})

const openTagsKeys = ref([])
const selectedTagKeyValue = ref({ key: '', value: '' })

const { initTags, keysValues, resourcesTags, displayTags, hideTags, highlight } = useTagsViews()
const { zoomToFit } = useZoom()

const diagramStore = useDiagramStore()

const mappingStore = useMappingStore()

const { getData } = storeToRefs(diagramStore)

const filtersKey = computed(() => {
  switch (route.name) {
    case 'ProviderAccountVisualize':
      return 'account-' + route.params.providerID
    case 'InventoryProviderDiagramView':
      return 'provider-' + route.params.provider
    case 'ProjectDesign':
      return 'project-' + route.params.id
    default:
      return 'global'
  }
})

const filters = ref(
  diagramStore.resourcesFilters[filtersKey.value] || {
    hiddenRegions: [],
    hiddenResources: [],
    open: [],
    hideEmpty: false
  }
)
const hideEmpty = ref(null)

const displayed = computed(() => {
  const resourcesKeys = Object.keys(resources.value)
  const regionsKeys = Object.keys(regions.value)
  const query = search.value.toLowerCase()

  const displayedResources = {}
  const displayedRegions = {}

  const matchingResourcesKeys = resourcesKeys
    .filter((key) => key.toLowerCase().includes(query))
    .sort()
  const matchingRegionsKeys = regionsKeys.filter((key) => key.toLowerCase().includes(query)).sort()

  // In case the user searched for an instance type.
  if (matchingResourcesKeys.length) {
    for (const key of matchingResourcesKeys) {
      displayedResources[key] = resources.value[key]
    }
  } else {
    // Maybe they're looking for an item name.
    for (const key of resourcesKeys) {
      const matchingResources = resources.value[key].filter((resource) =>
        resource.name.toLowerCase().includes(query)
      )

      if (matchingResources.length) {
        displayedResources[key] = matchingResources
      }
    }
  }

  for (const key of matchingRegionsKeys) {
    displayedRegions[key] = regions[key]
  }

  return {
    resources: displayedResources,
    regions: displayedRegions
  }
})

watch(displayed, (newDisplayed) => {
  if (!search.value && expandResults.value) {
    filters.value.open = []
  }

  const newOpen = [...Object.keys(newDisplayed.regions), ...Object.keys(newDisplayed.resources)]

  if (
    expandResults.value &&
    newOpen.length < Object.keys(resources.value).length + Object.keys(regions.value).length
  ) {
    filters.value.open = newOpen
  }
})

watch(expandResults, (val) => {
  if (!val) {
    filters.value.open = []
  } else {
    filters.value.open = [
      ...Object.keys(displayed.value.regions),
      ...Object.keys(displayed.value.resources)
    ]
  }
})

function toggleHideEmptyEnvironments(val) {
  const { commandManager } = window
  diagramStore.setLayouting(true)
  if (val) {
    commandManager.initBatchCommand()
    filterNoise(window.graph)
    performLayout(window.graph)
    diagramStore.setData(exportData(window.graph.toJSON().cells))
    commandManager.storeBatchCommand()
    diagramStore.setLayouting(false)
    setTimeout(zoomToFit, 200)
    reload()
  } else {
    commandManager.undo()
    setTimeout(zoomToFit, 200)
    diagramStore.setLayouting(false)
  }

  nextTick(() => {
    diagramStore.setResourcesFilters(filtersKey.value, {
      ...filters.value,
      hideEmpty: val
    })
  })
}

watch(showTags, (val) => {
  if (val) {
    displayTags()
  } else {
    hideTags()
  }
})

function restoreFilters() {
  const { hiddenResources, hiddenRegions } = filters.value

  for (const resourceID of hiddenResources) {
    toggleDisplay(resourceID, false)
  }

  for (const region of hiddenRegions) {
    toggleDisplay(regions.value[region], false)
  }
}

function load() {
  const { groups, nodes } = getData.value
  if (!groups || !nodes) {
    return
  }

  const items = [...groups, ...nodes]

  if (!items.length || loaded.value) {
    return
  }

  const withPath = items.filter((item) => item.path !== undefined)
  const withLocation = items.filter((item) => item.location !== undefined)

  const resourcesObj = {}
  const regionsObj = {}

  for (const item of withPath) {
    const { id, path, name, image } = item

    const { productName } = mappingStore.splitPath(path)

    if (!productName) {
      continue
    }

    if (!resourcesObj[productName]) {
      resourcesObj[productName] = []
    }

    resourcesObj[productName].push({
      id,
      name,
      image
    })
  }

  resources.value = resourcesObj

  for (const item of withLocation) {
    const { id, location } = item

    if (!regionsObj[location]) {
      regionsObj[location] = id
    }
  }

  regions.value = regionsObj

  initTags()

  restoreFilters()

  loaded.value = true
  if (hideEmpty.value === null) {
    hideEmpty.value = filters.value.hideEmpty
  }
}

function reload() {
  loaded.value = false
  load()
}

function toggleOpen(productName) {
  const index = filters.value.open.indexOf(productName)
  if (index < 0) {
    filters.value.open.push(productName)
  } else {
    filters.value.open.splice(index, 1)
  }
}

function isOpen(productName) {
  return filters.value.open.includes(productName)
}

function moreIconsChevron(productName) {
  return isOpen(productName) ? 'chevron-up' : 'chevron-down'
}

function isHidden(productName, resourceID = '') {
  const { hiddenResources } = filters.value

  if (!resourceID) {
    const resourcesForProduct = resources.value[productName].map(({ id }) => id)
    const isProductHidden = hiddenResources.includes(productName)
    const allResourcesHidden = resourcesForProduct.every((id) => hiddenResources.includes(id))

    return isProductHidden || allResourcesHidden
  } else {
    return hiddenResources.includes(resourceID)
  }
}

function eyeIcon(productName, resourceID = '') {
  return isHidden(productName, resourceID) ? 'eye-off' : 'eye'
}

function toggleItem(graph, id, visible) {
  if (window.commandManager) {
    window.commandManager.stopListening()
  }

  const element = graph.getCell(id)

  if (!element) {
    return
  }

  element.attr('./display', visible ? 'block' : 'none', {})

  const hideLinks = (item) => {
    const links = graph.getConnectedLinks(item)

    for (const link of links) {
      link.attr('./display', visible ? 'block' : 'none')
    }
  }

  const hideChildren = (item) => {
    if (!item.getEmbeddedCells) {
      return
    }

    const children = item.getEmbeddedCells()

    for (const child of children) {
      child.attr('./display', visible ? 'block' : 'none')
      hideChildren(child)
      hideLinks(child)
    }
  }

  hideChildren(element)
  hideLinks(element)

  if (window.commandManager) {
    window.commandManager.listen()
  }
}

function toggleDisplay(id, visible) {
  const { graph, graph1, graph2 } = window

  if (graph) {
    toggleItem(graph, id, visible)
  } else {
    toggleItem(graph1, id, visible)
    toggleItem(graph2, id, visible)
  }
}

function toggleSingleItem(id) {
  const index = filters.value.hiddenResources.indexOf(id)

  if (index > -1) {
    filters.value.hiddenResources.splice(index, 1)
  } else {
    filters.value.hiddenResources.push(id)
  }

  toggleDisplay(id, index > -1)
}

function toggleProductVisibility(productName) {
  const resourcesIDs = resources.value[productName].map(({ id }) => id)

  if (!resourcesIDs) {
    return
  }

  const visible = isHidden(productName)

  for (const id of resourcesIDs) {
    toggleDisplay(id, visible)
    toggleSingleItem(id)
  }
}

function toggleRegionVisibility(region) {
  const id = regions.value[region]
  const index = filters.value.hiddenRegions.indexOf(region)
  if (index > -1) {
    filters.value.hiddenRegions.splice(index, 1)
    toggleDisplay(id, true)
  } else {
    filters.value.hiddenRegions.push(region)
    toggleDisplay(id, false)
  }
}

function select(ids) {
  const { graph, graph1, graph2 } = window
  const { selection, selection1, selection2 } = window

  const findItem = (id) => {
    if (graph) {
      const element = graph.getCell(id)

      return {
        graph: 'default',
        element
      }
    }

    const inGraph1 = graph1.getCell(id)

    if (inGraph1) {
      return {
        graph: 'graph1',
        element: inGraph1
      }
    }

    const inGraph2 = graph2.getCell(id)

    if (inGraph2) {
      return {
        graph: 'graph2',
        element: inGraph2
      }
    }

    return undefined
  }

  const items = ids.map((id) => {
    const item = findItem(id)
    const { attributes } = item.element
    const { type } = attributes
    return {
      type,
      model: attributes,
      item
    }
  })

  if (selection) {
    selection.collection.reset()
  } else {
    selection1.collection.reset()
    selection2.collection.reset()
  }

  const selections = {
    default: selection,
    graph1: selection1,
    graph2: selection2
  }

  items.forEach((item) => {
    selections[item.item.graph].collection.add(item.item.element)
  })

  if (items.length === 1) {
    window.scroller.centerElement(items[0].item.element)
  }
}

function focusRegion(region) {
  const id = regions.value[region]
  if (id) {
    select([id])
  }
}

function toggleTagKey(key) {
  const index = openTagsKeys.value.indexOf(key)
  if (index < 0) {
    openTagsKeys.value.push(key)
  } else {
    openTagsKeys.value.splice(index, 1)
  }
}

function toggleKeyValue(key, value) {
  const { key: selectedKey, value: selectedValue } = selectedTagKeyValue.value
  if (selectedKey === key && selectedValue === value) {
    selectedTagKeyValue.value = { key: '', value: '' }
  } else {
    selectedTagKeyValue.value = { key, value }
  }
}

watch(selectedTagKeyValue, (current, previous) => {
  highlight(current, previous)
})

function tagsModal(id) {
  oruga.modal.open({
    component: ResourceTagsModal,
    trapFocus: true,
    props: {
      tags: resourcesTags.value[id]
    }
  })
}

watch(hideEmpty, toggleHideEmptyEnvironments)
watch(
  filters,
  (newFilters) => {
    diagramStore.setResourcesFilters(filtersKey.value, newFilters)
  },
  { deep: true }
)

onMounted(() => {
  EventBus.on('tags-label-clicked', tagsModal)
})

onBeforeUnmount(() => {
  EventBus.remove('tags-label-clicked', tagsModal)
})

defineExpose({
  load,
  reload
})
</script>
<template>
  <ScrollToTop tag="aside" class-name="resources">
    <div class="m-3 mb-5">
      <o-input
        v-model="search"
        v-keyboard-shortcut.focus="'/'"
        class="mb-3"
        icon="filter"
        placeholder="Filter resources or regions"
        clearable
        rounded
        expanded
      />
      <div class="is-flex is-align-items-center is-justify-content-space-between mb-2">
        <o-switch v-model="expandResults" size="small"> Expand search results </o-switch>
        <o-tooltip
          class="information-tooltip"
          label="Your filters are automatically saved and will be restored the next time you view this project."
          position="left"
        >
          <o-icon icon="information-outline" size="small" />
        </o-tooltip>
      </div>

      <div class="is-flex is-align-items-center is-justify-content-space-between mb-2">
        <o-switch v-model="hideEmpty" size="small"> Hide empty environments </o-switch>
        <o-tooltip
          class="information-tooltip"
          label="Hide regions that do not contain any resources inside."
          position="left"
        >
          <o-icon icon="information-outline" size="small" />
        </o-tooltip>
      </div>

      <div class="is-flex is-align-items-center is-justify-content-space-between">
        <o-switch v-model="showTags" size="small">Show tags</o-switch>
        <o-tooltip
          class="information-tooltip"
          label="Display costs on the diagram."
          position="left"
        >
          <o-icon icon="information-outline" size="small" />
        </o-tooltip>
      </div>
    </div>

    <p
      class="menu-label is-flex is-gap-3 is-justify-content-space-between is-align-items-center is-clickable px-3"
      @click="diagramStore.toggleResourcesCategories('resources')"
    >
      Resources
      <o-icon :icon="diagramStore.resourcesCategories.resources ? 'chevron-up' : 'chevron-down'" />
    </p>
    <transition name="slide">
      <ul v-if="diagramStore.resourcesCategories.resources" class="menu-list pl-3">
        <li v-for="(items, productName) in displayed.resources" :key="productName">
          <a
            class="is-flex is-justify-content-space-between is-align-items-center"
            @click="toggleOpen(productName)"
          >
            <o-tooltip label="Click to toggle resource visibility" position="right">
              <span
                class="is-flex is-align-items-center is-clickable"
                @click.stop="toggleProductVisibility(productName)"
              >
                <o-icon :icon="eyeIcon(productName)" />
              </span>
            </o-tooltip>
            <span class="is-flex-grow-1 is-capitalized mx-3 ellipsis">
              {{ productName }}
            </span>
            <span v-if="items !== undefined" class="tag">
              {{ items.length }}
            </span>
            <o-icon :icon="moreIconsChevron(productName)" class="ml-2" />
          </a>

          <transition name="slide">
            <ul v-if="isOpen(productName) && items !== undefined" class="menu-list">
              <li v-for="item in items" :key="item.id" class="is-flex is-align-items-center">
                <o-tooltip label="Click to toggle resource visibility" position="right">
                  <span
                    class="is-flex is-align-items-center is-clickable"
                    @click.stop="toggleSingleItem(item.id)"
                  >
                    <o-icon :icon="eyeIcon(item.id, item.id)" />
                  </span>
                </o-tooltip>
                <a
                  class="is-flex is-justify-content-space-between is-align-items-center is-flex-1"
                  @click="select([item.id])"
                >
                  <img :src="item.image" class="entry-icon" :alt="item.id" />
                  <span class="name is-flex-grow-1 is-capitalized mx-3 ellipsis">
                    {{ item.name }}
                  </span>
                </a>
              </li>
            </ul>
          </transition>
        </li>
      </ul>
    </transition>

    <p
      class="menu-label is-flex is-gap-3 is-justify-content-space-between is-align-items-center is-clickable px-3"
      @click="diagramStore.toggleResourcesCategories('regions')"
    >
      Regions
      <o-icon :icon="diagramStore.resourcesCategories.regions ? 'chevron-up' : 'chevron-down'" />
    </p>
    <transition name="slide">
      <ul v-if="diagramStore.resourcesCategories.regions" class="menu-list pl-3">
        <li v-for="(_, region) in displayed.regions" :key="region">
          <a
            class="is-flex is-justify-content-space-between is-align-items-center"
            @click.stop="focusRegion(region)"
          >
            <o-tooltip label="Click to toggle region visibility" position="right">
              <span
                class="is-flex is-align-items-center is-clickable"
                @click.stop="toggleRegionVisibility(region)"
              >
                <o-icon :icon="filters.hiddenRegions.includes(region) ? 'eye-off' : 'eye'" />
              </span>
            </o-tooltip>
            <span class="is-flex-grow-1 is-capitalized mx-3 ellipsis">
              {{ region }}
            </span>
          </a>
        </li>
      </ul>
    </transition>

    <p
      class="menu-label is-flex is-gap-3 is-justify-content-space-between is-align-items-center is-clickable px-3"
      @click="diagramStore.toggleResourcesCategories('tags')"
    >
      Tags
      <o-icon :icon="diagramStore.resourcesCategories.tags ? 'chevron-up' : 'chevron-down'" />
    </p>
    <transition name="slide">
      <ul v-if="diagramStore.resourcesCategories.tags" class="menu-list pl-3">
        <li v-for="key in Object.keys(keysValues)" :key="key">
          <a
            class="is-flex is-justify-content-space-between is-align-items-center"
            @click="toggleTagKey(key)"
          >
            <span class="is-flex is-align-items-center is-gap-3">
              <o-icon icon="tag" />
              {{ key }}
            </span>
            <o-icon
              :icon="openTagsKeys.includes(key) ? 'chevron-up' : 'chevron-down'"
              class="ml-2"
            />
          </a>

          <transition name="slide">
            <ul v-if="openTagsKeys.includes(key)" class="menu-list">
              <li
                v-for="value in Object.keys(keysValues[key])"
                :key="key + '-' + value"
                class="is-flex is-align-items-center"
              >
                <a
                  class="is-flex is-justify-content-space-between is-align-items-center is-flex-1"
                  :class="{
                    'is-active':
                      selectedTagKeyValue.key === key && selectedTagKeyValue.value === value
                  }"
                  @click="toggleKeyValue(key, value)"
                >
                  <span class="is-flex is-align-items-center is-gap-3">
                    <o-icon
                      :icon="
                        selectedTagKeyValue.key === key && selectedTagKeyValue.value === value
                          ? 'tag'
                          : 'tag-outline'
                      "
                    />
                    {{ value }}
                  </span>
                  <span class="tag">
                    {{ keysValues[key][value].length }}
                  </span>
                </a>
              </li>
            </ul>
          </transition>
        </li>
      </ul>
    </transition>
  </ScrollToTop>
</template>

<style scoped>
.wrapper {
  max-height: calc(70vh - var(--tabs-height));
  top: 195px;
  left: 0;
  position: fixed;
  width: 22rem;
  z-index: 3;
  transition: transform 0.3s ease;
}
.wrapper--invisible {
  transform: translateX(-100%);
}
.wrapper:not(:empty) {
  box-shadow: 5px 0 13px 3px rgba(10, 10, 10, 0.1);
}
.resources {
  max-height: calc(70vh - var(--tabs-height));
  user-select: none;
  position: static;
}
.wrapper,
.resources {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}
.name {
  width: 50px;
}
.tag {
  background: #eceeff;
}
.toggle-menu {
  position: absolute;
  top: 50%;
  right: 0;
  transform: translate(50%, -50%);
  transition: transform 0.3s ease;
  z-index: 20;
}
.toggle-menu--off {
  transform: translate(100%, -50%);
}
.entry-icon {
  border-radius: 5px;
  max-height: 30px;
  width: 30px;
}

.information-tooltip :deep(.tooltip-content) {
  width: 305px;
  height: 70px;
  white-space: break-spaces;
}
</style>
