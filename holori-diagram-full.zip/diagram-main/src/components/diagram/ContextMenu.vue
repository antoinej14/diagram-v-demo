<script setup>
import { computed } from 'vue'
import { storeToRefs } from 'pinia'
import { OIcon } from '@oruga-ui/oruga-next'

import { useDiagramStore } from '@/store/diagram'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  position: {
    type: Object,
    required: true
  },
  item: {
    type: Object,
    required: false,
    default: null
  },
  canPaste: {
    type: Boolean,
    required: true
  }
})

const emit = defineEmits([
  'copy',
  'duplicate',
  'paste',
  'delete',
  'create-edge',
  'create-group',
  'attach-group',
  'detach-group',
  'select-all',
  'hide'
])

const diagramStore = useDiagramStore()

const { getGlobalSelectionCount, settings } = storeToRefs(diagramStore)

const itemType = computed(() => (props.item ? props.item.get('type') : ''))

const canAttachToAGroup = computed(() => {
  if (!props.item || !settings.value.resizeMode || !settings.value.lockedMode) {
    return false
  }

  const { groupId, parentId, parent } = props.item.getModel()
  return props.item && itemType.value !== 'Edge' && !groupId && !parentId && !parent
})

const canDetachFromAGroup = computed(() => {
  if (!props.item || settings.value.resizeMode || !settings.value.lockedMode) {
    return false
  }

  const { groupId, parentId } = props.item.getModel()
  return props.item && itemType.value !== 'Edge' && (groupId || parentId)
})

function copy() {
  emit('copy', { item: props.item })
  hide()
}

function duplicate() {
  emit('duplicate', { item: props.item })
  hide()
}

function paste() {
  emit('paste', { ...props.position })
  hide()
}

function deleteItem() {
  emit('delete', { item: props.item })
  hide()
}

function createEdge() {
  const { x: clientX, y: clientY } = props.position
  emit('create-edge', { clientX, clientY })
  hide()
}

function createGroup() {
  emit('create-group')
  hide()
}

function attachToAGroup() {
  emit('attach-group')
  hide()
}

function detachFromGroup() {
  emit('detach-group')
  hide()
}

function selectAll() {
  emit('select-all')
  hide()
}

function hide() {
  emit('hide')
}
</script>

<template>
  <ul
    class="context-menu is-absolute box m-0 px-0 py-1"
    :class="{ visible: props.visible }"
    :style="{ top: props.position.y + 'px', left: props.position.x + 'px' }"
  >
    <li
      v-if="item && itemType !== 'Edge' && !settings.lockedMode"
      class="context-menu__item"
      @click="createEdge"
    >
      <o-icon icon="ray-start-arrow" />
      Create an Edge
    </li>
    <li
      v-if="getGlobalSelectionCount && itemType !== 'Edge' && !settings.lockedMode"
      class="context-menu__item"
      @click="createGroup"
    >
      <o-icon icon="group" />
      Create a Group
    </li>
    <li
      v-if="item && itemType === 'Edge' && !settings.lockedMode"
      class="context-menu__item"
      @click="createControlPoint"
    >
      <o-icon icon="plus" />
      Add a control point
    </li>
    <li v-if="canAttachToAGroup" class="context-menu__item" @click="attachToAGroup">
      <o-icon icon="location-enter" />
      Attach to a Group
    </li>
    <li v-if="canDetachFromAGroup" class="context-menu__item" @click="detachFromGroup">
      <o-icon icon="location-exit" />
      Detach from the Group
    </li>
    <li
      v-if="getGlobalSelectionCount && itemType !== 'Edge' && !settings.lockedMode"
      class="context-menu__item"
      @click="copy"
    >
      <o-icon icon="content-copy" />
      Copy
    </li>
    <li
      v-if="getGlobalSelectionCount && itemType !== 'Edge' && !settings.lockedMode"
      class="context-menu__item"
      @click="duplicate"
    >
      <o-icon icon="content-duplicate" />
      Duplicate
    </li>
    <li v-if="canPaste" class="context-menu__item" @click="paste">
      <o-icon icon="content-paste" />
      Paste
    </li>
    <li
      v-if="getGlobalSelectionCount && !settings.lockedMode"
      class="context-menu__item"
      @click="deleteItem"
    >
      <o-icon icon="delete" />
      Delete
    </li>
    <li v-if="!getGlobalSelectionCount && !item" class="context-menu__item" @click="selectAll">
      <o-icon icon="select-all" />
      Select All
    </li>
  </ul>
</template>

<style scoped>
.context-menu {
  transition: opacity 0.3s ease;
  opacity: 0;
  pointer-events: none;
  z-index: 3;
}
.context-menu.visible {
  opacity: 1;
  pointer-events: all;
}
.context-menu__item {
  align-items: center;
  cursor: pointer;
  display: flex;
  padding: 5px 10px;
}
.context-menu__item:hover {
  background-color: #5f95ff;
  color: #fff;
}
.context-menu__item :deep() .icon {
  margin-right: 10px;
}
</style>
