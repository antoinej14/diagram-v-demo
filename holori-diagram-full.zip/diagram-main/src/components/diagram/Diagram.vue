<script setup>
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, onBeforeRouteLeave } from 'vue-router'
import { g, format } from '@joint/plus'
import { storeToRefs } from 'pinia'
import { v4 } from 'uuid'
import { OButton, OSwitch } from '@oruga-ui/oruga-next'

import { useProjectStore } from '@/store/project'
import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import readG6Diagram from '@/common/diagram/options/methods/read'
import exportData from '@/common/diagram/options/methods/export'
import Node from '@/common/diagram/options/shapes/node.js'
import Group from '@/common/diagram/options/shapes/group.js'
import Edge from '@/common/diagram/options/shapes/edge.js'
import TextBox from '@/common/diagram/options/shapes/textbox.js'
import { debounce } from '@/common/utils'
import { performLayout, resizeGroup, filterNoise } from '@/common/diagram/options/methods/layout'
import EventBus from '@/common/eventBus'
import { useMixins } from '@/common/mixins'

import DiagramToolbar from '@/components/diagram/Toolbar.vue'
import DiagramContextMenu from '@/components/diagram/ContextMenu.vue'
import DiagramMultipleSelection from '@/components/diagram/MultipleSelection.vue'
import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import DiagramDetails from '@/components/diagram/Details.vue'
import Diagram3DView from '@/components/diagram/Diagram3DView.vue'

import { useInitDiagram } from './hooks/init'
import { defaultSettings, useSettings } from './hooks/settings'
import { useZoom } from './hooks/zoom'

defineOptions({
  name: 'DiagramView'
})

const emit = defineEmits(['save-diagram'])

const route = useRoute()
const { setPageTitle, setFavicon, updateQueryJS } = useMixins()

onBeforeRouteLeave((_to, _from, next) => {
  if (confirmLeave()) {
    next()
  } else {
    next(false)
  }
})

const leftSidebarVisible = ref(true)
const rightSidebarVisible = ref(true)
const contextMenu = ref({
  visible: false,
  position: { x: 0, y: 0 },
  item: null,
  canPaste: false
})
const use3dView = ref(false)

const leftSidebarRef = ref(null)
const canvasRef = ref(null)

const { zoomIn, zoomOut, zoomToFit } = useZoom()
const { initDiagram, initEditEvents } = useInitDiagram({
  canvasRef,
  contextMenu,
  zoomIn,
  zoomOut
})

const { updateSettings } = useSettings(createAutosave)

const projectStore = useProjectStore()
const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { project, projectDiagram, autosave, autosaveDelay, readonly } = storeToRefs(projectStore)
const {
  saved,
  getSelectedItem,
  getGlobalSelectionCount,
  getSelectedGroup,
  settings,
  canLeave,
  isComparing
} = storeToRefs(diagramStore)

let designTab = null
let autosaveInterval = null

watch(saved, (isSaved) => {
  if (isSaved) {
    designTab?.classList.remove('unsaved')
  } else if (!isComparing.value) {
    designTab?.classList.add('unsaved')
  }

  setFavicon(isSaved)
})

watch(autosave, (hasAutosave) => {
  if (!hasAutosave) {
    stopAutosave()
  } else {
    createAutosave()
  }
})

watch(use3dView, (newVal) => {
  updateQueryJS({ '3d': !newVal ? null : '' })
})

onBeforeUnmount(() => {
  setFavicon(true)
  stopAutosave()

  window.graph.clear()
  window.paper.remove()
})

onMounted(() => {
  designTab = document.getElementById('navbar-Design')

  initDiagram({
    allowUndoRedo: true
  })

  initEditEvents()

  read()
  window.graph.on('change', updateDiagram)
  window.stencil.on('element:drop', updateDiagram)

  if (route.hash) {
    const hashID = route.hash.substring(1)

    const cell = window.graph.getCell(hashID)
    if (cell) {
      window.selection.collection.reset([cell])
    }
  }

  EventBus.on('reloadDiagram', reloadDiagram)

  const loadedSettings = JSON.parse(window.localStorage.getItem('diagram-settings'))
  updateSettings({
    ...defaultSettings,
    ...loadedSettings
  })

  if ('3d' in route.query) {
    use3dView.value = true
  }
})

const updateDiagram = debounce(function (markUnsaved = true, cb = () => {}) {
  if (typeof cb === 'object' && cb.propertyPath?.includes('display')) {
    return
  }

  diagramStore.setData(exportData(window.graph.toJSON().cells))

  if (leftSidebarRef.value) {
    leftSidebarRef.value.reloadResources()
  }

  if (markUnsaved && !isComparing.value) {
    diagramStore.setSaved(false)
  }

  if (typeof cb === 'function') {
    cb()
  }
})

function startAddEdge(event) {
  const { x, y } = window.paper.clientToLocalPoint(event.clientX, event.clientY)
  const target = new g.Point(x, y)
  const link = new Edge()

  window.commandManager.initBatchCommand()

  const element = window.graph.getCell(getSelectedItem.value.id)
  link.source(element)
  link.target(target)
  link.connector('jumpover', { size: 10 })
  link.addTo(window.graph)
  window.newEdge = link
  window.newEdgeOriginal = { x, y }
}

function startAddNode(payload) {
  if (window.lockedMode) {
    return
  }

  const { node, event } = payload
  const { type, path, name } = node
  const id = v4()
  const { x, y } = window.paper.clientToLocalPoint(event.clientX, event.clientY)

  window.commandManager.initBatchCommand()

  if (type === 'TextBox') {
    const element = new TextBox({
      id,
      position: { x, y },
      notes: 'Text Box'
    })
    element.attr('label/text', 'Text Box')
    window.stencil.startDragging(element, event)
    return
  }

  const constructor = type === 'group' ? Group : Node

  const createElement = (image) => {
    const element = new constructor({
      id,
      image,
      name,
      path: path || '',
      ...node,
      type: type === 'group' ? 'Group' : 'Node',
      position: { x, y }
    })

    if (image) {
      element.attr('image/href', image)
    }

    if (type === 'group') {
      element.size(250, 150)
    }

    window.stencil.startDragging(element, event)
  }

  if (path) {
    createElement(`/diagram/diagram${path}.svg`)
  } else {
    createElement(node.image)
  }
}

function startAddDuplicate() {
  window.addingDuplicate = getSelectedGroup.value.id
}

function undo() {
  window.commandManager.undo()
}

function redo() {
  window.commandManager.redo()
}

function selectAll() {
  const cells = window.graph.getCells()
  window.selection.collection.reset(cells)
}

function copy() {
  const collection = window.selection.collection.clone()
  const array = collection.toArray()

  const loopChildren = (item) => {
    if (!item.getEmbeddedCells) {
      return
    }

    const children = item.getEmbeddedCells()

    for (const child of children) {
      collection.add(child)
      loopChildren(child)
    }
  }

  for (const item of array) {
    loopChildren(item)
  }

  window.clipboard.copyElements(collection, window.graph)
  contextMenu.value.canPaste = true
}

function paste(position) {
  if (position) {
    const point = window.paper.clientToLocalPoint(position.x, position.y)
    window.clipboard.pasteCellsAtPoint(window.graph, point)
  } else {
    window.clipboard.pasteCells(window.graph)
  }
  updateDiagram()
}

function duplicate() {
  copy()
  paste()
}

function deleteSelection() {
  diagramStore.clearSelection()
  window.commandManager.initBatchCommand()

  const elements = window.selection.collection.toArray()
  const parents = []
  for (const element of elements) {
    const parent = element.getParentCell()
    if (parent) {
      parents.push(parent)
    }
    element.remove()
  }

  for (const parent of parents) {
    resizeGroup(parent)
  }

  window.commandManager.storeBatchCommand()

  updateDiagram()
}

function deleteFromContextMenu(item) {
  diagramStore.clearSelection()
  window.commandManager.initBatchCommand()
  const cell = window.graph.getCell(item.item.attributes.id)
  const parent = cell.getParentCell()
  cell.remove()
  if (parent) {
    resizeGroup(parent)
  }
  window.commandManager.storeBatchCommand()
  updateDiagram()
}

async function layout() {
  window.commandManager.initBatchCommand()

  diagramStore.setLayouting(true)

  performLayout(window.graph)

  setTimeout(zoomToFit, 200)

  diagramStore.setLayouting(false)
  window.commandManager.storeBatchCommand()
}

function toggleResizeMode() {
  window.resizeMode = !window.resizeMode
}

function toggleLockedMode() {
  window.lockedMode = !window.lockedMode

  updateSettings({
    ...settings.value,
    lockedMode: !settings.value.lockedMode
  })
}

function createGroupFromSelection() {
  const elements = window.selection.collection.toArray()
  const minZ = elements.reduce((z, el) => Math.min(el.get('z') || 0, z), -Infinity)
  const group = new Group({
    id: v4(),
    name: 'Group'
  })
  group.set('z', minZ - 1)
  group.addTo(window.graph)
  group.embed(elements)
  group.fitEmbeds()

  const { x, y } = group.position()
  const { width, height } = group.size()
  group.position(x - 10, y - 40)
  group.size(width + 20, height + 50)
  window.commandManager.squashUndo(2)

  updateDiagram(true, () => {
    window.selection.collection.reset([group])
  })
}

function reloadDiagram() {
  read(true)
  diagramStore.setSaved(true)
}

function read(forceLayout = false) {
  const diagram = projectDiagram.value

  if (diagram) {
    const json = JSON.parse(diagram)
    const data = readG6Diagram(json, window.graph, window.paper, window.linkToolsView)
    diagramStore.setData(data)
    window.commandManager.reset()
  }

  window.paper.unfreeze()

  const ready = () => {
    setTimeout(zoomToFit, 200)
    updateDiagram(false)
  }

  if (diagram && project.value.imported) {
    const { organization_id, id } = project.value
    projectStore.getProjectThumbnail(organization_id, id).then((res) => {
      if (!res.data.thumbnail || forceLayout) {
        filterNoise(window.graph)
        performLayout(window.graph)
        ready()
        setTimeout(save, 500)
      } else {
        ready()
      }
    })
  } else {
    ready()
  }
}

function save() {
  format.toJPEG(
    window.paper,
    (dataURI) => {
      emit('save-diagram', dataURI)
    },
    {
      width: 200,
      height: 130,
      quality: 0.8,
      size: '0.5x',
      padding: 10,
      useComputedStyles: false
    }
  )
}

function createAutosave(recreate = true) {
  stopAutosave()

  if (recreate) {
    autosaveInterval = setInterval(() => {
      save()
    }, autosaveDelay.value * 1000)
  }
}

function stopAutosave() {
  clearInterval(autosaveInterval)
  autosaveInterval = null
}

function confirmLeave() {
  if (!canLeave.value) {
    return window.confirm('Are you sure you want to leave? Changes you made may not be saved.')
  }
  return true
}

diagramStore.reset()
diagramStore.clearSelection()
setPageTitle(project.value.name)
diagramStore.loadCompanies().then((companies) => mappingStore.getAllRegions(companies))
</script>

<template>
  <div class="diagram-view is-relative">
    <div class="back has-background-white p-3">
      <router-link :to="{ name: 'ProjectsOverview' }" v-slot="{ href }">
        <o-button tag="a" :href="href" variant="primary" icon-left="arrow-left" size="small">
          Back to projects
        </o-button>
      </router-link>
    </div>

    <div v-if="!isComparing" class="use-3d-view has-background-white is-absolute p-3">
      <o-switch v-model="use3dView"> Use 3D view</o-switch>
    </div>
    
    <div v-show="!use3dView" key="not-3d">
      <transition-group name="fade-x">
        <div key="toolbar-context-menu" v-if="!readonly">
          <DiagramToolbar
            :can-create-edge="!!getSelectedItem"
            :can-create-group="getGlobalSelectionCount > 0"
            :settings="settings"
            @undo="undo"
            @redo="redo"
            @create-edge="startAddEdge"
            @create-group="createGroupFromSelection"
            @select-all="selectAll"
            @duplicate="duplicate"
            @delete="deleteSelection"
            @zoom-in="zoomIn"
            @zoom-out="zoomOut"
            @reset-zoom="zoomToFit"
            @layout="layout"
            @toggle-resize-mode="toggleResizeMode"
            @toggle-locked-mode="toggleLockedMode"
            @settings-change="updateSettings"
            @save="save"
          />
          <DiagramContextMenu
            :visible="contextMenu.visible"
            :position="contextMenu.position"
            :item="contextMenu.item"
            :can-paste="contextMenu.canPaste"
            @copy="copy"
            @paste="paste"
            @delete="deleteFromContextMenu"
            @duplicate="duplicate"
            @create-edge="startAddEdge"
            @create-group="createGroupFromSelection"
            @select-all="selectAll"
            @hide="contextMenu.visible = false"
          />
        </div>
        <DiagramMultipleSelection v-if="getGlobalSelectionCount >= 2" key="multiple-selection" />
        <DiagramLeftSidebar
          v-if="getGlobalSelectionCount < 2"
          ref="leftSidebarRef"
          key="left-sidebar"
          :visible="leftSidebarVisible"
          @add-node="startAddNode"
          @toggle-visibility="leftSidebarVisible = !leftSidebarVisible"
        />
        <DiagramDetails
          key="details"
          :visible="rightSidebarVisible"
          general-tab
          @add-duplicate="startAddDuplicate"
          @toggle-visibility="rightSidebarVisible = !rightSidebarVisible"
        />
        <div ref="canvasRef" key="canvas" class="canvas" />
      </transition-group>
    </div>
    <transition name="fade-x">
      <Diagram3DView v-if="use3dView" key="is-3d" />
    </transition>
  </div>
</template>

<style scoped>
.diagram-view {
  padding-top: var(--navbar-height);
}

.back {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  z-index: 20;
}
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: calc(100vh - var(--navbar-height));
}
.use-3d-view {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  right: 0;
  z-index: 2;
}
</style>

<style>
body {
  overflow: hidden;
}
</style>
