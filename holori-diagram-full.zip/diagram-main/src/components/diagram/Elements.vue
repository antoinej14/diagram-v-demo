<script setup>
import { ref, computed, onBeforeUnmount } from 'vue'
import { OIcon, OInput, OLoading, OSwitch } from '@oruga-ui/oruga-next'

import diagramApi from '@/api/modules/public/diagram'

import EventBus from '@/common/eventBus'
import { getImage } from '@/common/diagram/options/shared'
import { useMixins } from '@/common/mixins'

import ProvidersList from '@/components/diagram/ProvidersList.vue'
import ElementsGroup from '@/components/diagram/ElementsGroup.vue'
import ScrollToTop from '@/components/ScrollToTop.vue'

defineOptions({
  name: 'DiagramElements'
})

const emit = defineEmits(['add-node', 'stop-add-node'])

const { toast, closeAllToasts } = useMixins()

const search = ref('')
const searchIcons = ref(false)
const menuData = ref([])
const moreIcons = ref({})
const moreIconsOpened = ref([])
const selectedCompanies = ref([])
const dragOver = ref(false)
const customs = ref([])
const addingNode = ref(null)

const uploadRef = ref(null)

const filteredMenuData = computed(() => {
  if (search.value.length < 3) {
    return menuData.value
  }

  const query = search.value.toLowerCase()

  return menuData.value.filter((entry) => {
    const entryName = entry.name.toLowerCase()
    const entryNameReplaced = entryName.replace(/[-_.]/g, ' ')
    const aliases = entry.alias.join('').toLowerCase()
    const aliasesReplaced = aliases.replace(/[-_.]/g, ' ')
    return (
      entryName.includes(query) ||
      aliases.includes(query) ||
      entryNameReplaced.includes(query) ||
      aliasesReplaced.includes(query)
    )
  })
})

const entries = computed(() => {
  const entries = {}
  for (const entry of filteredMenuData.value) {
    const name = entry.name.split('.', 2)[0]

    if (!(name in entries)) {
      entries[name] = []
    }

    entries[name].push(entry)
  }

  return entries
})

const sortedEntries = computed(() => {
  const withEntries = Object.keys(entries.value)
    .filter((entry) => entries.value[entry].length > 1)
    .sort()
  const withoutEntries = Object.keys(entries.value)
    .filter((entry) => entries.value[entry].length === 1)
    .sort()
  return [...withEntries, ...withoutEntries]
})

const className = 'elements has-background-white'

onBeforeUnmount(() => {
  EventBus.remove('displayAddNode', displayAddNode)
})

function addNode(node) {
  addingNode.value = node
}

function emitAddNode(event) {
  if (addingNode.value) {
    emit('add-node', {
      node: addingNode.value,
      event
    })
    addingNode.value = null
  }
}

function addTextBox(event) {
  event.preventDefault()

  // Not left click? Stop.
  if (event.buttons !== 1) {
    return
  }

  addNode({
    type: 'TextBox',
    name: 'Text',
    notes: 'Text Node'
  })
}

function addEmptyGroup(event) {
  event.preventDefault()

  // Not left click? Stop.
  if (event.buttons !== 1) {
    return
  }

  addNode({
    type: 'group',
    group: true,
    name: 'Group'
  })
}

function addLocationGroup(event) {
  event.preventDefault()

  // Not left click? Stop.
  if (event.buttons !== 1) {
    return
  }

  addNode({
    type: 'group',
    group: true,
    name: 'Location Group',
    location: ''
  })
}

function addCustomElement(event, element) {
  event.preventDefault()

  // Not left click? Stop.
  if (event.buttons !== 1) {
    return
  }

  addNode({
    type: 'text-box',
    notes: 'Custom element',
    ...element
  })
}

function addComplementaryIcon(event, category, icon) {
  event.preventDefault()

  // Not left click? Stop.
  if (event.buttons !== 1) {
    return
  }

  getImage(`/diagram/icons/${category}/${icon.replace('.svg', '')}`, 40, (image) => {
    addNode({
      type: 'text-box',
      notes: icon,
      name: icon,
      image
    })
  })
}

function displayAddNode() {
  closeAllToasts()
  toast({
    message: 'Please drag & drop a node on the diagram to create it.',
    variant: 'info'
  })
}

function triggerBrowseFiles() {
  uploadRef.value.click()
}

function addImageElement(file) {
  const { name } = file
  const reader = new FileReader()
  reader.onloadend = () => {
    customs.value.push({
      name,
      image: reader.result
    })
  }
  reader.readAsDataURL(file)
}

function selectFile(e) {
  const file = e.target.files[0]
  if (file) {
    addImageElement(file)
  }
}

function uploadImage(e) {
  e.preventDefault()

  const file = e.dataTransfer.files[0]
  addImageElement(file)
}

function dragOverHandler(e) {
  e.preventDefault()
  dragOver.value = true
}

function isCompanySelected(name) {
  return !selectedCompanies.value.length || selectedCompanies.value.includes(name)
}

function moreIconsToggle(category) {
  const index = moreIconsOpened.value.indexOf(category)
  if (index > -1) {
    moreIconsOpened.value.splice(index, 1)
  } else {
    moreIconsOpened.value.push(category)
  }
}

function moreIconsChevron(category) {
  return moreIconsOpened.value.includes(category) ? 'chevron-up' : 'chevron-down'
}

diagramApi
  .get('menu.json')
  .catch((error) => {
    console.warn('unable to load diagram menu :', error)
  })
  .then(({ data }) => {
    menuData.value = data
  })

EventBus.on('displayAddNode', displayAddNode)

diagramApi
  .get('icons/list.json')
  .catch((error) => {
    console.warn('unable to load diagram additonal icons :', error)
  })
  .then(({ data }) => {
    moreIcons.value = data
  })
</script>
<template>
  <ScrollToTop
    tag="aside"
    :class-name="className"
    @mouseleave="emitAddNode"
    @mouseup="emit('stop-add-node')"
  >
    <div class="p-3">
      <o-input
        id="elements-search"
        ref="searchRef"
        v-model="search"
        v-keyboard-shortcut.focus="'/'"
        rounded
        clearable
        placeholder="Search an element (/ to focus)"
        icon="magnify"
        class="mb-3"
      />
      <o-switch
        v-model="searchIcons"
        title="Warning: Enabling this option might increase the search time"
        size="small"
        root-class="mb-3 is-pulled-right"
        position="left"
      >
        Search in generic icons
      </o-switch>
      <ProvidersList :menu-data="menuData" @select="selectedCompanies = $event" />
    </div>
    <aside class="menu">
      <p class="menu-label px-3">Static Elements</p>
      <ul class="menu-list px-2">
        <li>
          <a
            class="is-flex is-align-items-center"
            @mousedown="addTextBox"
            @mouseup="displayAddNode"
          >
            <o-icon class="element-icon mr-3" icon="text" />
            Text Box
          </a>
        </li>
        <li>
          <a
            class="is-flex is-align-items-center"
            @mousedown="addEmptyGroup"
            @mouseup="displayAddNode"
          >
            <o-icon class="element-icon mr-3" icon="group" />
            Empty Group
          </a>
        </li>
        <li>
          <a
            class="is-flex is-align-items-center"
            @mousedown="addLocationGroup"
            @mouseup="displayAddNode"
          >
            <o-icon class="element-icon mr-3" icon="map-marker" />
            Location Group
          </a>
        </li>
      </ul>
      <p class="menu-label px-3">Provider Elements</p>
      <ul class="menu-list px-2 pb-2">
        <template v-if="menuData">
          <span v-for="name in sortedEntries" :key="name">
            <ElementsGroup
              v-if="isCompanySelected(name)"
              :has-search="search.length >= 3"
              :level="0"
              :name="name"
              :data="entries[name]"
              :path="name"
              :selected-companies="selectedCompanies"
              @add-node="addNode"
            />
          </span>
        </template>
        <o-loading v-else />
      </ul>
      <p class="menu-label px-3">Complementary Elements</p>
      <ul class="menu-list px-2 pb-2">
        <li
          v-for="category in Object.keys(moreIcons)"
          :key="category"
          @click="moreIconsToggle(category)"
        >
          <a class="is-flex is-justify-content-space-between is-align-items-center pr-0">
            <img :src="`/diagram/icons/${category}.svg`" class="entry-icon" lazy />
            <span class="is-flex-grow-1 is-capitalized mx-3 ellipsis">
              {{ category }}
            </span>
            <o-icon :icon="moreIconsChevron(category)" class="is-pulled-right" />
          </a>
          <transition name="slide">
            <ul
              v-if="moreIconsOpened.includes(category) || (searchIcons && search)"
              class="`menu-list menu-list--1 mt-0 mr-0`"
            >
              <template v-for="(name, icon) of moreIcons[category]">
                <li
                  v-if="(search && searchIcons && icon.includes(search)) || !search || !searchIcons"
                  :key="icon"
                >
                  <a
                    class="is-flex is-justify-content-space-between is-align-items-center pr-0"
                    @mousedown="addComplementaryIcon($event, category, icon)"
                    @mouseup="displayAddNode"
                  >
                    <img :src="`/diagram/icons/${category}/${icon}.svg`" class="entry-icon" lazy />
                    <span class="is-flex-grow-1 mx-3 ellipsis">
                      {{ name }}
                    </span>
                  </a>
                </li>
              </template>
            </ul>
          </transition>
        </li>
      </ul>
      <p class="menu-label px-3">Custom Elements</p>
      <ul class="menu-list px-2 pb-2">
        <transition-group name="fade-x">
          <li v-for="(element, index) in customs" :key="'custom-' + index">
            <a
              class="is-flex is-justify-content-space-between is-align-items-center pr-0"
              @mousedown="addCustomElement($event, element)"
              @mouseup="displayAddNode"
            >
              <img :src="element.image" class="entry-icon" lazy />
              <span class="is-flex-grow-1 mx-3 ellipsis">
                {{ element.name }}
              </span>
            </a>
          </li>
        </transition-group>
      </ul>
      <div
        class="mx-3 p-3 is-border-radius-md drop-zone"
        :class="{ 'drop-zone-over': dragOver }"
        @click="triggerBrowseFiles"
        @drop="uploadImage"
        @dragover="dragOverHandler"
        @dragleave="dragOver = false"
      >
        <input ref="uploadRef" type="file" @input="selectFile" />
        <div
          v-if="!dragOver"
          class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center"
        >
          <o-icon icon="image-outline" class="mr-3" />
          Drag an image here
        </div>
        <div
          v-else
          class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center"
        >
          <o-icon icon="check-circle-outline" class="mr-3" />
          Drop the file to create an item
        </div>
      </div>
    </aside>
  </ScrollToTop>
</template>

<style scoped>
.elements {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
  border-left: 0;
  max-height: calc(70vh - 24px);
  user-select: none;
  position: static;
}
.elements {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}
.menu {
  transition: opacity 0.3s ease;
}
.element-icon {
  height: 30px;
  width: 30px;
}
.no-scroll {
  overflow: hidden;
}
.no-more-elements {
  background-color: #ffffffcc;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 2;
}
.drop-zone {
  background-color: var(--primary-bg);
  border: 2px dashed var(--text-color);
}
.drop-zone-over {
  border-color: var(--primary);
}
.drop-zone input {
  display: none;
}
.entry-icon {
  border-radius: 5px;
  max-height: 30px;
  width: 30px;
}
.toggle-menu {
  position: absolute;
  top: 50%;
  left: 100%;
  transform: translate(-50%, -50%);
  transition: transform 0.3s ease;
  z-index: 20;
}
.toggle-menu--off {
  transform: translate(0, -50%);
}
</style>
