<script setup>
import { computed, ref, watch, nextTick } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, OTabItem, OTabs, OTooltip } from '@oruga-ui/oruga-next'

import { useDiagramStore } from '@/store/diagram'

import DiagramElements from './Elements.vue'
import DiagramResources from './Resources.vue'
import DiagramDiff from './Diff.vue'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  visualizeMode: {
    type: Boolean,
    required: false,
    default: false
  },
  displayDiff: {
    type: Boolean,
    required: false,
    default: false
  }
})

const emit = defineEmits(['add-node', 'stop-add-node', 'toggle-visibility', 'show-costs'])

const tab = ref('elements')

const diffRef = ref(null)
const resourcesRef = ref(null)

const diagramStore = useDiagramStore()

const { getGlobalSelectionCount, isComparing, settings } = storeToRefs(diagramStore)

const showElements = computed(() => {
  return !!(
    !props.visualizeMode &&
    (settings.value.lockedMode || !isComparing.value || getGlobalSelectionCount.value < 2)
  )
})

watch(() => settings.value.lockedMode, updateTab)
watch(isComparing, (val) => {
  if (val) {
    nextTick(() => {
      diffRef.value.load()
    })
  } else {
    tab.value = 'resources'
    resourcesRef.value.reload()
  }
})
watch(tab, (newTab) => {
  if (newTab === 'resources') {
    if (resourcesRef.value) {
      resourcesRef.value.load()
    }
  }
})

function updateTab() {
  if (settings.value.lockedMode || props.visualizeMode) {
    tab.value = 'resources'
  }
}

function reloadResources() {
  if (resourcesRef.value) {
    resourcesRef.value.reload()
  }
}

function reloadDiff() {
  if (diffRef.value) {
    diffRef.value.load()
  }
}

defineExpose({
  reloadResources,
  reloadDiff
})

updateTab()
</script>

<template>
  <fieldset
    id="left-sidebar"
    class="wrapper has-background-white"
    :class="{ 'wrapper--invisible': !visible }"
  >
    <o-tooltip
      :position="visible ? 'left' : 'right'"
      label="Toggle elements and assets view (Tab)"
      class="toggle-menu"
      :class="{ 'toggle-menu--off': !visible }"
    >
      <o-button
        v-keyboard-shortcut="'Tab'"
        variant="secondary"
        class="px-3"
        :icon-left="visible ? 'chevron-left' : 'chevron-right'"
        icon-class="is-size-4"
        size="small"
        rounded
        @click="emit('toggle-visibility')"
      />
    </o-tooltip>

    <o-tabs
      v-model="tab"
      type="toggle"
      class="sidebar-tabs"
      :class="{
        'tabs-item--resources-rounded': !(isComparing || displayDiff)
      }"
      nav-tabs-class="tabs is-toggle-rounded is-justify-content-center"
      content-class="tab-content holori-scrollbar p-0"
    >
      <o-tab-item v-if="showElements" value="elements" label="Icons" icon="package-variant">
        <DiagramElements
          @add-node="emit('add-node', $event)"
          @stop-add-node="emit('stop-add-node')"
        />
      </o-tab-item>
      <o-tab-item value="resources" label="Assets" icon="list-box-outline">
        <DiagramResources ref="resourcesRef" />
      </o-tab-item>
      <o-tab-item
        :visible="isComparing || displayDiff"
        value="diff"
        label="Diff"
        icon="vector-difference"
      >
        <DiagramDiff ref="diffRef" @loaded="tab = 'diff'" @select="emit('select', $event)" />
      </o-tab-item>
    </o-tabs>
  </fieldset>
</template>

<style scoped>
.wrapper {
  border: 1px solid hsl(0, 0%, 86%);
  max-height: 70vh;
  top: 195px;
  left: 0;
  position: fixed;
  width: 22rem;
  z-index: 3;
  transition: transform 0.3s ease;

  --tabs-height: 42px;
}

.wrapper--invisible {
  transform: translateX(-100%);
}

.wrapper:not(:empty) {
  box-shadow: 5px 0 13px 3px rgba(10, 10, 10, 0.1);
}

.wrapper {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}
.toggle-menu {
  position: absolute;
  top: 50%;
  right: 0;
  transform: translate(50%, -50%);
  transition: transform 0.3s ease;
  z-index: 20;
}
.toggle-menu--off {
  transform: translate(100%, -50%);
}
</style>
