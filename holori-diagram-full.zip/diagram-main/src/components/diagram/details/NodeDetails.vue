<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OField, OIcon, OInput } from '@oruga-ui/oruga-next'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import ItemImage from './ItemImage.vue'

const name = ref('')
const image = ref(null)
const textBoxContent = ref('')
const type = ref('')
const location = ref('')
const locationDisplay = ref('')

const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { getSelectedNode } = storeToRefs(diagramStore)

watch(getSelectedNode, (newNode) => {
  load(newNode)
})

watch(name, (newName, oldName) => {
  if (newName !== oldName && oldName) {
    const cell = window.graph.getCell(getSelectedNode.value.id)
    cell.set('name', newName)
    cell.setLabel(newName)
  }
})

function load(node) {
  name.value = node.name
  image.value = node.image

  if (node.type === 'TextBox') {
    textBoxContent.value = node.notes
    type.value = 'TextBox'
  } else {
    const data = diagramStore.getData

    location.value = mappingStore.findFirstLocation(node.parent || node.groupId, data)

    locationDisplay.value = mappingStore.findFirstLocationForDisplay(
      node.parent || node.groupId,
      data
    )

    type.value = node.path?.split('/')[1]
  }
}

load(getSelectedNode.value)
</script>

<template>
  <div class="is-flex is-flex-direction-column">
    <ItemImage v-if="type !== 'TextBox'" :item="getSelectedNode" />
    <o-field v-if="type !== 'TextBox'" label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="rename" class="mr-2" />
        Name
      </template>
      <o-input v-model="name" type="text" placeholer="Node name" expanded />
    </o-field>

    <div v-if="location" class="is-flex is-align-items-center mb-3">
      <o-icon icon="map-marker" />
      <strong class="mx-2">Location:</strong>
      <span>
        {{ locationDisplay }}
      </span>
    </div>
  </div>
</template>
