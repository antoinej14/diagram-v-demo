<script setup>
import { ref, onMounted, nextTick, watch } from 'vue'
import { OField, OIcon, OInput, ONotification } from '@oruga-ui/oruga-next'
import { storeToRefs } from 'pinia'

import { pinIcon } from '@/common/diagram/options/shared'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

const emit = defineEmits(['update-name'])

const selectedLocation = ref('')
const disabled = ref(false)
const availableLocations = ref([])
const filteredLocations = ref([])

/** @var {Ref<HTMLInputElement>} */
const inputRef = ref(null)

const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { getSelectedGroup } = storeToRefs(diagramStore)

onMounted(() => {
  load(getSelectedGroup.value)
})

function load(group) {
  selectedLocation.value = group.location || ''
  // availableLocations.value = getRegions.value

  const findFirstProvider = (id) => {
    if (!id) {
      return ''
    }

    const model = window.graph.getCell(id).attributes
    const { provider, parent } = model

    if (provider) {
      return provider
    }

    if (parent) {
      return findFirstProvider(parent)
    }

    return ''
  }

  const { parent, path } = group

  let provider = findFirstProvider(parent)

  if (path) {
    provider = mappingStore.splitPath(path).providerName
  }

  if (provider) {
    availableLocations.value = availableLocations.value.filter(
      (locations) => locations.provider === provider
    )
  }

  nextTick(() => {
    filteredLocations.value = availableLocations.value
  })
}

/**
 * @param {String} location
 * @param {InputEvent} e
 */
function updateLocation(location, e) {
  const { graph } = window
  const { id } = getSelectedGroup.value

  const updateElement = (loc, img) => {
    const name = loc ? loc.providerValue : 'Location Group'

    const element = graph.getCell(id)
    element.set('location', loc ? loc.providerValue : '')
    element.set('provider', loc ? loc.providerName : undefined)
    element.set('image', img)
    element.set('name', name)
    element.attr('image/href', img)

    emit('update-name', name, true)
  }

  if (location === '') {
    updateElement('', pinIcon)
    return
  }

  const foundLocation = Array.from(document.querySelectorAll('#locations option[data-value]')).find(
    (option) => {
      return option.innerText.trim() === location.trim()
    }
  )

  if (!foundLocation) {
    return
  }

  location = foundLocation.getAttribute('data-value')

  // This is just regular typing.
  if (!location.startsWith('{') || !location.endsWith('}')) {
    return
  }

  const parsed = JSON.parse(location)
  if (!parsed) {
    return
  }

  if (parsed) {
    nextTick(() => {
      e.target.value = parsed.providerValue
    })
  }

  const updateImagePromise = new Promise((resolve) => {
    if (parsed) {
      resolve(`/diagram/${parsed.providerName}.svg`)
    } else {
      resolve(pinIcon)
    }
  })
  updateImagePromise.then((img) => {
    updateElement(parsed, img)
  })
}

watch(selectedLocation, (newLocation) => {
  if (newLocation === '') {
    updateLocation('', null)
  }
})
</script>

<template>
  <div>
    <datalist id="locations">
      <template v-for="group in mappingStore.regions" :key="group.provider">
        <option readonly>{{ group.provider }}</option>
        <option
          v-for="(region, index) in group.regions"
          :key="region.holoriValue"
          :data-value="JSON.stringify(region)"
        >
          &nbsp;&nbsp;
          {{ index !== group.regions.length - 1 ? '&#x251d;' : '&#x2517;' }}
          {{ region.providerValue }}
        </option>
      </template>
    </datalist>
    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="map-marker" class="mr-2" />
        Location
      </template>
      <o-input
        v-model="selectedLocation"
        ref="inputRef"
        type="text"
        list="locations"
        @input="updateLocation"
        clearable
        expanded
      />
    </o-field>
    <o-notification
      v-if="disabled"
      type="info"
      variant="info"
      icon-size="medium"
      class="py-2 px-3 mt-3"
    >
      You cannot edit the location for this group because one or some of its children also have
      location.
    </o-notification>
  </div>
</template>
