<script setup>
import { ref, computed, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OField, OIcon, OInput } from '@oruga-ui/oruga-next'

import { useProjectStore } from '@/store/project'
import { useDiagramStore } from '@/store/diagram'

import { debounce } from '@/common/utils'

const projectStore = useProjectStore()
const diagramStore = useDiagramStore()

const { project, readonly } = storeToRefs(projectStore)
const { getElementsNumber } = storeToRefs(diagramStore)

const projectName = ref(project.value.name)
const projectNotes = ref(project.value.notes)

const maximumElementsNumber = computed(() => {
  return 'Unlimited'
})

function formatDate(date) {
  const newDate = new Date(date)
  return newDate.toLocaleString()
}

const updateField = debounce((field, value) => {
  projectStore.setProject({
    ...this.project,
    [field]: value
  })
  diagramStore.setSaved(false)
}, 200)

watch(projectName, (val) => {
  projectStore.setProject({
    ...projectStore.project,
    name: val
  })
})
</script>

<template>
  <div class="project-details p-3 is-flex is-flex-direction-column">
    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="rename" class="mr-2" />
        Project Name
      </template>
      <o-input
        v-model="projectName"
        type="text"
        :disabled="readonly"
        @input="updateField('name', $event)"
        expanded
      />
    </o-field>

    <o-field class="mb-0" label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="rename" class="mr-2" />
        Project Description
      </template>
      <o-input
        v-model="projectNotes"
        type="textarea"
        :disabled="readonly"
        @input="updateField('notes', $event)"
        expanded
      />
    </o-field>

    <div class="mt-5">
      <div class="is-flex is-align-items-center mb-2">
        <o-icon icon="calendar-plus" />
        <strong class="mx-2"> {{ project.imported ? 'Imported' : 'Created' }}: </strong>
        {{ formatDate(project.imported || project.created) }}
      </div>
      <div v-if="project.last_modified" class="is-flex is-align-items-center mb-2">
        <o-icon icon="calendar-edit" />
        <strong class="mx-2">Last modification:</strong>
        {{ formatDate(project.last_modified) }}
      </div>
      <div class="is-flex is-align-items-center">
        <o-icon icon="counter" />
        <strong class="mx-2">Elements:</strong>
        <span
          v-if="isNaN(maximumElementsNumber)"
          class="tag is-primary is-flex is-align-items-center is-justify-content-center"
          :title="`You have ${getElementsNumber} elements in your diagram`"
        >
          Unlimited
          <o-icon icon="infinity" class="ml-1" size="small" />
        </span>
        <template v-else>
          {{ getElementsNumber }}/{{ maximumElementsNumber }}
          <progress
            class="ml-3 progress is-small is-primary"
            :value="getElementsNumber"
            :max="maximumElementsNumber"
          />
        </template>
      </div>
    </div>
  </div>
</template>

<style scoped>
.project-details {
  max-height: 70vh;
  overflow-y: scroll;
  scrollbar-color: var(--primary) #fff;
  scrollbar-width: thin;
}
</style>
