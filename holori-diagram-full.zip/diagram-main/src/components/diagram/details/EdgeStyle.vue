<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, OField, OSelect, OSwitch } from '@oruga-ui/oruga-next'

import { colors, arrowStyle } from '@/common/diagram/options/shared'
import { lineTypeOptions, lineStyleOptions } from '@/common/diagram/options/shapes/edge'

import { useDiagramStore } from '@/store/diagram'

const defaults = {
  lineType: 'linear',
  lineStyle: 'solid',
  lineColor: colors.text,
  animation: '',
  startArrow: false,
  endArrow: true
}

const attrs = {
  lineType: 'router',
  lineColor: 'line/stroke',
  lineStyle: 'line/stroke-dasharray',
  startArrow: 'line/sourceMarker',
  endArrow: 'line/targetMarker'
}

const lineType = ref(defaults.lineType)
const lineStyle = ref(defaults.lineStyle)
const lineColor = ref(defaults.lineColor)
const animation = ref('')
const startArrow = ref(defaults.startArrow)
const endArrow = ref(defaults.endArrow)

const cell = ref(null)

const diagramStore = useDiagramStore()

const { getSelectedEdge } = storeToRefs(diagramStore)

watch(getSelectedEdge, load, { deep: true })

function load() {
  lineType.value = getSelectedEdge.value.lineType || defaults.lineType
  lineStyle.value = getSelectedEdge.value.lineStyle || defaults.lineStyle
  lineColor.value = getSelectedEdge.value.lineColor || defaults.lineColor
  animation.value = getSelectedEdge.value.animation || defaults.animation
  startArrow.value = !!getSelectedEdge.value.startArrow || defaults.startArrow
  endArrow.value = !!getSelectedEdge.value.endArrow || defaults.endArrow

  // Save current cell.
  cell.value = window.graph.getCell(getSelectedEdge.value.id)
}

function update(style, value, attrValue) {
  const { id } = getSelectedEdge.value
  const { graph } = window

  const cell = graph.getCell(id)
  cell.set(style, value)
  cell.attr(attrs[style], attrValue || value)
}

function reset(style) {
  update(style, defaults[style])
  load()
}

watch(lineType, (value) => {
  cell.value.router(lineTypeOptions[value])
  update('lineType', value, lineTypeOptions[value])
})

watch(lineStyle, (value) => {
  update('lineStyle', value, lineStyleOptions[value])
})

watch(lineColor, (value) => {
  update('lineColor', value)
})

watch(startArrow, (value) => {
  update('startArrow', value, value ? arrowStyle : { d: '0 0 0 0' })
})

watch(endArrow, (value) => {
  update('endArrow', value, value ? arrowStyle : { d: '0 0 0 0' })
})

load()
</script>

<template>
  <div>
    <o-field label="Line Type">
      <o-select v-model="lineType" expanded>
        <option v-for="(_value, option) in lineTypeOptions" :key="option" :value="option">
          {{ option }}
        </option>
      </o-select>
      <o-button
        :disabled="lineType === defaults.lineType"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('borderStyle')"
      />
    </o-field>
    <o-field label="Line Style">
      <o-select v-model="lineStyle" expanded>
        <option v-for="(_value, option) in lineStyleOptions" :key="option" :value="option">
          {{ option }}
        </option>
      </o-select>
      <o-button
        :disabled="lineStyle === defaults.lineStyle"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('lineStyle')"
      />
    </o-field>
    <o-field label="Line Color">
      <input v-model="lineColor" type="color" class="input" />
      <o-button
        :disabled="lineColor === defaults.lineColor"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('lineColor')"
      />
    </o-field>
    <o-field label="Start Arrow">
      <o-switch v-model="startArrow" />
    </o-field>
    <o-field label="End Arrow">
      <o-switch v-model="endArrow" />
    </o-field>
  </div>
</template>
