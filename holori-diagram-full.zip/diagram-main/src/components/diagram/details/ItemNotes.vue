<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OField, OInput } from '@oruga-ui/oruga-next'

import { debounce } from '@/common/utils'

import { useDiagramStore } from '@/store/diagram'

const notes = ref('')

const diagramStore = useDiagramStore()

const { getSelectedAnything } = storeToRefs(diagramStore)

watch(getSelectedAnything, refreshNotes)
function refreshNotes() {
  notes.value = getSelectedAnything.value.notes
}

const updateNotes = debounce((newNotes) => {
  const { graph } = window
  const { id, duplicates } = getSelectedAnything.value

  // Update this item
  const item = graph.getCell(id)
  item.set('notes', newNotes)

  if (Array.isArray(duplicates)) {
    // Update duplicates
    for (const duplicateID of duplicates) {
      const duplicateItem = graph.getCell(duplicateID)
      duplicateItem.set('notes', newNotes)
    }
  }
}, 200)

refreshNotes()
</script>

<template>
  <o-field label="Notes">
    <o-input
      v-model="notes"
      type="textarea"
      placeholder="You can type what you like here"
      @input="updateNotes"
      expanded
    />
  </o-field>
</template>
