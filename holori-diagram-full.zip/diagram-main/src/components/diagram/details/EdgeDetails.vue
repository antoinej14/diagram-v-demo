<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OField, OIcon, OInput } from '@oruga-ui/oruga-next'

import { useDiagramStore } from '@/store/diagram'

import NodeLink from '@/components/diagram/NodeLink.vue'

const name = ref('')
const from = ref('')
const to = ref('')

const diagramStore = useDiagramStore()

const { getSelectedEdge: edge } = storeToRefs(diagramStore)

watch(edge, updateDetails, { deep: true })

watch(name, (newName, oldName) => {
  if (newName !== oldName && oldName) {
    const { graph } = window
    const { id } = edge.value

    const cell = graph.getCell(id)
    cell.set('name', newName)
    cell.attr('label', newName)
  }
})

function updateDetails() {
  const {
    source: { id: source },
    target: { id: target },
    name: edgeName
  } = edge.value
  const { graph } = window
  const sourceNode = graph.getCell(source)
  const targetNode = graph.getCell(target)

  if (!sourceNode || !targetNode) {
    return
  }

  name.value = edgeName

  const { attributes: sourceAttributes } = sourceNode
  const { attributes: targetAttributes } = targetNode
  from.value = sourceAttributes
  to.value = targetAttributes
}

if (edge.value) {
  updateDetails()
}
</script>

<template>
  <div class="is-flex is-flex-direction-column pt-3">
    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="rename" class="mr-2" />
        Name
      </template>
      <o-input v-model="name" type="text" placeholer="Edge name" expanded />
    </o-field>

    <div class="is-flex is-align-items-center">
      <div class="is-flex-grow-1 mr-3">
        <strong>From</strong>
        <NodeLink :model="from" @select="emit('select', $event)" />
      </div>
    </div>

    <div class="is-flex is-align-items-center">
      <div class="is-flex-grow-1 mr-3">
        <strong>To</strong>
        <NodeLink :model="to" @select="emit('select', $event)" />
      </div>
    </div>
  </div>
</template>
