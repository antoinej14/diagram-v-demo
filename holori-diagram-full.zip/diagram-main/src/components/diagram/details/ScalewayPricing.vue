<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OField, OIcon, ONotification, OSelect } from '@oruga-ui/oruga-next'

import { formatPrice } from '@/common/diagram/utils.js'
import scalewayPricingApi from '@/api/modules/public/scaleway-pricing'

import { useDiagramStore } from '@/store/diagram'

const DEFAULT_REGION = 'fr-par-1'

const diagramStore = useDiagramStore()

const { getSelectedNode } = storeToRefs(diagramStore)

const loading = ref(false)
const loadError = ref(false)
const pricing = ref([])

const instanceType = ref('')
const region = ref('')

const instanceTypes = computed(() => [...new Set(pricing.value.map((row) => row.instance_type))])

const regionsForInstanceType = computed(() => [
  ...new Set(
    pricing.value.filter((row) => row.instance_type === instanceType.value).map((row) => row.region)
  )
])

const selectedPricing = computed(() => {
  const matches = pricing.value.filter(
    (row) => row.instance_type === instanceType.value && row.region === region.value
  )
  if (!matches.length) {
    return null
  }
  // Scaleway compute pricing doesn't vary by OS, but the catalog can carry one
  // row per OS. Prefer Linux, fall back to whatever is available.
  return matches.find((row) => row.operating_system === 'Linux') || matches[0]
})

const hourlyPrice = computed(() => {
  const row = selectedPricing.value
  if (!row) {
    return null
  }
  return row.hourly_price_usd || (row.monthly_price_usd ? row.monthly_price_usd / 730 : null)
})

const monthlyPrice = computed(() => {
  const row = selectedPricing.value
  if (!row) {
    return null
  }
  return row.monthly_price_usd || (row.hourly_price_usd ? row.hourly_price_usd * 730 : null)
})

async function loadPricing() {
  loading.value = true
  loadError.value = false
  try {
    pricing.value = await scalewayPricingApi.getScalewayInstancePricing()
  } catch {
    loadError.value = true
  } finally {
    loading.value = false
  }
}

function load(node) {
  instanceType.value = node?.scalewayInstanceType || ''
  region.value = node?.scalewayRegion || ''
}

function save() {
  const { id } = getSelectedNode.value
  const cell = window.graph.getCell(id)
  cell.set('scalewayInstanceType', instanceType.value)
  cell.set('scalewayRegion', region.value)
}

watch(getSelectedNode, load)

watch(instanceType, () => {
  if (!regionsForInstanceType.value.includes(region.value)) {
    region.value = regionsForInstanceType.value.includes(DEFAULT_REGION)
      ? DEFAULT_REGION
      : regionsForInstanceType.value[0] || ''
  }
  save()
})

watch(region, save)

onMounted(loadPricing)
load(getSelectedNode.value)
</script>

<template>
  <div class="mb-3">
    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="currency-usd" class="mr-2" />
        Estimated pricing
      </template>
    </o-field>

    <o-notification v-if="loadError" variant="danger" :closable="false">
      Couldn't load Scaleway pricing data.
    </o-notification>

    <template v-else>
      <o-field label="Instance type">
        <o-select v-model="instanceType" :disabled="loading" expanded>
          <option value="">Select an instance type</option>
          <option v-for="type in instanceTypes" :key="type" :value="type">
            {{ type }}
          </option>
        </o-select>
      </o-field>

      <o-field v-if="instanceType" label="Region">
        <o-select v-model="region" :disabled="loading" expanded>
          <option v-for="r in regionsForInstanceType" :key="r" :value="r">
            {{ r }}
          </option>
        </o-select>
      </o-field>

      <div
        v-if="selectedPricing"
        class="has-background-white-ter is-flex is-flex-direction-column is-align-items-center is-border-radius-xl p-5"
      >
        <span class="is-size-4 has-text-weight-bold">
          {{ formatPrice(monthlyPrice, 'USD') }}/month
        </span>
        <span class="is-size-6">{{ formatPrice(hourlyPrice, 'USD') }}/hour</span>
        <span class="is-size-7 has-text-grey mt-2">
          {{ selectedPricing.vcpu }} vCPU · {{ selectedPricing.memory }} RAM
        </span>
      </div>
    </template>
  </div>
</template>
