<script setup>
import { ref, computed, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OIcon, OTooltip } from '@oruga-ui/oruga-next'

import { lowercaseKeys } from '@/common/diagram/utils'
import supported from '@/common/tfstate'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import ItemImage from '@/components/ItemImage.vue'

const props = defineProps({
  item: {
    type: Object,
    required: false,
    default: null
  },
  addDivider: {
    type: Boolean,
    required: false,
    default: false
  },
  flatten: {
    type: Boolean,
    required: false,
    default: true
  },
  hideImage: {
    type: Boolean,
    required: false,
    default: false
  }
})

const blue = '#3498db'
const orange = '#e67e22'
const green = '#2ecc71'
const red = '#e74c3c'
const purple = '#9b59b6'

const stateColors = {
  'vm creating': blue,

  // Idling
  idle: orange,
  'vm starting': orange,

  // Running
  running: green,
  'in-use': green,
  available: green,
  enabled: green,
  ready: green,
  active: green,
  'vm running': green,
  succeeded: green,

  // Stopped
  disabled: red,
  stopped: red,
  'vm stopping': red,
  'vm stopped': red,

  'vm deallocating': purple,
  'vm deallocated': purple
}

const fields = ref([])
const terraform = ref({})

const diagramStore = useDiagramStore()

const mappingStore = useMappingStore()

const { getSelectedItem } = storeToRefs(diagramStore)

const usedItem = computed(() => props.item || getSelectedItem.value)

watch(
  () => props.item,
  () => {
    load()
  },
  { deep: true }
)

function load() {
  const { providerName, productName } = mappingStore.splitPath(usedItem.value.path)

  terraform.value = flattenTerraform(usedItem.value)

  const product = `${providerName}/${productName}`

  if (Object.keys(supported).includes(product)) {
    fields.value = supported[product]
  }
}

function flattenTerraform(item) {
  const { terraform, name } = item

  return lowercaseKeys({
    name,
    ...terraform
  })
}

function getValue(key, computed, values, type) {
  const splitKey = key.toLowerCase().split('.')
  const firstKey = splitKey.shift()

  let value = terraform.value[firstKey]

  if (!value) {
    const snakeCase = firstKey
      .split(/\.?(?=[A-Z])/)
      .join('_')
      .toLowerCase()
    value = terraform.value[snakeCase]
  }

  for (const k of splitKey) {
    if (!value) {
      break
    }

    let newValue = value[isNaN(parseInt(k)) ? k : parseInt(k)]
    // Try with snake case.
    if (!newValue) {
      const snakeCase = k
        .split(/\.?(?=[A-Z])/)
        .join('_')
        .toLowerCase()
      newValue = value[snakeCase]
    }
    value = newValue
  }

  value = value || '#N/A?'

  if (computed) {
    if (typeof computed === 'function') {
      value = computed(value, terraform.value)
    } else {
      value = computed?.replace('$val', value) || value
    }
  }

  if (values) {
    value = values[value]
  }

  if (type === 'state') {
    value = value.toLowerCase()
  }

  return value
}

function getDateValue(key) {
  const val = getValue(key)
  const date = new Date(val)

  if (isNaN(date)) {
    return val
  }

  return date.toISOString()
}

function getStateColor(key) {
  const state = getValue(key).toLowerCase()
  return stateColors[state]
}

function displayIcon(type) {
  return type !== 'state' && type !== 'section'
}

function getEntries(field) {
  const { key, entries } = field
  const { id: idKey } = entries
  const value = getValue(key)

  if (value === '#N/A?') {
    return []
  }

  const values = Object.entries(value).map((entry) => entry[1])

  const final = !idKey ? values : []

  if (idKey) {
    for (const entry of values) {
      const splitKey = idKey.toLowerCase().split('.')
      let id = entry[splitKey.shift()]

      for (const k of splitKey) {
        if (!id) {
          break
        }

        id = id[k]
      }

      if (props.flatten) {
        const node = diagramStore.findById(id)

        if (node) {
          final.push(flattenTerraform(node))
        }
      }
    }
  }

  return final
}

load()
</script>

<template>
  <div :class="{ 'mb-5': fields.length && addDivider }">
    <template v-if="fields.length">
      <ItemImage v-if="!props.hideImage" :item="usedItem" disabled />

      <div :class="{ 'mb-5': $slots.default }">
        <slot />
      </div>

      <div
        v-for="(field, index) of fields"
        :key="field.key"
        class="is-flex is-align-items-center is-white-space-no-wrap"
        :class="{ 'mb-3': index < fields.length - 1 }"
      >
        <template v-if="field.type !== 'section'">
          <o-tooltip
            trigger-class="is-flex is-align-items-center"
            :label="field.name"
            position="right"
          >
            <o-icon v-if="displayIcon(field.type)" :icon="field.icon" class="mr-3" />
            <div v-else class="state mr-3" :style="{ backgroundColor: getStateColor(field.key) }" />
          </o-tooltip>
          <strong v-if="field.label" class="is-flex is-align-items-center">
            {{ field.name }}: &nbsp;
          </strong>
          <span
            v-if="
              field.type === 'simple' ||
              field.type === 'state' ||
              field.type === 'computed' ||
              field.type === 'boolean'
            "
            class="value"
            :class="{ 'is-capitalized': field.type === 'state' }"
          >
            {{ getValue(field.key, field.value, field.values, field.type) }}
          </span>
          <span v-if="field.type === 'date'" class="value">
            {{ getDateValue(field.key, field.value) }}
          </span>
          <template v-if="field.type === 'url'">
            <a :href="getValue(field.key)" title="Open in a new tab" class="value">
              {{ getValue(field.key) }}
            </a>
          </template>
        </template>
        <div v-else>
          <strong v-if="getEntries(field).length" class="is-block is-size-5 my-3">
            {{ field.name }}
          </strong>

          <div
            v-for="entry in getEntries(field)"
            :key="entry.id"
            class="is-flex is-align-items-center mb-5"
          >
            <img :src="`/diagram/${field.entries.icon}`" alt="Entry" class="entry-icon mr-3" />
            <div class="is-flex is-flex-direction-column">
              <span v-if="!field.entries.hideName" class="mb-3 value">{{ entry.name }}</span>

              <span
                v-for="subfield in field.entries.fields"
                :key="subfield.key"
                class="is-flex is-align-items-center mb-3 value"
              >
                <strong v-if="!subfield.icon"> {{ subfield.name }}: &nbsp; </strong>
                <o-tooltip
                  v-else
                  trigger-class="is-flex is-align-items-center"
                  :label="subfield.name"
                  position="right"
                >
                  <o-icon :icon="subfield.icon" class="mr-3" />
                </o-tooltip>
                <span class="value">
                  {{ entry[subfield.key.toLowerCase()] }}
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>

      <hr v-if="addDivider" />
    </template>
  </div>
</template>

<style scoped>
strong {
  color: inherit;
}
.state {
  border-radius: 12px;
  height: 24px;
  width: 24px;
}
.entry-icon {
  border-radius: 5px;
  max-height: 30px;
  width: 30px;
}
</style>
