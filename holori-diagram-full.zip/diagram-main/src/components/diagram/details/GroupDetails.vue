<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, OField, OIcon, OInput } from '@oruga-ui/oruga-next'

import { debounce } from '@/common/utils'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import NodeLink from '@/components/diagram/NodeLink.vue'
import GroupLocation from '@/components/diagram/details/GroupLocation.vue'
import ItemImage from '@/components/diagram/details/ItemImage.vue'

const emit = defineEmits(['add-duplicate'])

const groupName = ref('')
const location = ref('')
const isAddingDuplicate = ref(false)
const duplicates = ref([])

/** @var {Ref<ItemImage>} */
const itemImageRef = ref(null)

const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { getSelectedGroup, data } = storeToRefs(diagramStore)

watch(getSelectedGroup, (newGroup) => {
  update(newGroup)
})

function update(newGroup) {
  groupName.value = newGroup.name

  location.value = mappingStore.findFirstLocation(newGroup.id, data.value)
  duplicates.value = []

  if (Array.isArray(newGroup.duplicates)) {
    newGroup.duplicates.forEach((duplicate) => {
      const element = window.graph.getCell(duplicate).attributes
      duplicates.value.push(element)
    })
  }
}

const updateGroupName = debounce((name, reloadImage = false) => {
  const { graph } = window

  groupName.value = name

  // Update this item
  const cell = graph.getCell(getSelectedGroup.value.id)
  cell.set('name', name)
  cell.setLabel(name)

  if (Array.isArray(getSelectedGroup.value.duplicates)) {
    // Update duplicates
    getSelectedGroup.value.duplicates.forEach((duplicateID) => {
      const duplicateCell = graph.getCell(duplicateID)
      duplicateCell.set('name', name)
      duplicateCell.setLabel(name)
    })
  }

  if (reloadImage) {
    itemImageRef.value.load()
  }
}, 200)

function removeDuplicate() {
  const { graph } = window
  const { id } = getSelectedGroup.value

  graph.getCell(id).set('duplicates', null)

  getSelectedGroup.value.duplicates.forEach((duplicateID) => {
    const cell = graph.getCell(duplicateID)
    const model = cell.attributes

    const newDuplicates = [...model.duplicates].filter((itemID) => itemID !== id)
    cell.set('duplicates', newDuplicates)
  })

  duplicates.value = []
}

if (getSelectedGroup.value) {
  update(getSelectedGroup.value)
}
</script>

<template>
  <div class="is-flex is-flex-direction-column mb-3">
    <ItemImage ref="itemImageRef" :item="getSelectedGroup" />
    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="rename" class="mr-2" />
        Name
      </template>
      <o-input v-model="groupName" placeholder="Group name" @input="updateGroupName" expanded />
    </o-field>

    <o-field label-class="is-flex is-align-items-center">
      <template #label>
        <o-icon icon="circle-multiple-outline" class="mr-2" />
        Duplicates
      </template>
      <div class="is-flex is-flex-direction-column is-flex-1">
        <NodeLink v-for="duplicate in duplicates" :key="duplicate.id" :model="duplicate" />
        <o-button
          variant="primary"
          icon-left="plus-circle-multiple-outline"
          :disabled="isAddingDuplicate || !!getSelectedGroup.location"
          class="is-block full-width"
          @click="emit('add-duplicate')"
        >
          {{ isAddingDuplicate ? 'Press Esc to stop' : 'Add duplicate' }}
        </o-button>
        <o-button
          v-if="duplicates.length"
          variant="primary"
          class="mt-2 is-block full-width"
          icon-left="plus-circle-multiple-outline"
          @click="removeDuplicate"
        >
          Exclude from duplicate
        </o-button>
      </div>
    </o-field>
    <GroupLocation v-if="!duplicates.length" @update-name="updateGroupName" />
  </div>
</template>
