<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'

import NodeLink from '@/components/diagram/NodeLink.vue'

import { useDiagramStore } from '@/store/diagram'

const nodes = ref([])
const groups = ref([])

const diagramStore = useDiagramStore()

const { getSelectedItem } = storeToRefs(diagramStore)

watch(getSelectedItem, loadItems)

function loadItems() {
  if (!getSelectedItem.value || !getSelectedItem.value.id) {
    return
  }

  /**
   * @type {dia.ElementView} graph
   */
  const { graph } = window
  const item = graph.getCell(getSelectedItem.value.id)

  if (getSelectedItem.value.type === 'Group') {
    const children = item.getEmbeddedCells().map((child) => child.attributes)
    groups.value = children.filter((child) => child.type === 'Group')
    nodes.value = children.filter((child) => child.type === 'Node')
  } else {
    groups.value = []
    nodes.value = []
  }
}

loadItems()
</script>

<template>
  <div class="mt-3">
    <template v-if="groups.length">
      <label class="label"> Children groups </label>
      <NodeLink
        v-for="childGroup in groups"
        :key="childGroup.id"
        :model="childGroup"
        @select="$emit('select', $event)"
      />
    </template>

    <template v-if="nodes.length">
      <label class="label"> Children nodes </label>
      <NodeLink
        v-for="childNode in nodes"
        :key="childNode.id"
        :model="childNode"
        @select="$emit('select', $event)"
      />
    </template>
  </div>
</template>

<style scoped>
.label {
  font-weight: normal;
}
</style>
