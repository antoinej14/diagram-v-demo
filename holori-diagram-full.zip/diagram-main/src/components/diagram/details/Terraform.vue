<script setup>
import { useDiagramStore } from '@/store/diagram'

import TerraformDocumentationEntry from '@/components/diagram/export/TerraformDocumentationEntry.vue'

import TfState from './TfState.vue'

defineOptions({
  name: 'TerraformTab'
})

const diagramStore = useDiagramStore()
</script>

<template>
  <div class="pt-3">
    <TfState add-divider>
      <slot />
    </TfState>

    <TerraformDocumentationEntry
      v-for="(value, key) in diagramStore.getSelectedItem?.terraform"
      :key="`${diagramStore.getSelectedItem?.id}-${key}`"
      :field="key"
      :value="value"
      :node="diagramStore.getSelectedItem"
    />
  </div>
</template>
