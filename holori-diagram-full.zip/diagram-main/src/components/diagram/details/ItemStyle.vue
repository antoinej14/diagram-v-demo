<script setup>
import { ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, OField, OSelect } from '@oruga-ui/oruga-next'

import { defaultStyle } from '@/common/diagram/options/shared'

import { useDiagramStore } from '@/store/diagram'

const defaults = {
  borderStyle: 'solid',
  borderColor: defaultStyle.stroke,
  borderWidth: defaultStyle.lineWidth,
  backgroundColor: defaultStyle.fill
}

const borderStyleOptions = [
  {
    name: 'solid',
    value: 0
  },
  {
    name: 'dashed',
    value: 6
  },
  {
    name: 'dotted',
    value: 2
  }
]

const attrs = {
  borderStyle: ['shape/strokeDasharray'],
  borderColor: ['shape/stroke', 'labelBox/stroke'],
  borderWidth: ['shape/strokeWidth'],
  backgroundColor: ['shape/fill', 'labelBox/fill']
}

const borderStyle = ref(defaults.borderStyle)
const borderColor = ref(defaults.borderColor)
const borderWidth = ref(defaults.borderWidth)
const backgroundColor = ref(defaults.backgroundColor)

const diagramStore = useDiagramStore()

const { getSelectedAnything } = storeToRefs(diagramStore)

watch(getSelectedAnything, load)

function load() {
  const item = getSelectedAnything.value

  borderStyle.value = item.borderStyle || defaults.borderStyle
  borderColor.value = item.borderColor || defaults.borderColor
  borderWidth.value = item.borderWidth || defaults.borderWidth[item.type]
  backgroundColor.value = item.backgroundColor || defaults.backgroundColor
}

function updateBorderColor(e) {
  update('borderColor', e.target.value)
}

function updateBorderWidth(e) {
  update('borderWidth', parseInt(e.target.value, 10))
}

function updateBackgroundColor(e) {
  update('backgroundColor', e.target.value)
}

function updateBorderStyle(e) {
  update(
    'borderStyle',
    e.target.value,
    borderStyleOptions.find((o) => o.name === e.target.value).value
  )
}

function update(style, value, styleValue) {
  const { id, duplicates } = getSelectedAnything.value
  const { graph } = window

  // Find the cell
  const element = graph.getCell(id)
  // Set the style attribute
  element.set(style, value)

  // And apply the style
  for (const attr of attrs[style]) {
    element.attr(attr, styleValue !== undefined ? styleValue : value)
  }

  if (Array.isArray(duplicates)) {
    for (const duplicateID of duplicates) {
      // Find the cell
      const duplicateItem = graph.getCell(duplicateID)
      // Set the style attribute
      duplicateItem.set(style, value)

      // And apply the style
      for (const attr of attrs[style]) {
        duplicateItem.attr(attr, styleValue !== undefined ? styleValue : value)
      }
    }
  }
}

function reset(style) {
  update(style, defaults[style])
  load()
}

load()
</script>

<template>
  <div class="mt-5">
    <o-field label="Border Style">
      <o-select v-model="borderStyle" expanded @input="updateBorderStyle">
        <option v-for="option in borderStyleOptions" :key="option.name" :value="option.name">
          {{ option.name }}
        </option>
      </o-select>
      <o-button
        :disabled="borderStyle === defaults.borderStyle"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('borderStyle')"
      />
    </o-field>
    <o-field label="Border Color">
      <input v-model="borderColor" type="color" class="input" @input="updateBorderColor" />
      <o-button
        :disabled="borderColor === defaults.borderColor"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('borderColor')"
      />
    </o-field>
    <o-field label="Border Width">
      <input
        v-model="borderWidth"
        type="number"
        class="input"
        min="0"
        step="1"
        @input="updateBorderWidth"
      />
      <o-button
        :disabled="borderWidth == defaults.borderWidth"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('borderWidth')"
      />
    </o-field>
    <o-field label="Background Color">
      <input v-model="backgroundColor" type="color" class="input" @input="updateBackgroundColor" />
      <o-button
        :disabled="backgroundColor === defaults.backgroundColor"
        variant="primary"
        icon-left="lock-reset"
        title="Reset to default"
        @click="reset('backgroundColor')"
      />
    </o-field>
  </div>
</template>
