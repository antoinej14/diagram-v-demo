<script setup>
import { ref, computed } from 'vue'
import { OIcon } from '@oruga-ui/oruga-next'

import { getNodeMeta } from '@/common/diagram/options/shared'
import EventBus from '@/common/eventBus'

import { useDiagramStore } from '@/store/diagram'

const props = defineProps({
  name: {
    type: String,
    required: true
  },
  data: {
    type: [Array, Object],
    required: false,
    default: null
  },
  hasSearch: {
    type: Boolean,
    required: true
  },
  level: {
    type: Number,
    required: true
  },
  path: {
    type: String,
    required: true
  },
  selectedCompanies: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['add-node'])

const expanded = ref(false)

const diagramStore = useDiagramStore()

const image = computed(() => `/diagram/diagram/${props.path.replace(/\./g, '/')}.svg`)

const entries = computed(() => {
  const entriesObj = {}

  if (!Array.isArray(props.data) || props.name === props.data[0].name) {
    return {}
  }

  for (const entry of props.data) {
    const [name, value] = entry.name.replace(props.path + '.', '').split('.', 2)

    if (value === undefined) {
      entriesObj[name] = entry
      continue
    }

    if (!(name in entriesObj)) {
      entriesObj[name] = []
    }

    entriesObj[name].push(entry)
  }

  return entriesObj
})

const hasEntries = computed(() => Object.keys(entries.value).length > 0)

const sortedEntries = computed(() => {
  const withEntries = Object.keys(entries.value)
    .filter((entry) => entry.split('.').length > props.level)
    .sort()
  const withoutEntries = Object.keys(entries.value)
    .filter((entry) => entry.split('.').length <= props.level)
    .sort()
  return [...withEntries, ...withoutEntries]
})

function mouseDown(event) {
  if (event) {
    event.preventDefault()

    // Not left click? Stop.
    if (event.buttons !== 1) {
      return
    }
  }

  if (hasEntries.value) {
    return
  }

  const path = '/' + props.path.replace(/\./g, '/')

  getNodeMeta(
    path,
    (obj) => {
      const node = {
        type: 'custom',
        path,
        name: props.name.split('.').pop(),
        terraform_path: ''
      }

      emitAddNode({
        ...node,
        ...obj
      })
    },
    (terraformPath) => {
      diagramStore.getTerraformFields(terraformPath)
    }
  )
}

function emitAddNode(node) {
  emit('add-node', node)
}

function mouseUp() {
  if (!hasEntries.value) {
    EventBus.dispatch('displayAddNode')
  } else {
    expanded.value = !expanded.value
  }
}

/**
 * Replace the failed-to-load image by an appropriate one.
 * @param {ErrorEvent} e The ErrorEvent for the image that failed to load.
 */
function switchToDefaultImage(e) {
  e.target.src = '/diagram/holori/logo.svg'
}
</script>
<template>
  <li>
    <a
      class="is-flex is-justify-content-space-between is-align-items-center pr-0"
      :class="{ [`is-active is-active--${level}`]: expanded }"
      @mousedown="mouseDown"
      @mouseup="mouseUp"
    >
      <img :src="image" class="entry-icon" lazy @error="switchToDefaultImage" />
      <span class="is-flex-grow-1 mx-3 ellipsis" :class="{ 'is-capitalized': level === 0 }">
        {{ name }}
      </span>
      <o-icon
        v-if="hasEntries"
        class="is-pulled-right"
        :icon="expanded ? 'chevron-up' : 'chevron-down'"
      />
    </a>
    <Transition name="slide">
      <ul v-if="expanded || hasSearch" :class="`menu-list menu-list--${level} mt-0 mr-0`">
        <ElementsGroup
          v-for="entryName in sortedEntries"
          :key="entryName"
          :level="level + 1"
          :name="entryName"
          :has-search="hasSearch"
          :data="entries[entryName]"
          :path="path + '.' + entryName"
          :selected-companies="selectedCompanies"
          @add-node="emitAddNode"
        />
      </ul>
    </Transition>
  </li>
</template>

<style scoped>
.entry-icon {
  border-radius: 5px;
  height: 30px;
  width: 30px;
}
.menu-list--0 {
  border-left-color: #5a40ec;
}
.menu-list--1 {
  border-left-color: #5a40eccc;
}
.menu-list--2 {
  border-left-color: #5a40ec99;
}
.menu-list--3 {
  border-left-color: #5a40ec66;
}
.menu-list--4 {
  border-left-color: #5a40ec33;
}
.menu-list a.is-active--0 {
  background-color: #5a40ec;
}
.menu-list a.is-active--1 {
  background-color: #5a40eccc;
}
.menu-list a.is-active--2 {
  background-color: #5a40ec99;
}
.menu-list a.is-active--3 {
  background-color: #5a40ec66;
}
.menu-list a.is-active--4 {
  background-color: #5a40ec33;
}
</style>
