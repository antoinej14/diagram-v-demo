import { ref } from 'vue'
import { useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import { elementTools, dia, ui, g, linkTools } from '@joint/plus'

import Node from '@/common/diagram/options/shapes/node'
import Group from '@/common/diagram/options/shapes/group'
import Edge from '@/common/diagram/options/shapes/edge'
import TextBox from '@/common/diagram/options/shapes/textbox'
import { resizeGroup } from '@/common/diagram/options/methods/layout'
import { useMixins } from '@/common/mixins'
import { useOrganizationMembership } from '@/common/organization-membership.js'

import { useDiagramStore } from '@/store/diagram'
import { useProviderAccountsStore } from '@/store/provider-accounts'

import { useZoom } from './zoom'

function calculateGroupSize(group) {
  let minX, minY, maxX, maxY
  const children = group.getEmbeddedCells()

  for (const child of children) {
    const bbox = child.getBBox()
    const { x, y } = bbox
    if (minX === undefined || x < minX) {
      minX = x
    }
    if (minY === undefined || y < minY) {
      minY = y
    }

    const corner = bbox.corner()
    if (maxX === undefined || corner.x > maxX) {
      maxX = corner.x
    }
    if (maxY === undefined || corner.y > maxY) {
      maxY = corner.y
    }
  }

  const x = minX - (minX < 0 ? -20 : 20)
  const y = minY - 40
  const padding = 10
  const width = Math.max(maxX + padding * 2 - x, 60)
  const height = Math.max(maxY + padding * 2 - y, 60)

  return { x, y, width, height }
}

const resizeGroupButton = elementTools.Button.extend({
  name: 'info-button',
  options: {
    markup: [
      {
        tagName: 'circle',
        selector: 'button',
        attributes: {
          fill: '#ffffff',
          r: 15,
          cursor: 'pointer'
        }
      },
      {
        tagName: 'path',
        selector: 'icon',
        attributes: {
          d: 'M19.5,3.09L15,7.59V4H13V11H20V9H16.41L20.91,4.5L19.5,3.09M4,13V15H7.59L3.09,19.5L4.5,20.91L9,16.41V20H11V13H4Z',
          fill: '#000000',
          stroke: 'none',
          transform: 'translate(-12.5,-12.5)',
          'pointer-events': 'none'
        }
      }
    ],
    x: '100%',
    y: '100%',
    offset: {
      x: -15,
      y: -15
    },
    rotate: true,
    action() {
      resizeGroup(this.model)
    }
  }
})

export const useInitDiagram = ({ canvasRef, contextMenu, zoomIn, zoomOut, selectionChanged }) => {
  const { toast } = useMixins()

  const diagramStore = useDiagramStore()

  const { getSelectedGroup, getGlobalSelectionCount } = storeToRefs(diagramStore)

  function initDiagram() {
    const namespace = { Edge, Node, Group, TextBox }
    const graph = new dia.Graph(
      {},
      {
        cellNamespace: namespace
      }
    )
    window.graph = graph

    const canvas = canvasRef.value
    const { offsetWidth, offsetHeight } = canvas

    const paper = new dia.Paper({
      model: graph,
      gridSize: 10,
      frozen: true,
      async: true,
      sorting: dia.Paper.sorting.APPROX,
      embeddingMode: true,
      width: offsetWidth,
      height: offsetHeight,
      validateEmbedding(childView, parentView) {
        if (window.lockedMode) {
          return false
        }
        const model = parentView.model
        return model.get('type') === 'Group'
      },
      frontParentOnly: false,
      cellViewNamespace: namespace
    })
    window.paper = paper

    const scroller = new ui.PaperScroller({
      paper,
      autoResizePaper: true,
      cursor: 'grab',
      width: offsetWidth,
      height: offsetHeight,
      contentOptions: {
        minWidth: offsetWidth,
        minHeight: offsetHeight
      }
    })
    window.scroller = scroller

    window.stencil = new ui.Stencil({
      paper: scroller
    })

    scroller.render()

    const commandManager = new dia.CommandManager({ graph })
    commandManager.on('stack', () => {
      diagramStore.setCanUndo(commandManager.hasUndo())
      diagramStore.setCanRedo(commandManager.hasRedo())
    })
    window.commandManager = commandManager
    window.clipboard = new ui.Clipboard({ useLocalStorage: false })

    const selection = new ui.Selection({
      theme: 'material',
      paper,
      useModelGeometry: true,
      filter: (el) => el.isEmbedded(),
      handles: []
    })
    window.selection = selection

    const updateSelection = () => {
      const newSelection = selection.collection.toArray().map((item) => item.attributes)
      const groups = []
      const nodes = []
      const edges = []

      for (const item of newSelection) {
        const { type } = item
        if (type === 'Group') {
          groups.push(item)

          if (Array.isArray(item.duplicates)) {
            for (const duplicate of item.duplicates) {
              const node = window.graph.getCell(duplicate)
              selection.collection.add(node)
            }
          }
        } else if (type === 'Node' || type === 'TextBox') {
          nodes.push(item)
        } else {
          edges.push(item)
        }
      }

      diagramStore.clearUniqueSelection()
      diagramStore.setSelection({ groups, nodes, edges })
      typeof selectionChanged === 'function' && selectionChanged({ groups, nodes })
    }
    selection.collection.on('reset', updateSelection)
    selection.collection.on('add', updateSelection)

    const verticesTool = new linkTools.Vertices()
    window.linkToolsView = new dia.ToolsView({
      tools: [verticesTool]
    })

    /**
     * When clicking on the canvas
     */
    paper.on('blank:pointerdown', (e) => {
      const {
        originalEvent: { shiftKey }
      } = e

      if (contextMenu) {
        contextMenu.value.visible = false
      }

      if (shiftKey) {
        selection.startSelecting(e)
      } else {
        scroller.startPanning(e)
      }
    })
    paper.on('blank:mouseleave', (e) => {
      scroller.stopPanning(e)
    })
    paper.on('blank:pointerclick', () => {
      selection.collection.reset()

      if (window.freeTransform) {
        window.freeTransform.remove()
      }

      if (window.resizeButton) {
        window.resizeButton.remove()
        window.resizeButton = null
      }
    })
    paper.on('cell:pointerdown', (cellView, event) => {
      if (window.lockedMode || event.originalEvent.ctrlKey) {
        paper.setInteractivity(false)
        scroller.startPanning(event)
      }
    })
    paper.on('cell:pointerup', () => {
      // Restore interactivity
      if (!window.lockedMode) {
        paper.setInteractivity(true)
      }
    })

    paper.on('element:pointerclick', (element, event) => {
      const { newEdge, addingDuplicate } = window
      const { model } = element
      const {
        originalEvent: { shiftKey }
      } = event

      if (!newEdge) {
        if (shiftKey) {
          if (selection.collection.has(model)) {
            selection.collection.remove(model)
          } else {
            selection.collection.add(model)
          }
        } else {
          if (addingDuplicate) {
            if (addingDuplicate !== model.id) {
              finishAddDuplicate(model.id)
            }
          } else {
            selection.collection.reset([model])
          }
        }
      } else {
        if (element.model.id !== newEdge.source().id) {
          newEdge.target(element.model)
          window.commandManager.storeBatchCommand()
          element.unhighlight()
          newEdge.findView(paper).addTools(window.linkToolsView)
          window.newEdge = null
        }
      }
    })
    paper.on('link:mouseenter', (linkView, event) => {
      if (event.originalEvent.shiftKey) {
        linkView.showTools()
      } else {
        linkView.hideTools()
      }
    })
    paper.on('link:pointerclick', (linkView) => {
      selection.collection.reset([linkView.model])
    })

    paper.on('cell:mouseenter', (cellView) => {
      const { newEdge, addingDuplicate } = window
      const elementID = cellView.model.id

      if (newEdge) {
        const sourceID = newEdge.source().id

        if (sourceID !== elementID) {
          cellView.highlight()
        }
      }
      if (addingDuplicate) {
        if (addingDuplicate !== elementID) {
          cellView.highlight()
        }
      }
    })

    // Initialising the various helper variables
    window.newEdge = null
    window.newElement = null
    window.newElementMoves = 0
    window.freeTransform = null
    window.resizeButton = null
    window.resizeMode = false

    paper.on('element:pointerup', (cellView) => {
      const { newEdge, newElement, lockedMode } = window
      if (!newEdge && !newElement && !lockedMode) {
        // Do not transform links
        if (!(cellView.model instanceof Group)) {
          return
        }

        const { width, height } = calculateGroupSize(cellView.model)

        window.freeTransform = new ui.FreeTransform({
          cellView,
          minWidth: width,
          minHeight: height,
          allowRotation: false
        })
        // selection.collection.reset()
        window.freeTransform.render()

        if (cellView.model.attributes.type === 'Group') {
          if (window.resizeButton) {
            window.resizeButton.remove()
          }

          window.resizeButton = new dia.ToolsView({
            tools: [new resizeGroupButton()]
          })
          cellView.addTools(window.resizeButton)
        }
      }
    })

    paper.on('cell:mouseleave', (cellView) => {
      const { newEdge, addingDuplicate } = window
      if (newEdge || addingDuplicate) {
        cellView.unhighlight()
      }
    })

    if (zoomIn && zoomOut) {
      canvas.addEventListener('wheel', (e) => {
        const { wheelDelta } = e
        const { x, y } = paper.clientToLocalPoint(e.clientX, e.clientY)
        if (wheelDelta < 0) {
          zoomOut(x, y)
        } else {
          zoomIn(x, y)
        }
      })
    }

    scroller.lock()
    canvas.appendChild(scroller.el)
  }

  function finishAddDuplicate(newDuplicateID) {
    const group = getSelectedGroup.value
    const { graph, paper } = window
    const duplicatesSet = Array.isArray(group.duplicates) ? new Set(group.duplicates) : new Set()
    const newDuplicate = graph.getCell(newDuplicateID)
    newDuplicate.findView(paper).unhighlight()

    if (newDuplicate.location) {
      toast({
        message: 'You cannot use a group that has a location as a duplicate.',
        variant: 'danger'
      })

      return
    }

    const newDuplicateId = newDuplicate.id
    const newDuplicateDuplicates = Array.isArray(newDuplicate.duplicates)
      ? new Set(newDuplicate.duplicates)
      : new Set()

    // Add the new duplicate
    duplicatesSet.add(newDuplicateId)

    // Add all the previous duplicates
    newDuplicateDuplicates.forEach((duplicateId) => {
      duplicatesSet.add(duplicateId)
    })

    // Update the selection to reflect changes
    diagramStore.setSelection({
      groups: [
        {
          ...group,
          duplicates: Array.from(duplicatesSet)
        }
      ],
      nodes: [],
      edges: []
    })

    // Then add the ID of the selected group
    duplicatesSet.add(group.id)

    // Update all the groups
    const { image, name } = group
    duplicatesSet.forEach((id) => {
      // Create a new Set
      const duplicates = new Set(duplicatesSet)
      // Remove the ID of this group
      duplicates.delete(id)
      // Update the group
      const thisDuplicateCell = graph.getCell(id)
      thisDuplicateCell.set('name', name)
      thisDuplicateCell.set('image', image)
      thisDuplicateCell.set('duplicates', Array.from(duplicates))

      thisDuplicateCell.setLabel(name)

      if (image) {
        thisDuplicateCell.attr('image/href', image)
      }
    })

    window.addingDuplicate = null
  }

  function initEditEvents() {
    window.addEventListener('mousemove', mouseMove)
    window.addEventListener('keydown', keyDown)

    if (contextMenu) {
      window.addEventListener('contextmenu', showContextMenu)
    }
  }

  function removeEvents() {
    window.removeEventListener('mousemove', mouseMove)
    window.removeEventListener('keydown', keyDown)

    if (contextMenu) {
      window.removeEventListener('contextmenu', showContextMenu)
    }
  }

  function mouseMove(e) {
    const { newEdge, newElement, newEdgeOriginal } = window
    if (newEdge) {
      const { x: originalX, y: originalY } = newEdgeOriginal
      const { x, y } = window.paper.clientToLocalPoint(new g.Point(e.clientX, e.clientY))
      window.newElementMoves++
      newEdge.target(new g.Point(x - (x > originalX ? 10 : -10), y - (y > originalY ? 10 : -10)))
    } else if (newElement) {
      const { x, y } = window.paper.clientToLocalPoint(new g.Point(e.clientX, e.clientY))
      newElement.position(x, y)
    }
  }

  function keyDown(e) {
    if (e.key === 'Escape') {
      const { newEdge, newElement } = window
      if (newEdge) {
        newEdge.remove()
        window.newEdge = null
      }
      if (newElement) {
        newElement.remove()
        window.newElement = null
      }
    }
  }

  function showContextMenu(e) {
    const { clientX: x, clientY: y } = e
    contextMenu.value.position = { x, y }
    contextMenu.value.visible = true

    const localPoint = window.paper.clientToLocalPoint(x, y)
    const cells = window.paper
      .findViewsFromPoint(localPoint)
      .map((view) => view.model)
      .sort((cellA, cellB) => (cellA.attributes.z > cellB.attributes.z ? -1 : 1))

    if (cells.length) {
      const item = cells[0]
      contextMenu.value.item = item

      if (!getGlobalSelectionCount.value) {
        window.selection.collection.reset([item])
      }
    }
  }

  return {
    initDiagram,
    initEditEvents,
    removeEvents
  }
}

export const initOneDiagram = ({ number, canvas, zoomIn, zoomOut }) => {
  // Clear the paper in window.
  window.paper = null

  const diagramStore = useDiagramStore()

  const namespace = { Edge, Node, Group, TextBox }
  const graph = new dia.Graph(
    {
      number
    },
    {
      cellNamespace: namespace
    }
  )
  window[`graph${number}`] = graph

  const paper = new dia.Paper({
    model: graph,
    gridSize: 10,
    async: true,
    sorting: dia.Paper.sorting.APPROX,
    interactive: false,
    cellViewNamespace: namespace
  })
  window[`paper${number}`] = paper

  const { offsetWidth, offsetHeight } = canvas

  const scroller = new ui.PaperScroller({
    paper,
    cursor: 'grab',
    width: offsetWidth,
    height: offsetHeight
  })
  window[`scroller${number}`] = scroller

  scroller.render()

  const selection = new ui.Selection({
    theme: 'material',
    paper,
    useModelGeometry: true,
    filter: (el) => el.isEmbedded(),
    handles: []
  })

  const updateSelection = () => {
    const newSelection = selection.collection.toArray().map((item) => item.attributes)
    const groups = []
    const nodes = []
    const edges = []

    for (const item of newSelection) {
      const { type } = item
      if (type === 'Group') {
        groups.push(item)
      } else if (type === 'Node' || type === 'TextBox') {
        nodes.push(item)
      } else {
        edges.push(item)
      }
    }

    diagramStore.setSelection({ groups, nodes, edges })
  }
  selection.collection.on('reset', updateSelection)
  selection.collection.on('add', updateSelection)

  window[`selection${number}`] = selection

  canvas.addEventListener('wheel', (e) => {
    const { wheelDelta } = e
    const { x, y } = paper.clientToLocalPoint(e.clientX, e.clientY)

    if (wheelDelta < 0) {
      zoomOut(x, y, number)
    } else {
      zoomIn(x, y, number)
    }
  })

  paper.on('cell:pointerdown', (cellView, event) => {
    scroller.startPanning(event)
  })
  paper.on('blank:pointerdown', (event) => {
    scroller.startPanning(event)
  })
  paper.on('blank:pointerup', () => {
    selection.collection.reset()
  })

  paper.on('element:pointerup', (elementView) => {
    selection.collection.reset([elementView.model])
    window.graph = graph
    window.paper = paper
  })

  scroller.lock()
  canvas.appendChild(scroller.el)
}

export const useProviderAccountDiagrams = (canvases) => {
  const route = useRoute()
  const { toast } = useMixins()
  const { zoomIn, zoomOut } = useZoom()

  const { organizationID } = useOrganizationMembership(false)
  const providerID = Number(route.params.providerID)

  const entryA = ref({
    date: '',
    diagram: '',
    didLayout: false
  })
  const entryB = ref({
    date: '',
    diagram: '',
    didLayout: false
  })
  const loading = ref({
    canvas1: true,
    canvas2: true
  })

  const providerAccountsStore = useProviderAccountsStore()

  function setEntry(entry, obj) {
    if (entry === 'A') {
      entryA.value = obj
    } else {
      entryB.value = obj
    }
  }

  function initDiagrams() {
    initOneDiagram({
      number: 1,
      canvas: canvases.value.canvas1,
      zoomIn,
      zoomOut
    })
    initOneDiagram({
      number: 2,
      canvas: canvases.value.canvas2,
      zoomIn,
      zoomOut
    })

    const { a, b } = route.query

    const notFound = () => {
      toast({
        variant: 'warning',
        message: 'Could not get history entry.'
      })
    }

    if (a) {
      providerAccountsStore
        .getSynchronization(organizationID, providerID, Number(a))
        .then((sync) => {
          const { id, imported: date, thumbnail } = sync

          providerAccountsStore
            .getSynchronizationDiagram(organizationID, providerID, id)
            .then((diagram) => {
              setEntry('A', {
                id,
                date,
                diagram,
                didLayout: thumbnail !== undefined
              })
            }, notFound)
        }, notFound)
    }
    if (b) {
      providerAccountsStore
        .getSynchronization(organizationID, providerID, Number(b))
        .then((sync) => {
          const { id, imported: date, thumbnail } = sync

          providerAccountsStore
            .getSynchronizationDiagram(organizationID, providerID, id)
            .then((diagram) => {
              setEntry('B', {
                id,
                date,
                diagram,
                didLayout: thumbnail !== undefined
              })
            }, notFound)
        }, notFound)
    }

    // No entries, try to get the first two
    if (!a || !b) {
      providerAccountsStore.getSynchronizations(organizationID, providerID).then((entries) => {
        if (entries.length < 2) {
          toast({
            variant: 'info',
            message: 'Your account does not have history yet.'
          })

          loading.value.canvas1 = false
          loading.value.canvas2 = false
        } else {
          const [lastEntry, previousEntry] = entries
          providerAccountsStore
            .getSynchronizationDiagram(organizationID, providerID, lastEntry.id)
            .then((diagram) => {
              const { imported: date, thumbnail } = lastEntry
              setEntry('B', {
                id: lastEntry.id,
                date,
                diagram,
                didLayout: thumbnail !== undefined
              })
            })

          if (previousEntry) {
            providerAccountsStore
              .getSynchronizationDiagram(organizationID, providerID, previousEntry.id)
              .then((diagram) => {
                const { imported: date, thumbnail } = previousEntry
                setEntry('A', {
                  id: previousEntry.id,
                  date,
                  diagram,
                  didLayout: thumbnail !== undefined
                })
              })
          }
        }
      })
    }
  }

  return { initDiagrams, setEntry, entryA, entryB, loading }
}
