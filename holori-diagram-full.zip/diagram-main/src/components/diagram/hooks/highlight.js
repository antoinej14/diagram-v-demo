import { useRoute } from 'vue-router'
import { highlighters } from '@joint/plus'

import { useZoom } from '@/components/diagram/hooks/zoom.js'

export function useHighlight(loadingRef, reverseLoading = false) {
  const route = useRoute()
  const { zoomToFit, focusElement } = useZoom()

  const { region, resource } = route.query

  function toggleCell(cell, display, embed = false) {
    cell.attr('./display', display)

    if (embed) {
      const children = cell.getEmbeddedCells()
      for (const child of children) {
        toggleCell(child, display, embed)
      }
    }
  }

  function removeHighlight() {
    const cells = window.graph.getCells()

    for (const cell of cells) {
      toggleCell(cell, 'block')
    }
  }

  function highlight() {
    const { graph, paper } = window

    let foundCell

    const cells = graph.getCells()

    if (region) {
      foundCell = cells.find(
        ({ attributes }) =>
          attributes.location === region || attributes.location?.startsWith(region)
      )
    } else if (resource) {
      foundCell = cells.find(
        ({ attributes }) =>
          attributes.id?.startsWith(resource) ||
          attributes.id?.includes(resource) ||
          resource.includes(attributes.id) ||
          resource.includes(attributes.name) ||
          attributes.name?.includes(resource)
      )
    }

    if (foundCell) {
      toggleCell(foundCell, 'block', true)

      highlighters.mask.add(foundCell.findView(paper), { selector: 'root' }, 'highlight')
    }

    setTimeout(() => {
      if (foundCell) {
        focusElement(foundCell)
      } else {
        zoomToFit()
      }
      loadingRef.value = reverseLoading
    }, 500)
  }

  return { highlight, removeHighlight }
}
