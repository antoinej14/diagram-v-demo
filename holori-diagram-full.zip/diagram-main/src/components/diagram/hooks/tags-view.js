import { ref } from 'vue'
import { elementTools, dia, g } from '@joint/plus'

import { colors } from '@/common/diagram/options/shared'
import EventBus from '@/common/eventBus'

const highlighter = {
  name: 'stroke',
  options: {
    padding: 10,
    rx: 5,
    ry: 5,
    attrs: {
      stroke: colors.added,
      strokeWidth: 4,
      fill: colors.added,
      opacity: 0.5
    }
  }
}

function extractTags(model) {
  const { path, terraform } = model
  if (!terraform) {
    return []
  }
  if (path.startsWith('/aws')) {
    const tags = terraform.tags || terraform.Tags

    if (Array.isArray(tags)) {
      return tags.map(({ Key: key, Value: value }) => ({ key, value }))
    }
  } else if (path.startsWith('/gcp')) {
    const tags = terraform.labels

    if (tags !== undefined) {
      return Object.keys(tags).map((key) => ({ key, value: tags[key] }))
    }
  } else if (path.startsWith('/azure')) {
    const tags = terraform.tags

    if (tags !== undefined) {
      return Object.keys(tags).map((key) => ({ key, value: tags[key] }))
    }
  }
  return []
}

let tagsToolView = []

const tagLabel = elementTools.Button.extend({
  name: 'tag-label',
  options: {
    markup: [
      {
        tagName: 'rect',
        selector: 'box',
        attributes: {
          fill: '#5a40ec',
          width: 60,
          height: 25,
          rx: 5
        }
      },
      {
        tagName: 'text',
        selector: 'cost',
        attributes: {
          fill: '#ffffff',
          textAnchor: 'end',
          transform: 'translate(50,17)'
        }
      }
    ],
    x: '100%',
    y: '0%',
    offset: {
      x: -50,
      y: -15
    },
    rotate: true,
    action() {
      EventBus.dispatch('tags-label-clicked', this.model.attributes.id)
    }
  }
})

export function useTagsViews() {
  const keysValues = ref({})
  const resourcesTags = ref({})

  let cells = []

  function initTags() {
    cells = window.graph.getCells()

    const elements = cells
      .filter(({ attributes: { path } }) => path !== undefined && path !== '')
      .map(({ attributes }) => attributes)

    for (const element of elements) {
      const { id } = element
      const tags = extractTags(element)
      resourcesTags.value[id] = tags

      for (const tag of tags) {
        const { key, value } = tag

        if (value === '') {
          continue
        }

        if (!(key in keysValues.value)) {
          keysValues.value[key] = {}
        }
        if (!(value in keysValues.value[key])) {
          keysValues.value[key][value] = []
        }

        keysValues.value[key][value].push(id)
      }
    }
  }

  function displayTags() {
    for (const id in resourcesTags.value) {
      const tags = resourcesTags.value[id]

      if (tags.length) {
        const tool = new tagLabel()
        const view = new dia.ToolsView({
          tools: [tool]
        })
        const cell = window.graph.getCell(id)
        if (cell) {
          cell.findView(window.paper).addTools(view)
          tagsToolView.push({
            id,
            view
          })
          setTimeout(() => {
            tool.el.children[1].innerHTML = tags.length + ' tag' + (tags.length > 1 ? 's' : '')
          }, 50)
        }
      }
    }
  }

  function hideTags() {
    for (const tool of tagsToolView) {
      window.graph.getCell(tool.id).findView(window.paper).removeTools()
    }
  }

  function highlight(current, previous) {
    const { paper } = window
    const { key: currentKey, value: currentValue } = current
    const { key: previousKey, value: previousValue } = previous

    if (previousKey && previousValue) {
      const ids = keysValues.value[previousKey][previousValue]

      for (const id of ids) {
        const found = cells.find(({ attributes }) => attributes.id === id)

        if (found) {
          found.findView(paper).unhighlight(null, { highlighter })
        }
      }
    }

    if (currentKey && currentValue) {
      for (const cell of cells) {
        cell.attr('./opacity', 0.1)
      }

      const ids = keysValues.value[currentKey][currentValue]

      const rects = []

      for (const id of ids) {
        const found = cells.find(({ attributes }) => attributes.id === id)

        if (found) {
          found.attr('./opacity', 1)
          found.findView(paper).highlight(null, { highlighter })
          rects.push(found.getBBox())
        }
      }

      window.scroller.zoomToRect(g.Rect.fromRectUnion(...rects), {
        padding: 20,
        maxScale: 1
      })
    } else {
      for (const cell of cells) {
        cell.attr('./opacity', 1)
      }
    }
  }

  return { initTags, keysValues, resourcesTags, displayTags, hideTags, highlight }
}
