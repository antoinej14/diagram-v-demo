import { onBeforeUnmount, onMounted } from 'vue'
import { elementTools, dia } from '@joint/plus'
import { useOruga } from '@oruga-ui/oruga-next'

import EventBus from '@/common/eventBus.js'

import ElementCostModal from '@/components/modal/ElementCost.vue'

let costToolsView = []

const LABEL_WIDTH = 120
const LABEL_HEIGHT = 28

const costLabel = elementTools.Button.extend({
  name: 'info-button',
  options: {
    markup: [
      {
        tagName: 'foreignObject',
        selector: 'container',
        attributes: {
          width: LABEL_WIDTH,
          height: LABEL_HEIGHT,
          class: 'is-clickable'
        },
        children: [
          {
            tagName: 'div',
            namespaceURI: 'http://www.w3.org/1999/xhtml',
            attributes: {
              class: 'is-flex is-justify-content-flex-end'
            },
            children: [
              {
                tagName: 'span',
                namespaceURI: 'http://www.w3.org/1999/xhtml',
                attributes: {
                  class: 'tag is-primary is-size-6'
                }
              }
            ]
          }
        ]
      }
    ],
    x: '50%',
    y: '0%',
    offset: {
      x: -LABEL_WIDTH / 2,
      y: -LABEL_HEIGHT / 2
    },
    rotate: true,
    action() {
      EventBus.dispatch('elementCost', this)
    }
  }
})

export function useCostsLabels(costsRef) {
  const oruga = useOruga()

  function openElementModal(cellView) {
    const {
      model: { attributes: element }
    } = cellView

    oruga.modal.open({
      component: ElementCostModal,
      props: {
        element
      },
      trapFocus: true
    })
  }

  function createCostLabel(id, cost) {
    const tool = new costLabel()
    const view = new dia.ToolsView({
      tools: [tool]
    })
    window.graph.getCell(id).findView(window.paper).addTools(view)
    costToolsView.push({
      id,
      view
    })
    setTimeout(() => {
      tool.el.children[0].children[0].children[0].textContent = cost
      // tool.el.children[1].innerHTML = cost
    }, 50)
  }

  function removeLabels() {
    for (const tool of costToolsView) {
      window.graph.getCell(tool.id).findView(window.paper).removeTools()
    }
  }

  const formatters = {}

  function displayCosts() {
    const costs = costsRef.value
    for (const resourceID in costs) {
      const foundCell = window.graph.getCell(resourceID)
      if (foundCell) {
        const resourceCost = costs[resourceID]
        const { currency, value } = resourceCost
        if (resourceCost !== undefined) {
          foundCell.set('cost', value)
          foundCell.set('currency', currency)
          if (!(currency in formatters)) {
            formatters[currency] = new Intl.NumberFormat('en-US', {
              maximumFractionDigits: 2,
              style: 'currency',
              currency,
              currencyDisplay: 'narrowSymbol'
            })
          }
          const formatter = formatters[currency]
          const str = formatter.format(value)
          createCostLabel(resourceID, str)
        }
      }
    }
  }

  onMounted(() => {
    EventBus.on('elementCost', openElementModal)
  })

  onBeforeUnmount(() => {
    EventBus.remove('elementCost', openElementModal)
  })

  return {
    displayCosts,
    removeLabels
  }
}
