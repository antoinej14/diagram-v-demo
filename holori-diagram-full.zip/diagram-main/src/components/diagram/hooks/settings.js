import { computed } from 'vue'

import { defaultMargin } from '@/common/diagram/options/methods/layout.js'

import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'

export const defaultSettings = {
  hideEdges: false,
  resizeMode: false,
  lockedMode: false,
  nodeLabels: false,
  lockMaximumZoom: true,
  grid: false,
  autosaveDelay: 30,
  layoutMargin: defaultMargin
}

const drawGrid = {
  name: 'doubleMesh',
  args: [
    { color: '#d7d7d7', thickness: 1 },
    { color: '#c4c4c4', scaleFactor: 5, thickness: 2 }
  ]
}

function stopListening() {
  if ('commandManager' in window) {
    window.commandManager.stopListening()
  }
}

function listen() {
  if ('commandManager' in window) {
    window.commandManager.listen()
  }
}

function applyWithoutSaving(action) {
  stopListening()
  action()
  listen()
}

export const useSettings = (createAutosave, saveKey = 'diagram-settings') => {
  const diagramStore = useDiagramStore()
  const projectStore = useProjectStore()

  function updateSettings(settings) {
    const { autosaveDelay, lockedMode, resizeMode, hideEdges, nodeLabels, grid } = settings

    // Update autosave and delay
    if (autosaveDelay) {
      projectStore.setAutosaveDelay(autosaveDelay)
      if (typeof createAutosave === 'function') {
        createAutosave()
      }
    } else {
      projectStore.setAutosave(false)
      if (typeof createAutosave === 'function') {
        createAutosave(false)
      }
    }

    // Related to graph optimizations.
    if (window.graph) {
      const { graph, paper } = window

      paper.setInteractivity(!lockedMode)

      if (diagramStore.settings.hideEdges !== hideEdges) {
        applyWithoutSaving(() => {
          graph.getLinks().forEach((link) => {
            link.attr('./display', hideEdges ? 'none' : 'block')
          })
        })
      }
      if (diagramStore.settings.nodeLabels !== nodeLabels) {
        graph.getCells().forEach((cell) => {
          if (cell.attributes.type === 'Node') {
            applyWithoutSaving(() => {
              cell.attr('label/display', nodeLabels ? 'block' : 'none')
              cell.attr('labelBox/display', nodeLabels ? 'block' : 'none')
            })
          }
        })
      }
      if (diagramStore.settings.grid !== grid) {
        paper.setGrid(grid ? drawGrid : false)
      }
    }

    window.lockedMode = lockedMode
    window.resizeMode = resizeMode

    localStorage.setItem(saveKey, JSON.stringify(settings))
    diagramStore.setSettings(settings)
  }

  const diagramSettings = computed(() => diagramStore.settings)

  return {
    diagramSettings,
    updateSettings
  }
}
