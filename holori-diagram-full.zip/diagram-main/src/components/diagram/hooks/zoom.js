import { useDiagramStore } from '@/store/diagram.js'

export const useZoom = (scrollerArg = null, lockMaximumZoom = null, min = 0.2) => {
  const diagramStore = useDiagramStore()

  function getScroller(number) {
    if (scrollerArg) {
      return scrollerArg
    }
    return number ? window[`scroller${number}`] : window.scroller
  }

  function zoomOut(ox = undefined, oy = undefined, number = undefined) {
    getScroller(number).zoom(-0.1, {
      min,
      ox,
      oy
    })
  }

  function zoomIn(ox = undefined, oy = undefined, number = undefined) {
    const max = (() => {
      if (lockMaximumZoom !== null) {
        return lockMaximumZoom
      }
      return diagramStore.settings.lockMaximumZoom ? 1 : undefined
    })()
    getScroller(number).zoom(0.1, {
      max,
      ox,
      oy
    })
  }

  function zoomToFit(number = undefined) {
    getScroller(number).zoomToFit({ padding: 20, maxScale: 1 })
  }

  function focusElement(element, number = undefined) {
    getScroller(number).zoomToRect(element.getBBox(), { padding: 10, maxScale: 1 })
  }

  return {
    zoomOut,
    zoomIn,
    zoomToFit,
    focusElement
  }
}
