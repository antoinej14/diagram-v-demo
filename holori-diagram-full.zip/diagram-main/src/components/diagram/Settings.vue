<script setup>
import { computed, ref, watch } from 'vue'
import { OButton, ODropdown, ODropdownItem, OIcon, OTooltip } from '@oruga-ui/oruga-next'
import { storeToRefs } from 'pinia'

import { useDiagramStore } from '@/store/diagram.js'

defineOptions({
  name: 'DiagramSettings'
})

const props = defineProps({
  visualizeMode: {
    type: Boolean,
    required: false,
    default: false
  }
})

const emit = defineEmits(['change'])

const diagramStore = useDiagramStore()
const { settings } = storeToRefs(diagramStore)

const localSettings = ref([])

function updateSetting(setting, value) {
  emit('change', {
    ...settings.value,
    [setting]: value
  })
}

const activeSettings = computed(() => {
  let active = 0
  const keys = ['toolbarLabel', 'nodeLabels', 'hideEdges', 'lockMaximumZoom', 'grid']
  for (const key of keys) {
    if (settings.value[key]) {
      active++
    }
  }
  return active
})

watch(localSettings, (newVal, oldVal) => {
  const added = newVal.filter((val) => !oldVal.includes(val))
  const removed = oldVal.filter((val) => !newVal.includes(val))

  if (added.length === 1) {
    updateSetting(added[0], true)
  } else if (removed.length === 1) {
    updateSetting(removed[0], false)
  }
})

watch(settings, (newVal, oldVal) => {
  if (!Object.keys(oldVal).length) {
    localSettings.value = Object.keys(newVal)
      .filter((key) => typeof newVal[key] === 'boolean')
      .filter((key) => newVal[key])
  }
})
</script>

<template>
  <o-dropdown
    v-model="localSettings"
    class="settings-dropdown"
    aria-role="list"
    :close-on-click="false"
    multiple
  >
    <template #trigger>
      <o-tooltip label="Diagram settings" position="bottom">
        <o-button
          class="mx-1 is-relative"
          icon-left="cog"
          icon-class="toolbar-icon"
          variant="secondary"
        >
          <span
            v-if="activeSettings > 0"
            class="tag is-primary is-rounded is-absolute active-settings"
          >
            {{ activeSettings }}
          </span>
          <slot />
        </o-button>
      </o-tooltip>
    </template>

    <o-dropdown-item
      class="is-flex is-align-items-center pr-3"
      aria-role="listitem"
      value="toolbarLabel"
    >
      <o-icon icon="label-outline" class="mr-2" />
      Display toolbar labels
    </o-dropdown-item>

    <o-dropdown-item
      class="is-flex is-align-items-center pr-3"
      aria-role="listitem"
      value="nodeLabels"
    >
      <o-icon icon="information-outline" class="mr-2" />
      Display node labels
    </o-dropdown-item>

    <o-dropdown-item
      class="is-flex is-align-items-center pr-3"
      aria-role="listitem"
      value="hideEdges"
    >
      <o-icon icon="ray-start-arrow" class="mr-2" />
      Hide edges
    </o-dropdown-item>

    <o-dropdown-item
      class="is-flex is-align-items-center pr-3"
      aria-role="listitem"
      value="lockMaximumZoom"
    >
      <o-icon icon="magnify-expand" class="mr-2" />
      Lock maximum zoom
    </o-dropdown-item>

    <o-dropdown-item class="is-flex is-align-items-center pr-3" aria-role="listitem" value="grid">
      <o-icon icon="grid" class="mr-2" />
      Grid
    </o-dropdown-item>

    <o-dropdown
      v-if="!props.visualizeMode"
      aria-role="list"
      class="full-width"
      trigger-class="full-width"
      :triggers="['hover', 'click']"
      position="top-left"
      menu-class="autosave-menu"
      animation=""
    >
      <template #trigger>
        <o-dropdown-item aria-role="listitem" class="is-flex full-width pr-1">
          <o-icon icon="arrow-expand-horizontal" class="mr-2" />
          Layout spacing
          <o-icon icon="chevron-right" class="ml-auto" />
        </o-dropdown-item>
      </template>

      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.layoutMargin === 10 }"
        aria-role="listitem"
        @click="updateSetting('layoutMargin', 10)"
      >
        <o-icon icon="size-s" class="mr-2" />
        Small
      </o-dropdown-item>
      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.layoutMargin === 70 }"
        aria-role="listitem"
        @click="updateSetting('layoutMargin', 70)"
      >
        <o-icon icon="size-m" class="mr-2" />
        Medium
      </o-dropdown-item>
      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.layoutMargin === 300 }"
        aria-role="listitem"
        @click="updateSetting('layoutMargin', 300)"
      >
        <o-icon icon="size-l" class="mr-2" />
        Large
      </o-dropdown-item>
    </o-dropdown>

    <o-dropdown
      v-if="!props.visualizeMode"
      aria-role="list"
      class="full-width m-0"
      trigger-class="full-width"
      :triggers="['hover', 'click']"
      position="top-left"
      menu-class="autosave-menu"
      animation=""
    >
      <template #trigger>
        <o-dropdown-item aria-role="listitem" class="is-flex full-width pr-1">
          <o-icon icon="content-save-outline" class="mr-2" />
          Autosave
          <o-icon icon="chevron-right" class="ml-auto" />
        </o-dropdown-item>
      </template>

      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.autosaveDelay === 30 }"
        aria-role="listitem"
        @click="updateSetting('autosaveDelay', 30)"
      >
        <o-icon icon="timer-outline" class="mr-2" />
        Every 30 seconds
      </o-dropdown-item>
      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.autosaveDelay === 60 }"
        aria-role="listitem"
        @click="updateSetting('autosaveDelay', 60)"
      >
        <o-icon icon="timer-outline" class="mr-2" />
        Every minute
      </o-dropdown-item>
      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.autosaveDelay === 60 * 5 }"
        aria-role="listitem"
        @click="updateSetting('autosaveDelay', 60 * 5)"
      >
        <o-icon icon="timer-outline" class="mr-2" />
        Every 5 minutes
      </o-dropdown-item>
      <o-dropdown-item
        class="is-flex"
        :class="{ 'is-active': settings.autosaveDelay === null }"
        aria-role="listitem"
        @click="updateSetting('autosaveDelay', null)"
      >
        <o-icon icon="timer-off-outline" class="mr-2" />
        Disable
      </o-dropdown-item>
    </o-dropdown>
  </o-dropdown>
</template>

<style scoped>
.settings-dropdown :deep(.dropdown-menu) {
  left: auto;
  right: 0;
}
:deep(.autosave-menu) {
  left: 100% !important;
  top: 0 !important;
  bottom: auto !important;
}
.active-settings {
  top: 0;
  left: 100%;
  transform: translateX(-50%) translateY(-50%);
  z-index: 20;
}
</style>
