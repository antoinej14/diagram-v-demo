<script setup>
import { computed } from 'vue'
import { storeToRefs } from 'pinia'

import { useDiagramStore } from '@/store/diagram'

import NodeLink from '@/components/diagram/NodeLink.vue'

const diagramStore = useDiagramStore()

const { getGlobalSelection } = storeToRefs(diagramStore)

const displayedItems = computed(() => {
  return getGlobalSelection.value.filter((item) => {
    // Case for a control point node.
    if (item.type === 'control-point') {
      return false
    }
    // Case for a controlled edge.
    if (item.originalEdgeID) {
      return false
    }
    // Case for 'empty' text box.
    if (item.type === 'text-box' && item.notes === 'empty') {
      return false
    }

    return true
  })
})

function selectItem(id) {
  const item = window.graph.getCell(id).attributes
  let type = item.type

  if (type === 'Node') {
    type = 'node'
  } else if (type === 'Group') {
    type = 'group'
  } else {
    type = 'edge'
  }

  diagramStore.setUniqueSelection({
    [type]: item
  })
}
</script>

<template>
  <aside class="multiple-selection has-background-white">
    <div class="p-5">
      <NodeLink v-for="item in displayedItems" :key="item.id" :model="item" @select="selectItem" />
    </div>
  </aside>
</template>

<style scoped>
.multiple-selection {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
  box-shadow: 5px 0 13px 3px rgba(10, 10, 10, 0.1);
  max-height: 70vh;
  overflow-x: hidden;
  overflow-y: scroll;
  top: 50% !important;
  transform: translateY(-50%);
  z-index: 3;
  position: fixed;
  right: auto;
  left: 0;
  width: 20rem;
}
</style>
