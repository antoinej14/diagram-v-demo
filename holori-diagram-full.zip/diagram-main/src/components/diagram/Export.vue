<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { OIcon } from '@oruga-ui/oruga-next'

import { useMixins } from '@/common/mixins'

import ExportTerraform from './export/ExportTerraform.vue'
import ExportListView from './export/ExportListView.vue'
import ExportDocumentation from './export/ExportDocumentation.vue'

defineOptions({
  name: 'DiagramExport'
})

const route = useRoute()
const { navigate } = useMixins()

const tab = computed(() => route.params.tab || 'documentation')

function gotoTab(tab) {
  navigate('ProjectExport', {
    params: {
      id: route.params.id,
      tab
    }
  })
}
</script>
<template>
  <div class="under-navbar is-flex">
    <aside class="menu sidebar py-5 pl-5">
      <div class="sidebar-inside">
        <ul class="menu-list">
          <li>
            <a
              class="is-flex is-align-items-center sidebar-item"
              :class="{ 'is-active': tab === 'documentation' }"
              @click="gotoTab('documentation')"
            >
              <o-icon icon="file-document-outline" class="mr-3" />
              Documentation
            </a>
          </li>
          <li>
            <a
              class="is-flex is-align-items-center sidebar-item"
              :class="{ 'is-active': tab === 'list' }"
              @click="gotoTab('list')"
            >
              <o-icon icon="list-box-outline" class="mr-3" />
              List view
            </a>
          </li>
          <li>
            <a
              class="is-flex is-align-items-center sidebar-item"
              :class="{ 'is-active': tab === 'terraform' }"
              @click="gotoTab('terraform')"
            >
              <o-icon icon="terraform" class="mr-3" />
              Terraform
            </a>
          </li>
        </ul>
      </div>
    </aside>
    <section class="is-flex-grow-1 is-flex is-flex-direction-column p-5">
      <transition name="fade-x">
        <ExportTerraform v-if="tab === 'terraform'" key="terraform" />
        <ExportListView v-if="tab === 'list'" key="list" />
        <ExportDocumentation v-if="tab === 'documentation'" key="documentation" />
      </transition>
    </section>
  </div>
</template>

<style scoped>
.sidebar-item {
  height: 45px;
}
.menu-list :deep() .is-active {
  background-color: var(--primary-bg);
  color: var(--text-color);
  position: relative;
}
:deep() pre {
  background-color: transparent;
}
:deep() .ssh-pre {
  margin-top: 0;
}
</style>

<style>
@media print {
  nav,
  aside {
    display: none;
  }
}
</style>
