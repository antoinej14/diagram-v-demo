<script setup>
import { ref, computed, nextTick } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, ODropdown, ODropdownItem, OIcon, OTooltip, useOruga } from '@oruga-ui/oruga-next'

import projectsApi from '@/api/modules/main-server/organizations/projects.js'

import EventBus from '@/common/eventBus'
import { exportDiagramImage } from '@/common/diagram/utils'
import { useOrganizationMembership } from '@/common/organization-membership.js'

import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useAppStore } from '@/store/app.js'

import DiagramSettings from './Settings.vue'
import CostEstimateModal from '@/components/modal/CostEstimate.vue'

defineOptions({
  name: 'DiagramToolbar'
})

const props = defineProps({
  canCreateEdge: {
    type: Boolean,
    required: false,
    default: false
  },
  canCreateGroup: {
    type: Boolean,
    required: false,
    default: false
  },
  leftSidebarVisible: {
    type: Boolean,
    required: false,
    default: false
  },
  rightSidebarVisible: {
    type: Boolean,
    required: false,
    default: false
  },
  visualizeMode: {
    type: Boolean,
    required: false,
    default: false
  }
})

const emit = defineEmits([
  'undo',
  'redo',
  'create-edge',
  'create-group',
  'create-from-infrastructure',
  'duplicate',
  'delete',
  'zoom-in',
  'zoom-out',
  'layout',
  'toggle-locked-mode',
  'save',
  'settings-change'
])

const { organizationID } = useOrganizationMembership(false)

const oruga = useOruga()

function openCostEstimate() {
  oruga.modal.open({
    component: CostEstimateModal,
    trapFocus: true
  })
}

const formats = {
  'image/png': {
    name: 'PNG',
    icon: 'file-png-box',
    whiteBackground: false
  },
  'image/jpeg': {
    name: 'JPG',
    icon: 'file-jpg-box',
    whiteBackground: true
  },
  'image/svg': {
    name: 'SVG',
    icon: 'svg',
    whiteBackground: false
  }
}

const exportLoading = ref(false)
const exportFormat = ref(null)

const appStore = useAppStore()
const projectStore = useProjectStore()
const diagramStore = useDiagramStore()
const providerAccountsStore = useProviderAccountsStore()

const { project, readonly } = storeToRefs(projectStore)
const { getGlobalSelectionCount, canUndo, canRedo, isComparing, settings } =
  storeToRefs(diagramStore)
const { providerAccount } = storeToRefs(providerAccountsStore)

const labelClass = computed(() => {
  let className = 'toolbar-label'
  if (settings.value.toolbarLabel) {
    className += ' toolbar-label--visible'
  }
  return className
})

const undoDisabled = computed(
  () => !canUndo.value || isComparing.value || settings.value.lockedMode
)
const redoDisabled = computed(
  () => !canRedo.value || isComparing.value || settings.value.lockedMode
)
const createEdgeDisabled = computed(
  () => !props.canCreateEdge || isComparing.value || settings.value.lockedMode
)
const createGroupDisabled = computed(
  () => !props.canCreateGroup || isComparing.value || settings.value.lockedMode
)
const duplicateDisabled = computed(
  () => !getGlobalSelectionCount.value || isComparing.value || settings.value.lockedMode
)
const rearrangeDisabled = computed(() => isComparing.value || settings.value.lockedMode)

function stopComparing() {
  projectsApi.getProjectDiagram(organizationID, project.value.id).then((res) => {
    EventBus.dispatch('reloadDiagram', JSON.parse(res.data.diagram))
    diagramStore.setComparing(false)
    EventBus.dispatch('openHistory')
  })
}

function exportImage(format) {
  exportLoading.value = true
  appStore.increaseMaxLoading(2)
  appStore.increaseValLoading()

  const previousSettings = { ...settings.value }
  const { nodeLabels: previousNodeLabels } = previousSettings

  emit('settings-change', {
    ...previousSettings,
    nodeLabels: true
  })

  nextTick(() => {
    const def = formats[format]
    const { whiteBackground } = def
    const ext = formats[format].name.toLowerCase()

    // Give time for the loader to appear...
    setTimeout(() => {
      exportDiagramImage(
        whiteBackground,
        format,
        `${project.value?.name || providerAccount.value?.name}.${ext}`,
        () => {
          appStore.increaseValLoading()
          exportLoading.value = false
          exportFormat.value = null
          EventBus.dispatch('stopGlobalLoading')

          emit('settings-change', {
            ...previousSettings,
            nodeLabels: previousNodeLabels
          })
        }
      )
    }, 200)
  })
}
</script>
<template>
  <div class="pt-3 is-flex is-justify-content-center">
    <div id="graph" class="is-absolute" />
    <div class="toolbar is-flex is-justify-content-center is-relative">
      <o-tooltip
        v-if="visualizeMode"
        label="Create a project from this infrastructure"
        position="bottom"
      >
        <o-button
          variant="secondary"
          icon-left="rename"
          class="mr-1"
          @click="emit('create-from-infrastructure')"
        >
          Edit
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!visualizeMode" label="Undo last action (Ctrl+Z)" position="bottom">
        <o-button
          v-if="!readonly"
          v-keyboard-shortcut="'Ctrl+Z'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          icon-left="undo"
          :disabled="undoDisabled"
          @click="emit('undo')"
        >
          <span :class="labelClass">Undo</span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!visualizeMode" label="Redo cancelled action (Ctrl+Y)" position="bottom">
        <o-button
          v-if="!readonly"
          v-keyboard-shortcut="'Ctrl+Y'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          icon-left="redo"
          :disabled="redoDisabled"
          @click="emit('redo')"
        >
          <span :class="labelClass"> Redo </span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!visualizeMode" label="Create an edge (Ctrl+E)" position="bottom">
        <o-button
          v-if="!readonly"
          v-keyboard-shortcut="'Ctrl+E'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          :disabled="createEdgeDisabled"
          icon-left="ray-start-arrow"
          @click="emit('create-edge', $event)"
        >
          <span :class="labelClass"> Create an edge </span>
        </o-button>
      </o-tooltip>
      <o-tooltip
        v-if="!visualizeMode"
        label="Create a group from the selection (Ctrl+G)"
        position="bottom"
      >
        <o-button
          v-if="!readonly"
          v-keyboard-shortcut="'Ctrl+G'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          :disabled="createGroupDisabled"
          icon-left="group"
          @click="emit('create-group')"
        >
          <span :class="labelClass"> Create a group </span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!visualizeMode" label="Select all (Ctrl+A)" position="bottom">
        <o-button
          v-keyboard-shortcut="'Ctrl+A'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          icon-left="select-all"
          @click="emit('select-all')"
        >
          <span :class="labelClass"> Select all </span>
        </o-button>
      </o-tooltip>
      <o-tooltip
        v-if="!readonly && !visualizeMode"
        label="Duplicate the selection (Ctrl+D)"
        position="bottom"
      >
        <o-button
          v-keyboard-shortcut="'Ctrl+D'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          :disabled="duplicateDisabled"
          icon-left="content-duplicate"
          @click="emit('duplicate')"
        >
          <span :class="labelClass"> Duplicate </span>
        </o-button>
      </o-tooltip>
      <o-tooltip
        v-if="!readonly && !visualizeMode"
        label="Delete the selection (Delete)"
        position="bottom"
      >
        <o-button
          v-keyboard-shortcut="'Delete'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          :disabled="!getGlobalSelectionCount || isComparing || settings.lockedMode"
          icon-left="delete"
          @shortkey="
            !(!getGlobalSelectionCount || isComparing || settings.lockedMode)
              ? emit('delete')
              : null
          "
          @click="emit('delete')"
        >
          <span :class="labelClass"> Delete </span>
        </o-button>
      </o-tooltip>
      <o-tooltip label="Zoom in (Ctrl++)" position="bottom">
        <o-button
          v-keyboard-shortcut="'Ctrl+='"
          variant="secondary"
          icon-class="toolbar-icon"
          class="mx-1"
          icon-left="magnify-plus-outline"
          @click="emit('zoom-in')"
        >
          <span :class="labelClass"> Zoom in </span>
        </o-button>
      </o-tooltip>
      <o-tooltip label="Zoom out (Ctrl+-)" position="bottom">
        <o-button
          v-keyboard-shortcut="'Ctrl+-'"
          variant="secondary"
          icon-class="toolbar-icon"
          class="mx-1"
          icon-left="magnify-minus-outline"
          @click="emit('zoom-out')"
        >
          <span :class="labelClass"> Zoom out </span>
        </o-button>
      </o-tooltip>
      <o-tooltip label="Reset zoom" position="bottom">
        <o-button
          variant="secondary"
          icon-class="toolbar-icon"
          class="mx-1"
          icon-left="magnify"
          @click="emit('reset-zoom')"
        >
          <span :class="labelClass">Reset zoom</span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!props.visualizeMode" label="Rearrange diagram (Ctrl+J)" position="bottom">
        <o-button
          v-keyboard-shortcut="'Ctrl+J'"
          variant="secondary"
          class="mx-1"
          icon-class="toolbar-icon"
          icon-left="graphql"
          :disabled="rearrangeDisabled"
          @shortkey="!rearrangeDisabled ? emit('layout') : null"
          @click="emit('layout')"
        >
          <span :class="labelClass"> Rearrange </span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="!visualizeMode" label="Locked Mode (Only move diagram)" position="bottom">
        <o-button
          :variant="settings.lockedMode ? 'primary' : 'secondary'"
          id="locked-mode-button"
          class="mx-1"
          icon-class="toolbar-icon"
          icon-left="lock"
          :disabled="isComparing"
          @click="emit('toggle-locked-mode')"
        >
          <span :class="labelClass"> Locked Mode </span>
        </o-button>
      </o-tooltip>
      <o-tooltip
        v-if="!readonly && !visualizeMode"
        label="Save the diagram (Ctrl+S)"
        position="bottom"
      >
        <o-button
          v-if="!readonly"
          v-keyboard-shortcut="'Ctrl+S'"
          class="mx-1"
          icon-class="toolbar-icon"
          variant="secondary"
          icon-left="content-save"
          :disabled="isComparing"
          @click="emit('save')"
        >
          <span :class="labelClass"> Save </span>
        </o-button>
      </o-tooltip>
      <DiagramSettings
        :settings="settings"
        :visualize-mode="visualizeMode"
        @change="emit('settings-change', $event)"
      >
        <span :class="labelClass"> Settings </span>
      </DiagramSettings>
      <o-dropdown v-model="exportFormat" class="export-dropdown ml-0" @change="exportImage">
        <template #trigger>
          <o-tooltip label="Export diagram to image" position="bottom">
            <o-button
              class="mx-1"
              variant="secondary"
              :icon-left="exportLoading ? 'loading' : 'file-export-outline'"
              :icon-class="`toolbar-icon ${exportLoading ? 'is-spin' : ''}`"
              :disabled="exportLoading"
            >
              <span :class="labelClass"> Export image </span>
            </o-button>
          </o-tooltip>
        </template>
        <o-dropdown-item
          v-for="(format, type) in formats"
          :key="format.name"
          class="is-flex is-align-items-center"
          :value="type"
        >
          <o-icon :icon="format.icon" class="mr-2" />
          Export to {{ format.name }}
        </o-dropdown-item>
      </o-dropdown>
      <o-tooltip label="Estimate this diagram's monthly cost on Scaleway" position="bottom">
        <o-button
          class="mx-1"
          variant="secondary"
          icon-class="toolbar-icon"
          icon-left="currency-usd"
          :disabled="isComparing"
          @click="openCostEstimate"
        >
          <span :class="labelClass"> Cost estimate </span>
        </o-button>
      </o-tooltip>
      <o-tooltip v-if="isComparing" label="Stop comparing" position="bottom">
        <o-button class="mx-1" variant="primary" icon-left="stop" @click="stopComparing">
          Stop comparing
        </o-button>
      </o-tooltip>
    </div>
  </div>
</template>

<style scoped>
.toolbar {
  background-color: #fffdfd;
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.25);
  max-width: 98vw;
  gap: 0.5rem 0;
  flex-wrap: wrap;
  padding: 15px 11px;
  z-index: 4;
}
.toolbar-label {
  font-size: 0;
  margin-left: -13px;
  opacity: 0;
  transform: translateX(-20px);
  transition: all 0.1s ease;
}
.toolbar-label--visible {
  font-size: unset;
  margin-left: 13px;
  opacity: 1;
  transform: none;
}
.export-dropdown :deep(.dropdown-menu) {
  left: auto;
  right: 0;
}
</style>
