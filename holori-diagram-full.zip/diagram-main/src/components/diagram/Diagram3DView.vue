<script setup>
import { onBeforeUnmount, onMounted, ref, nextTick } from 'vue'
import { storeToRefs } from 'pinia'
import { useRoute } from 'vue-router'
import { OButton, ODropdown, ODropdownItem, OIcon, OLoading } from '@oruga-ui/oruga-next'
import panzoom from 'panzoom'

import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'

import { generate3DDiagram } from '@/common/3d-view'
import { downloadFile } from '@/common/utils.js'
import { exportToRaster } from '@/common/diagram/utils.js'

import DiagramDetails from '@/components/diagram/Details.vue'

const formats = {
  'image/png': {
    name: 'PNG',
    icon: 'file-png-box',
    whiteBackground: false
  },
  'image/jpeg': {
    name: 'JPG',
    icon: 'file-jpg-box',
    whiteBackground: true
  },
  'image/svg': {
    name: 'SVG',
    icon: 'svg',
    whiteBackground: false
  }
}

let panzoomInstance = null

const props = defineProps({
  provider: {
    type: String,
    required: false,
    default: ''
  }
})

const route = useRoute()

const loading = ref(true)
const progress = ref('')
const panzoomReady = ref(false)
const cursor = ref('grab')
const content = ref('')
const panning = ref(false)

const canvasRef = ref(null)

const diagramStore = useDiagramStore()
const projectStore = useProjectStore()

const { getData } = storeToRefs(diagramStore)
const { project } = storeToRefs(projectStore)

function getDownloadName(format) {
  return `${props.provider || project.value.name}.${format.name.toLowerCase()}`
}

function clickElement(e) {
  if (panning.value) {
    return
  }

  const element = e.target.closest('g.joint-element')
  Array.from(document.querySelectorAll('g.joint-element.selected')).forEach((el) => {
    el.classList.remove('selected')
  })

  if (!element) {
    diagramStore.clearSelection()
    return
  }

  element.classList.add('selected')

  const id = element.getAttribute('model-id')
  const { groups, nodes } = getData.value
  const elements = [...groups, ...nodes]
  const found = elements.find((e) => e.id === id)

  if (found) {
    const type = found.type.toLowerCase() + 's'
    const selectionType = found.type === 'TextBox' ? 'nodes' : type
    const selection = {
      groups: [],
      nodes: [],
      edges: [],
      [selectionType]: [found]
    }
    if (diagramStore.selection[selectionType][0]?.id === found.id) {
      element.classList.remove('selected')
      diagramStore.clearSelection()
    } else {
      diagramStore.setSelection(selection)
    }
  }
}

onMounted(() => {
  diagramStore.setDetailsTab('terraform')

  generate3DDiagram(
    getData.value,
    (data) => {
      loading.value = false
      content.value = data

      nextTick(() => {
        const svgTag = canvasRef.value.querySelector('svg')

        const { region, resource } = route.query

        if (region || resource) {
          const cell = window.graph
            .getCells()
            .find(
              ({ attributes }) =>
                attributes.location?.startsWith(region) || attributes.id?.startsWith(resource)
            )
          if (cell) {
            svgTag
              .querySelector(`g.joint-cell[model-id="${cell.attributes.id}"]`)
              .classList.add('highlighted-3d')
          }
        }

        panzoomInstance = panzoom(canvasRef.value, {
          smoothScroll: false,
          initialZoom: 1.0
        })
        panzoomInstance.on('panstart', () => {
          cursor.value = 'grabbing'
          panning.value = true
        })
        panzoomInstance.on('panend', () => {
          cursor.value = 'grab'
          setTimeout(() => {
            panning.value = false
          }, 200)
        })
        panzoomInstance.on('zoom', () => {
          cursor.value = 'zoom-in'
        })

        panzoomReady.value = true
      })
    },
    progress
  )
})

function lol(format) {
  const fileName = getDownloadName(formats[format])
  if (format === 'image/svg') {
    downloadFile(content.value, fileName, format)
  } else {
    const svgTag = canvasRef.value.querySelector('svg')
    const width = svgTag.width.baseVal.value
    const height = svgTag.height.baseVal.value
    exportToRaster(
      content.value,
      format,
      (result) => {
        downloadFile(result, fileName, format)
      },
      formats[format].whiteBackground,
      { width, height }
    )
  }
}

onBeforeUnmount(() => {
  if (panzoomInstance) {
    panzoomInstance.dispose()
  }
})
</script>

<template>
  <div>
    <o-loading :active="loading" full-page>
      <o-icon icon="loading" size="large" />

      <p>
        {{ progress || 'Generating your 3D diagram&hellip;' }}
      </p>
    </o-loading>

    <o-dropdown v-if="!loading" class="download-button" position="top-right" @change="lol">
      <template #trigger="{ active }">
        <o-button
          tag="a"
          variant="primary"
          icon-left="file-download"
          :icon-right="active ? 'chevron-down' : 'chevron-up'"
        >
          Download 3D diagram image
        </o-button>
      </template>

      <o-dropdown-item
        v-for="(format, type) in formats"
        :key="format.name"
        class="is-flex is-align-items-center"
        :value="type"
      >
        <o-icon :icon="format.icon" class="mr-2" />
        Export to {{ format.name }}
      </o-dropdown-item>
    </o-dropdown>

    <div id="canvas3d" style="width: 100vw; height: 100vh; opacity: 0" />

    <div ref="canvasRef" class="canvas" :style="{ cursor }">
      <div v-if="!images" class="jointjs-paper" :class="{ 'is-invisible': images }" />
      <div v-html="content" class="is-flex is-justify-content-center" @click="clickElement" />
    </div>

    <DiagramDetails
      key="details"
      :visible="diagramStore.getGlobalSelectionCount > 0"
      hide-project
      hide-style
    />
  </div>
</template>

<style scoped>
.canvas {
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: 100vh;
}
.download-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 20;
}

.download-button :deep(.dropdown-content) {
  left: auto;
  right: 0;
}

.canvas:deep(svg .joint-element) {
  cursor: pointer;
}

.canvas:deep(svg .joint-element.selected polygon),
.canvas:deep(svg .joint-element.selected path),
.canvas:deep(svg .joint-element.selected ellipse) {
  fill: #3498db;
  opacity: 1;
  stroke: #2980b9;
}

.highlighted-3d {
  filter: drop-shadow(0 0 20px var(--primary));
}
</style>
