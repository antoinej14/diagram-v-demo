<script setup>
import { computed, watch } from 'vue'
import { storeToRefs } from 'pinia'
import {
  OButton,
  OField,
  OIcon,
  ONotification,
  OTabItem,
  OTabs,
  OTooltip
} from '@oruga-ui/oruga-next'
import moment from 'moment'

import { useMixins } from '@/common/mixins.js'
import { formatPrice } from '@/common/diagram/utils.js'

import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'

import NodeLink from '@/components/diagram/NodeLink.vue'
import NodeDetails from '@/components/diagram/details/NodeDetails.vue'
import EdgeDetails from '@/components/diagram/details/EdgeDetails.vue'
import GroupDetails from '@/components/diagram/details/GroupDetails.vue'
import Terraform from '@/components/diagram/details/Terraform.vue'
import ItemStyle from '@/components/diagram/details/ItemStyle.vue'
import EdgeStyle from '@/components/diagram/details/EdgeStyle.vue'
import ItemNotes from '@/components/diagram/details/ItemNotes.vue'
import ScalewayPricing from '@/components/diagram/details/ScalewayPricing.vue'
import ItemChildren from '@/components/diagram/details/ItemChildren.vue'
import ProjectDetails from '@/components/diagram/details/ProjectDetails.vue'
import ScrollToTop from '@/components/ScrollToTop.vue'

defineOptions({
  name: 'DiagramDetails'
})

const emit = defineEmits(['select', 'toggle-visibility', 'add-duplicate'])

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  disabled: {
    type: Boolean,
    required: false,
    default: false
  },
  hideStyle: {
    type: Boolean,
    required: false,
    default: false
  },
  hideProject: {
    type: Boolean,
    required: false,
    default: false
  },
  tab: {
    type: String,
    required: false,
    default: ''
  },
  generalTab: {
    type: Boolean,
    required: false,
    default: false
  },
  costs: {
    type: Object,
    required: false,
    default: () => ({})
  }
})

const lastMonth = moment().subtract(1, 'month').format('MMM YYYY')

const { toast } = useMixins()

const diagramStore = useDiagramStore()
const projectStore = useProjectStore()

const {
  getGlobalSelectionCount,
  getSelectedNode,
  getSelectedGroup,
  getSelectedEdge,
  getSelectedItem,
  getSelectedAnything,
  hasUniqueSelection,
  detailsTab,
  isComparing,
  settings
} = storeToRefs(diagramStore)

const { project, readonly } = storeToRefs(projectStore)

const hasTerraform = computed(() => {
  if (!('terraform' in getSelectedAnything.value)) {
    return false
  }
  return typeof getSelectedAnything.value.terraform === 'object'
})

const isScalewayInstance = computed(() =>
  Boolean(getSelectedNode.value?.path?.startsWith('/scaleway/Compute/Instance'))
)

const groupId = computed(() => {
  const { groupId, parentId, parent } = getSelectedAnything.value
  return groupId || parentId || parent
})

const parentGroups = computed(() => {
  if (!groupId.value) {
    return []
  }
  return getParentGroups(groupId.value)
})

const selectedTab = computed({
  get() {
    if (detailsTab.value === 'terraform' && !hasTerraform.value) {
      return 'general'
    }
    return detailsTab.value
  },
  set(tab) {
    diagramStore.setDetailsTab(tab)
  }
})

if (props.tab) {
  selectedTab.value = props.tab
}

watch(getSelectedAnything, (val) => {
  if (val) {
    const { type } = val
    const imported = project.value?.imported || props.hideProject

    if (imported) {
      if (type === 'custom' || type === 'group') {
        selectedTab.value = 'terraform'
      }
    }
  }
})

function getParentGroups(groupId) {
  if (!groupId) {
    return []
  }

  const parentGroup = window.graph.getCell(groupId)

  if (!parentGroup) {
    return []
  }

  const model = parentGroup.attributes
  const { parent } = model

  return [model, ...getParentGroups(parent)]
}

function displayHiddenInfo(e) {
  if (
    e.target.className.includes('mdi-information') ||
    e.target.className.includes('mdi-view-list')
  ) {
    toast({
      variant: 'info',
      message: `ID: ${getSelectedItem.value.id}<br />Path: ${getSelectedItem.value.path}`,
      infinite: true
    })
  }
}
</script>

<template>
  <aside
    :id="getSelectedItem?.id"
    class="details has-background-white"
    :class="{ 'details--invisible': !props.visible || (isComparing && !getGlobalSelectionCount) }"
  >
    <span class="is-hidden">{{ getSelectedItem?.id }}</span>
    <o-tooltip
      :position="props.visible ? 'right' : 'left'"
      label="Toggle details view (Ctrl+Shift+/)"
      class="toggle-menu"
      :class="{ 'toggle-menu--off': !props.visible || (isComparing && !getGlobalSelectionCount) }"
    >
      <o-button
        v-keyboard-shortcut="'Ctrl+Shift+/'"
        variant="secondary"
        class="px-3 is-clickable"
        :icon-left="props.visible ? 'chevron-right' : 'chevron-left'"
        icon-class="is-size-4"
        size="small"
        title="Toggle details view"
        rounded
        @click="emit('toggle-visibility')"
      />
    </o-tooltip>

    <fieldset :disabled="props.disabled || readonly || settings.lockedMode">
      <template v-if="getGlobalSelectionCount === 1 || hasUniqueSelection">
        <o-tabs
          :key="getSelectedAnything?.id"
          v-model="selectedTab"
          type="toggle"
          class="sidebar-tabs"
          nav-tabs-class="tabs is-toggle-rounded is-justify-content-center"
          content-class="tab-content holori-scrollbar pt-0"
          @dblclick="displayHiddenInfo"
        >
          <o-tab-item
            v-if="!props.generalTab ? getSelectedAnything?.type !== 'Node' : true"
            value="general"
            label="General"
            icon="information"
          >
            <ScrollToTop tag="div" class-name="scrollable-tab">
              <div class="pt-3">
                <NodeDetails v-if="getSelectedNode && getSelectedNode?.type !== 'control-point'" />
                <EdgeDetails v-else-if="getSelectedEdge" @select="emit('select', $event)" />
                <GroupDetails v-else-if="getSelectedGroup" @add-duplicate="emit('add-duplicate')" />
                <o-field v-if="groupId" label-class="is-flex is-align-items-center">
                  <template #label>
                    <o-icon icon="file-tree-outline" class="mr-2" />
                    Groups Hierarchy
                  </template>
                  <div class="is-flex is-flex-direction-column is-gap-3">
                    <NodeLink
                      v-for="childGroup in parentGroups"
                      :key="childGroup.id"
                      :model="childGroup"
                      display-hierarchy
                      @select="emit('select', $event)"
                    />
                  </div>
                </o-field>
                <ItemChildren v-if="getSelectedItem" @select="emit('select', $event)" />
                <ScalewayPricing v-if="isScalewayInstance" />
                <ItemNotes />
              </div>
            </ScrollToTop>
          </o-tab-item>
          <o-tab-item v-if="hasTerraform" value="terraform" label="Details" icon="view-list">
            <ScrollToTop tag="div" class-name="scrollable-tab">
              <Terraform>
                <div
                  v-if="props.costs[getSelectedAnything?.id]"
                  class="has-background-white-ter is-flex is-flex-direction-column is-align-items-center is-border-radius-xl p-5"
                >
                  <span class="is-size-4 has-text-weight-bold">
                    {{
                      formatPrice(
                        props.costs[getSelectedAnything?.id].value,
                        props.costs[getSelectedAnything?.id].currency
                      )
                    }}/month
                  </span>
                  <span class="is-size-5">
                    {{ lastMonth }}
                  </span>
                </div>
              </Terraform>
            </ScrollToTop>
          </o-tab-item>
          <template v-if="!props.hideStyle">
            <o-tab-item
              v-if="getSelectedItem && getSelectedItem.type !== 'control-point'"
              value="style"
              label="Style"
              icon="palette-swatch"
            >
              <ItemStyle />
            </o-tab-item>
            <o-tab-item v-if="getSelectedEdge" value="style" label="Style" icon="palette-swatch">
              <EdgeStyle />
            </o-tab-item>
          </template>
        </o-tabs>
      </template>
      <template v-else-if="getGlobalSelectionCount > 1 && !hasUniqueSelection">
        <div class="p-5">
          <o-notification type="info" variant="info">
            You can select an item on the left to see its details.
          </o-notification>
        </div>
      </template>
    </fieldset>
    <ProjectDetails v-if="!getGlobalSelectionCount && !isComparing && !props.hideProject" />
  </aside>
</template>

<style scoped>
.details {
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
  max-height: 70vh;
  top: 195px !important;
  left: auto;
  position: fixed;
  right: 0;
  width: 26.5rem !important;
  z-index: 3;
  transition: transform 0.3s ease;
}
.details--invisible {
  transform: translateX(100%);
}
.details:not(:empty) {
  border: 1px solid hsl(0, 0%, 86%);
  border-right: 0;
  box-shadow: 5px 0 13px 3px rgba(10, 10, 10, 0.1);
}

:deep(.tab-content) {
  overflow: hidden;
}
.scrollable-tab {
  max-height: calc(70vh - 42px);
}

:deep(.tabs) {
  margin-top: -20px;
}

:deep(.tabs-item a) {
  background-color: #fff;
}
.toggle-menu {
  position: absolute;
  top: 50%;
  left: 0;
  transform: translate(-50%, -50%);
  transition: transform 0.3s ease;
  z-index: 20;
}
.toggle-menu .button {
  background-color: hsl(0, 0%, 100%) !important;
  border-color: hsl(0, 0%, 86%) !important;
  opacity: 1 !important;
}
.toggle-menu .button:hover {
  border-color: hsl(0, 0%, 71%) !important;
  color: hsl(0, 0%, 21%) !important;
}
.toggle-menu--off {
  transform: translate(-100%, -50%);
}
</style>
