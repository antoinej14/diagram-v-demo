<script setup>
import { onBeforeMount, onMounted, ref } from 'vue'
import { OIcon } from '@oruga-ui/oruga-next'

import EventBus from '@/common/eventBus'

import ScrollToTop from '@/components/ScrollToTop.vue'
import NodeLink from '@/components/diagram/NodeLink.vue'

defineOptions({
  name: 'DiagramDiffList'
})

const emit = defineEmits(['loaded'])

const diffStates = ['added', 'updated', 'removed']

const added = ref([])
const removed = ref([])
const updated = ref([])
const open = ref({
  added: true,
  updated: true,
  removed: true
})

onMounted(() => {
  EventBus.on('reloadDiffList', load)
})

onBeforeMount(() => {
  EventBus.remove('reloadDiffList', load)
})

function load() {
  const items = window.graph.getElements().map((item) => item.attributes)

  added.value = items.filter((item) => item.added)
  removed.value = items.filter((item) => item.removed)
  updated.value = items.filter((item) => item.updated)

  emit('loaded')
}

function items(diffState) {
  switch (diffState) {
    case 'added':
      return added.value
    case 'removed':
      return removed.value
    case 'updated':
      return updated.value
  }
}

defineExpose({ load })
</script>

<template>
  <ScrollToTop tag="aside" class-name="diff">
    <div class="pt-5 px-4">
      <div v-for="diffState in diffStates" :key="diffState" class="mb-3">
        <p
          class="menu-label is-flex is-align-items-center"
          @click="open[diffState] = !open[diffState]"
        >
          {{ diffState }}

          <span :class="`ml-1 diff-state diff-state--${diffState}`" />

          <o-icon class="ml-auto" :icon="open[diffState] ? 'chevron-up' : 'chevron-down'" />
        </p>
        <transition name="slide">
          <ul v-if="open[diffState]" class="menu-list">
            <li v-for="item in items(diffState)" :key="item.id">
              <NodeLink :model="item" @select="$emit('select', $event)" />
            </li>
          </ul>
        </transition>
      </div>
    </div>
  </ScrollToTop>
</template>

<style scoped>
.diff {
  max-height: calc(70vh - var(--tabs-height));
  max-width: 350px;
  user-select: none;
  position: static;
}
.diff-state {
  display: block;
  border-radius: 7px;
  height: 14px;
  width: 14px;
}
.diff-state--added {
  background-color: #2ecc71;
}
.diff-state--removed {
  background-color: #e74c3c;
}
.diff-state--updated {
  background-color: #f1c40f;
}
</style>
