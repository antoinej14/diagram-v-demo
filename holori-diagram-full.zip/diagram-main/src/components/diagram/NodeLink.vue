<script setup>
import { computed } from 'vue'
import { OButton, OField, OIcon } from '@oruga-ui/oruga-next'

const props = defineProps({
  model: {
    type: Object,
    required: true
  },
  displayHierarchy: {
    type: Boolean,
    required: false,
    default: false
  }
})

const emit = defineEmits(['select'])

const displayName = computed(() => {
  const { id, name } = props.model
  return name || id
})

const icon = computed(() => {
  const { type, source } = props.model
  if (source) {
    return 'vector-line'
  }
  return type === 'Group' ? 'group' : 'server'
})

function highlightItem() {
  window.graph.getCell(props.model.id).findView(window.paper).highlight()
}

function unhighlightItem() {
  window.graph.getCell(props.model.id).findView(window.paper).unhighlight()
}

function selectItem() {
  emit('select', props.model.id)
}
</script>

<template>
  <div
    class="is-flex is-flex-direction-column is-align-items-center link"
    :class="{ 'mb-3': !displayHierarchy }"
  >
    <o-field class="full-width mb-0">
      <span v-if="model.image" class="button item-image">
        <img :src="model.image" :alt="model.id" height="24" width="24" />
      </span>
      <o-button v-else :icon-left="icon" />
      <span
        class="name px-2 is-flex is-align-items-center ellipsis"
        title="Hover to highlight this item"
        @mouseenter="highlightItem"
        @mouseleave="unhighlightItem"
      >
        <span class="ellipsis">{{ displayName }}</span>
      </span>
      <o-button
        variant="primary"
        class="no-disable"
        icon-left="selection-ellipse-arrow-inside"
        title="Select this item"
        @click="selectItem"
      />
    </o-field>

    <o-icon v-if="model.parentId && displayHierarchy" icon="chevron-up" />
  </div>
</template>

<style scoped>
.link {
  max-width: 390px;
}
.item-image {
  padding: 0;
  width: 40px;
}
.item-image img {
  height: 24px;
  width: 24px;
}
.name {
  border: 1px solid var(--secondary-light-lightgray2);
  border-left-width: 0;
  flex: 1;
}

.button.is-primary.no-disable {
  cursor: pointer !important;
  opacity: 1 !important;
}
</style>
