<script setup>
import { ref, computed, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, ONotification } from '@oruga-ui/oruga-next'

import supported from '@/common/tfstate'

import { useProjectStore } from '@/store/project'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import TerraformDocumentationEntry from '@/components/diagram/export/TerraformDocumentationEntry.vue'
import ItemImage from '@/components/diagram/details/ItemImage.vue'

import TfState from '../details/TfState.vue'

const props = defineProps({
  dataSource: {
    type: String,
    required: false,
    default: 'project'
  },
  data: {
    type: Object,
    required: false,
    default: () => ({})
  },
  selectFirst: {
    type: Boolean,
    required: false,
    default: true
  }
})

const loading = ref(true)
const items = ref([])
const activeItem = ref(null)
const supportedItem = ref(false)
const allConfigDetails = ref(false)

const projectStore = useProjectStore()
const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()

const mappingStore = useMappingStore()

const { project } = storeToRefs(projectStore)
const { synchronizationDiagram } = storeToRefs(providerAccountsStore)

const data = computed(() => {
  if (props.dataSource === 'project') {
    return project.value.diagram
  } else if (props.dataSource === 'provider-account') {
    return synchronizationDiagram.value
  } else if (props.dataSource === 'props') {
    return props.data
  }

  return '{}'
})

const supportedProducts = Object.keys(supported)

function load() {
  loading.value = true

  const parsedData = typeof data.value === 'string' ? JSON.parse(data.value) : data.value
  const { nodes, groups, edges } = parsedData
  diagramStore.setData({
    nodes,
    groups,
    edges
  })

  if (!nodes || !groups) {
    return
  }

  const diagramItems = [...nodes, ...groups]
  const supportedItems = diagramItems
    .filter((item) => !('location' in item))
    .sort((a, b) => (a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1))

  items.value = supportedItems

  if (props.selectFirst) {
    activeItem.value = supportedItems[0] || null
  }

  loading.value = false
}

load()

defineExpose({ load })

watch(activeItem, (newActiveItem) => {
  if (!newActiveItem) {
    return
  }

  const { path } = newActiveItem

  if (!path) {
    supportedItem.value = false
    allConfigDetails.value = true

    return
  }

  const { providerName, productName } = mappingStore.splitPath(path)
  const product = `${providerName}/${productName}`

  if (!supportedProducts.includes(product)) {
    supportedItem.value = false
    allConfigDetails.value = true
  } else {
    supportedItem.value = true
  }
})
</script>

<template>
  <div class="is-flex export-list-view">
    <div class="fixed box is-flex-1 mb-0 px-0">
      <template v-if="!loading">
        <ul v-if="items.length" class="menu-list">
          <li v-for="item in items" :key="item.id">
            <a
              href="#"
              class="is-flex is-align-items-center"
              :class="{ 'is-active': activeItem?.id === item.id }"
              @click.prevent="activeItem = item"
            >
              <img v-if="item.image" :src="item.image" :alt="item.id" class="entry-icon mr-3" />
              <span>
                {{ item.name }}
              </span>
            </a>
          </li>
        </ul>
        <o-notification v-else variant="info" type="info" class="mx-5">
          No supported product.
        </o-notification>
      </template>
      <div v-else class="is-flex is-flex-direction-column is-gap-3 px-5">
        <o-skeleton v-for="i in Array(5)" :key="i" class="mb-0" />
      </div>
    </div>
    <transition name="fade-x">
      <div v-if="activeItem" :key="activeItem.id" class="box details ml-5 is-clipped is-flex-1">
        <div class="is-flex is-justify-content-flex-end is-gap-3 mb-5">
          <o-button
            v-if="supportedItem && !activeItem.location"
            variant="secondary"
            size="small"
            @click="allConfigDetails = !allConfigDetails"
          >
            {{ allConfigDetails ? 'Back to less details' : 'See all config details' }}
          </o-button>
          <o-button
            variant="secondary"
            class="px-3"
            icon-left="close"
            size="small"
            rounded
            @click="activeItem = null"
          />
        </div>
        <TfState v-if="!allConfigDetails" :item="activeItem" />
        <template v-else>
          <ItemImage :item="activeItem" />
          <TerraformDocumentationEntry
            v-for="(value, key) in activeItem?.terraform"
            :key="`${activeItem?.id}-${key}`"
            :field="key"
            :value="value"
            :node="activeItem"
          />
          <strong>Path:</strong> {{ activeItem?.path }}
        </template>
      </div>
    </transition>
  </div>
</template>

<style scoped>
.fixed {
  position: sticky;
  top: calc(var(--navbar-height) + 1.5rem);
}
.entry-icon {
  border-radius: 5px;
  max-height: 30px;
  width: 30px;
}
.details {
  position: sticky;
  top: 10px;
  max-height: calc(100vh - 40px);
  overflow-y: visible !important;
}

.export-list-view .value {
  width: 100%;
}
</style>
