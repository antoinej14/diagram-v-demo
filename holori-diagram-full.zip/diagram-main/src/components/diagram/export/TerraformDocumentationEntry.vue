<script setup>
import { computed } from 'vue'

import { useDiagramStore } from '@/store/diagram.js'

const props = defineProps({
  /**
   * The object representing the node from the diagram.
   */
  node: {
    type: Object,
    required: true
  },
  /**
   * The 'key' of the field, from the Terraform JSON file.
   */
  field: {
    type: String,
    required: true
  },
  /**
   * The value attributed to the node for this field.
   */
  value: {
    required: true,
    validator: () => true
  },
  parents: {
    type: Array,
    required: false,
    default: () => []
  }
})

const diagramStore = useDiagramStore()

const isNested = computed(() => typeof props.value === 'object')

const getUpdatedValue = computed(() => {
  const fullPath = [...props.parents, props.field].join('/')
  return diagramStore.getUpdatedTerraformKey(props.node.id, fullPath)
})
</script>

<template>
  <div class="is-flex is-flex-wrap-wrap entry">
    <div
      class="is-flex is-align-items-center is-gap-2 has-text-weight-bold"
      :class="{ 'full-width': isNested }"
    >
      {{ props.field }}

      <o-tooltip
        v-if="getUpdatedValue !== undefined"
        :label="`Previous value: ${getUpdatedValue}`"
        teleport
      >
        <span class="is-block updated" />
      </o-tooltip>
    </div>
    <div class="pl-5 entry-value" :class="{ 'full-width': isNested }">
      <template v-if="isNested">
        <TerraformDocumentationEntry
          v-for="(subvalue, subkey) in props.value"
          :key="`${node.id}-${field}-${subkey}`"
          :field="subkey + ''"
          :value="subvalue"
          :node="props.node"
          :parents="[...props.parents, props.field]"
        />
      </template>
      <template v-else>
        {{ props.value }}
      </template>
    </div>
  </div>
</template>

<style scoped>
.entry:not(:last-child) {
  border-bottom: 1px solid #00000021;
  margin-bottom: 0.75rem;
  padding-bottom: 0.75rem;
}
.updated {
  background-color: #f1c40f;
  border-radius: 10px;
  height: 20px;
  width: 20px;
}
.entry-value {
  word-break: break-all;
}
</style>
