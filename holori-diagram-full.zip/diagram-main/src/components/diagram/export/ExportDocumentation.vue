<script setup>
import { computed, ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, OIcon, OLoading } from '@oruga-ui/oruga-next'

import readDiagram from '@/common/diagram/options/methods/read'
import { exportDiagramImage } from '@/common/diagram/utils'

import { useProjectStore } from '@/store/project'
import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

import { useInitDiagram } from '@/components/diagram/hooks/init.js'

import TerraformDocumentationEntry from './TerraformDocumentationEntry.vue'

const thumbnail = ref('')
const data = ref({})
const costs = ref({})
const loadingImages = ref(0)

const canvasRef = ref(null)

const loadingImagesSteps = 2

const { initDiagram } = useInitDiagram({ canvasRef })

const projectStore = useProjectStore()
const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { project, projectDiagram } = storeToRefs(projectStore)

const resources = computed(() => {
  const { nodes, groups } = data.value

  if (Array.isArray(nodes) && Array.isArray(groups)) {
    const noEmptyTextBoxes = nodes.filter(
      (node) => node.type !== 'TextBox' || (node.type === 'TextBox' && node.notes !== '')
    )
    return [...noEmptyTextBoxes, ...groups]
  }

  return []
})

watch(loadingImages, (val) => {
  if (val === loadingImagesSteps) {
    setTimeout(() => {
      loadingImages.value = 0
    }, 200)
  }
})

function load() {
  const newData = projectDiagram.value

  if (newData === JSON.stringify(data.value)) {
    return
  }

  data.value = JSON.parse(newData)
  data.value.nodes = data.value.nodes
    .sort((a, b) => (a.name < b.name ? -1 : 1))
    .filter((node) => node.type !== 'TextBox')

  generateImage()
}

function generateImage() {
  const diagram = JSON.parse(projectDiagram.value)

  initDiagram()
  readDiagram(diagram, window.graph, window.paper)
  window.paper.unfreeze()

  loadingImages.value = 1

  exportDiagramImage(
    false,
    'image/png',
    (result) => {
      thumbnail.value = result
      loadingImages.value++
    },
    null,
    false
  )
}

function formatDate(date) {
  const newDate = new Date(date)
  return newDate.toLocaleDateString()
}

function print() {
  window.print()
}

// Created.
diagramStore.loadCompanies().then((companies) => {
  mappingStore.getAllRegions(companies).then(() => {
    load()
  })
})
</script>

<template>
  <div class="is-relative is-flex-grow-1 is-flex is-flex-direction-column">
    <div class="is-absolute z-1">
      <canvas id="jointjs-canvas" />
      <div ref="canvasRef" class="canvas" />
    </div>

    <div id="to-print" class="p-5">
      <div class="box">
        <div class="my-auto">
          <h1 class="has-text-centered is-size-1 has-text-semibold mb-6">
            {{ project.name }}
          </h1>
          <div class="has-text-centered">
            <strong>Created:</strong>
            {{ formatDate(project.created) }}
          </div>
          <div v-if="project.last_modified" class="has-text-centered">
            <strong>Last modification:</strong>
            {{ formatDate(project.last_modified) }}
          </div>
        </div>
      </div>
      <div class="box">
        <template v-if="project.notes">
          <h2 class="is-size-3 my-4">Notes</h2>
          <p class="has-text-justified my-5 notes">
            {{ project.notes }}
          </p>
        </template>
        <h2 class="is-size-3 my-4">Thumbnail</h2>

        <img :src="thumbnail" alt="Project thumbnail" class="is-block max-width-full m-auto" />
      </div>
      <div ref="add-watermark1" class="box is-relative">
        <h2 class="is-size-3 my-4">Resources</h2>
        <table>
          <thead>
            <tr>
              <th style="width: 10%">Image</th>
              <th>Name</th>
              <th style="width: 30%">Location</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="node in resources" :key="node.id">
              <td class="py-2 node-image">
                <img v-if="node.image" :src="node.image" :alt="node.id" class="node-image" />
                <o-icon v-else-if="node.type === 'TextBox'" icon="text" />
                <o-icon
                  v-else-if="node.type === 'Group'"
                  :icon="node.location ? 'map-marker' : 'group'"
                  class="node-image"
                />
              </td>
              <td class="py-2">
                <template v-if="node.type === 'TextBox'"> Text Box </template>
                <component
                  :is="node.terraform ? 'a' : 'span'"
                  v-else
                  :href="node.terraform ? `#${node.id}` : undefined"
                >
                  {{ node.name }}
                </component>
              </td>
              <td class="py-2">
                {{ mappingStore.findFirstLocationForDisplay(node.groupId, data.value) }}
              </td>
              <td class="py-2">
                {{ costs[node.id] }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div ref="add-watermark2" class="box is-relative">
        <h2 class="is-size-3 my-4">Terraform</h2>
        <div v-for="node in resources" :key="node.id">
          <template v-if="node.terraform_path && node.terraform">
            <h3 class="is-size-4 mb-3">
              <a :name="node.id">{{ node.name }}</a>
            </h3>

            <div class="mt-3 mb-5 pl-5">
              <TerraformDocumentationEntry
                v-for="(value, key) in node.terraform"
                :key="`${node.id}-${key}`"
                :field="key"
                :value="value"
                :node="node"
              />
            </div>
          </template>
        </div>
      </div>
    </div>
    <o-button
      variant="primary"
      icon-left="printer"
      class="print-button ml-auto mt-5"
      title="Print documentation"
      @click="print"
    >
      Print
    </o-button>
    <o-loading :active="loadingImages > 0">
      <div class="is-flex is-flex-direction-column is-justify-content-center is-align-items-center">
        <o-icon icon="loading" spin size="large" />
        <p class="my-5">Please wait while we are generating the documentation&hellip;</p>
        <progress class="progress is-primary" :value="loadingImages" :max="loadingImagesSteps" />
      </div>
    </o-loading>
  </div>
</template>

<style scoped>
#to-print {
  margin-top: var(--navbar-height);
}
.box {
  display: flex;
  flex-direction: column;
}
.box:not(:last-child) {
  page-break-after: always;
}
.progress {
  width: 200px;
}
.notes {
  text-indent: 2.5rem;
}
td {
  vertical-align: middle;
}
.node-image {
  width: 30px;
}
.canvas {
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: 100vh;
}
.z-1 {
  transform: translate(-100000px, -100000px);
  z-index: -1;
}
</style>

<style>
.print-button {
  position: sticky;
  bottom: 20px;
  right: 0;
}
@media print {
  body {
    background-color: #fff;
    padding: 0;
  }
  .nav-bar,
  .sidebar,
  .print-button,
  .notification,
  .canvas,
  .jointjs-paper {
    display: none !important;
  }
  .under-navbar {
    margin-top: 0 !important;
  }
  #to-print {
    margin-top: 0 !important;
  }
  .p-5 {
    padding: 0 !important;
  }
  .box {
    background-color: transparent;
    box-shadow: none;
    min-height: 100vh;
    padding: 0;
  }
  .box:first-child {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-direction: column !important;
  }
}
</style>
