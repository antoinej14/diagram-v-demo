<script setup>
import { ref, computed } from 'vue'
import { storeToRefs } from 'pinia'
import { OButton, ODropdown } from '@oruga-ui/oruga-next'

import { useMappingStore } from '@/store/mapping'

const props = defineProps({
  menuData: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['select'])

const selected = ref([])

const mappingStore = useMappingStore()

const { providersData } = storeToRefs(mappingStore)

const providers = computed(() => {
  const companies = new Set()
  props.menuData.forEach((entry) => {
    const [name] = entry.name.split('.')
    companies.add(name)
  })

  return Array.from(companies)
    .map((company) => ({
      name: providersData.value[company]?.name || company,
      company
    }))
    .sort((a, b) => (a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1))
})

function update(selectedCompanies) {
  emit('select', selectedCompanies)
}
</script>

<template>
  <o-dropdown v-model="selected" multiple expanded scrollable @change="update">
    <template #trigger>
      <o-button
        variant="secondary"
        type="button"
        class="full-width"
        icon-right="chevron-down"
        rounded
      >
        <span>Providers ({{ selected.length }})</span>
      </o-button>
    </template>

    <o-dropdown-item
      v-for="provider in providers"
      :key="provider.company"
      :value="provider.company"
      class="is-flex is-align-items-center is-capitalized"
    >
      <img :src="`/diagram/${provider.company}.svg`" class="company-icon mr-3" />
      {{ provider.name }}
    </o-dropdown-item>
  </o-dropdown>
</template>

<style scoped>
.company-icon {
  max-height: 20px;
  width: 20px;
}
</style>
