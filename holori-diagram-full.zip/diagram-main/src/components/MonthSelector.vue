<script setup>
import { computed, ref, watch } from 'vue'
import moment from 'moment'
import { OButton, ODatepicker } from '@oruga-ui/oruga-next'

import { GRANULARITIES } from '@/common/enums.js'

const props = defineProps({
  min: {
    type: Date,
    required: false,
    default: () => null
  },
  max: {
    type: Date,
    required: false,
    default: () => null
  },
  limit: {
    type: Boolean,
    required: false,
    default: true
  },
  softLimit: {
    type: Boolean,
    required: false,
    default: true
  },
  expanded: {
    type: Boolean,
    required: false,
    default: false
  },
  placement: {
    type: String,
    required: false,
    default: 'bottom'
  },
  loading: {
    type: Boolean,
    required: false,
    default: false
  },
  type: {
    type: String,
    required: false,
    default: GRANULARITIES.MONTHLY
  }
})

const model = defineModel()
const dropdownActive = defineModel('active')

const display = computed(() => {
  // this is used only in MONTHLY
  if (model.value) {
    return moment(model.value).format('MMM YYYY')
  }

  return 'Pick month'
})

let minDate = computed(() =>
  props.min ? moment(props.min).toDate() : moment('2024-01-01').toDate()
)

const maxDate = computed(() => {
  if (props.max) {
    return props.max
  }
  if (props.limit) {
    return moment().subtract(1, 'month').endOf('month').toDate()
  }
  if (props.softLimit) {
    return moment().endOf('month').toDate()
  }
  return null
})

function updateMinDate() {
  const min = moment(props.min)
  const value = moment(model.value)
  if (value.isBefore(min)) {
    model.value = min.toDate()
  }
}

if (props.min) {
  updateMinDate()
}

const yearSelection = ref(moment(model.value).format('YYYY'))

const years = [
  moment().format('YYYY'),
  moment().subtract(1, 'year').format('YYYY'),
  moment().subtract(2, 'year').format('YYYY'),
  moment().subtract(3, 'year').format('YYYY'),
  moment().subtract(4, 'year').format('YYYY'),
  moment().subtract(5, 'year').format('YYYY')
]

watch(() => props.min, updateMinDate)

watch(
  () => props.type,
  (newType) => {
    if (newType === GRANULARITIES.YEARLY) {
      model.value = moment(model.value).startOf('year').toDate()
    } else if (newType === GRANULARITIES.MONTHLY) {
      model.value = moment(model.value).startOf('month').toDate()
    } else {
      model.value = moment(model.value).toDate()
    }
  }
)

watch(yearSelection, (newValue) => {
  if (newValue) {
    model.value = moment(newValue).toDate()
  }
})
</script>

<template>
  <o-dropdown
    v-if="props.type === GRANULARITIES.MONTHLY"
    v-model:active="dropdownActive"
    :class="{ 'full-width': props.expanded }"
    :trigger-class="props.expanded ? 'full-width' : ''"
    menu-class="is-z-99"
    teleport-class="is-z-99"
    :position="props.placement + '-left'"
    teleport
  >
    <template #trigger="{ active }">
      <o-button
        :class="{ 'full-width': props.expanded }"
        variant="secondary"
        :icon-left="props.loading ? 'loading' : 'calendar'"
        :icon-right="active ? 'chevron-up' : 'chevron-down'"
      >
        {{ display }}
      </o-button>
    </template>

    <o-datepicker
      v-model="model"
      prev-button-class="is-small"
      next-button-class="is-small"
      :select-classes="{ rootClass: 'is-small' }"
      box-class="p-3"
      :dropdown-classes="{ menuClass: 'no-shadow' }"
      type="month"
      :min-date="minDate"
      :max-date="maxDate"
      inline
    />
  </o-dropdown>
  <!--  YEARLY -->
  <o-select v-else v-model="yearSelection">
    <option v-for="year in years" :key="year" :value="year">
      {{ year }}
    </option>
  </o-select>
</template>
