<script setup>
import { ref } from 'vue'
import { OButton } from '@oruga-ui/oruga-next'

const props = defineProps({
  tag: {
    type: String,
    required: false,
    default: 'div'
  },
  className: {
    type: String,
    required: false,
    default: ''
  },
  noGradient: {
    type: Boolean,
    required: false,
    default: false
  }
})

const displayBackToTop = ref(false)
const containerRef = ref(null)

function detectScroll(e) {
  displayBackToTop.value = e.target.scrollTop > 0
}

function backToTop() {
  containerRef.value.scrollTo({
    top: 0,
    behavior: 'smooth'
  })
}
</script>

<template>
  <component
    :is="props.tag"
    ref="containerRef"
    class="scrollable"
    :class="{
      [className]: true,
      'scrollable--scrolled': displayBackToTop,
      'scrollable--no-gradient': props.noGradient
    }"
    @scroll="detectScroll"
  >
    <slot />

    <span class="spacer" />
    <Transition name="fade-y">
      <o-button
        v-if="displayBackToTop"
        tag="a"
        class="back-to-top"
        variant="secondary"
        icon-left="arrow-up-bold"
        size="small"
        rounded
        @click="backToTop"
      >
        Back to top
      </o-button>
    </Transition>
  </component>
</template>

<style scoped>
.scrollable {
  overflow-x: hidden;
  overflow-y: scroll;
  position: relative;
  scrollbar-color: var(--primary) #fff;
  scrollbar-width: thin;
}
.scrollable:not(.scrollable--no-gradient):before {
  content: '';
  display: block;
  background: linear-gradient(white, rgba(255, 255, 255, 0.001));
  position: sticky;
  top: 0;
  left: 0;
  height: 20px;
  width: 100%;
  margin-bottom: -20px;
  z-index: 2;
  pointer-events: none;
  transition: opacity 0.3s ease;
  opacity: 0;
}
.scrollable--scrolled:before {
  opacity: 1;
}
.spacer {
  display: block;
  height: 30px;
}
.back-to-top {
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.25) !important;
  position: sticky;
  bottom: 10px;
  left: 50%;
  transform: translateX(-50px);
  width: 100px;
  opacity: 1 !important;
  cursor: pointer !important;
}
</style>
