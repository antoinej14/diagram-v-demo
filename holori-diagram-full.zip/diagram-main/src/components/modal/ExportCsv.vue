<script setup>
import { ref, onMounted } from 'vue'
import { OButton } from '@oruga-ui/oruga-next'

const emit = defineEmits(['close'])

const props = defineProps({
  title: {
    type: String,
    required: true
  }
})

const separators = [
  {
    label: 'Semi-colon',
    value: ';'
  },
  {
    label: 'Comma',
    value: ','
  }
]

const numberFormats = [
  {
    label: 'International (1234.56)',
    value: 'international'
  },
  {
    label: 'European (1234,56)',
    value: 'european'
  }
]

const includeLabels = ref(true)
const separator = ref(separators[0].value)
const numberFormat = ref(numberFormats[0].value)

const downloadRef = ref(null)

function download() {
  emit('close', {
    includeLabels: includeLabels.value,
    separator: separator.value,
    numberFormat: numberFormat.value
  })
}

onMounted(() => {
  downloadRef.value.$el.focus()
})
</script>

<template>
  <form class="modal-card mx-auto" @submit.prevent="download">
    <header class="modal-card-head">
      <p class="modal-card-title">Download {{ props.title }} table data</p>
      <o-button
        icon-left="close"
        class="ml-auto pl-4 is-border-radius-full"
        @click="emit('close')"
      />
    </header>
    <section class="modal-card-body">
      <p class="mb-5">
        You can specify the name of the file after clicking the <strong>Download</strong> button.
      </p>

      <o-field>
        <o-switch v-model="includeLabels"> Include labels </o-switch>
      </o-field>

      <o-field label="Separator">
        <o-select v-model="separator" :options="separators" />
      </o-field>

      <o-field label="Number format">
        <o-select v-model="numberFormat" :options="numberFormats" />
      </o-field>
    </section>
    <footer class="modal-card-foot is-justify-content-flex-end">
      <o-button variant="secondary" @click="emit('close', false)"> Cancel </o-button>
      <o-button ref="downloadRef" variant="primary" icon-left="check" type="submit">
        Download
      </o-button>
    </footer>
  </form>
</template>
