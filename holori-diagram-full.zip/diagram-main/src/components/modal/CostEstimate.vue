<script setup>
import { computed } from 'vue'
import { storeToRefs } from 'pinia'
import {
  OButton,
  OIcon,
  ONotification,
  OTable,
  OTableColumn,
  OTooltip
} from '@oruga-ui/oruga-next'

import { formatPrice } from '@/common/diagram/utils.js'
import {
  estimateDiagramCost,
  PRICING_CURRENCY
} from '@/common/diagram/scaleway-cost-estimate.js'
import { PRICING_SNAPSHOT_DATE } from '@/common/diagram/scaleway-static-pricing.js'

import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'

defineOptions({
  name: 'CostEstimateModal'
})

const emit = defineEmits(['close'])

const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()
const { getNodes } = storeToRefs(diagramStore)

function labelFor(path) {
  if (!path) return 'Unknown element'
  const { productName, providerName } = mappingStore.splitPath(path)
  return `${providerName} · ${productName}`
}

// Static snapshot, so there's nothing to await, no network, nothing to fail.
const result = computed(() => estimateDiagramCost(getNodes.value))

const pricedItems = computed(() =>
  result.value.items
    .filter((item) => item.status === 'priced' || item.status === 'estimated')
    .sort((a, b) => b.monthlyPriceEur - a.monthlyPriceEur)
)

const rateOnlyItems = computed(() => result.value.items.filter((item) => item.status === 'rate-only'))

const unsupportedItems = computed(() =>
  result.value.items.filter((item) => item.status === 'unsupported')
)

const unsupportedSummary = computed(() => {
  const counts = {}
  for (const item of unsupportedItems.value) {
    const label = labelFor(item.path)
    counts[label] = (counts[label] || 0) + 1
  }
  return Object.entries(counts).map(([label, count]) => ({ label, count }))
})

function closePopup() {
  emit('close')
}
</script>

<template>
  <div class="modal-card cost-estimate-modal" style="width: auto">
    <header class="modal-card-head">
      <p class="modal-card-title">
        <o-icon icon="currency-usd" class="mr-2" />
        Cost estimate (preview)
      </p>
      <o-button icon-left="close" class="ml-auto pl-4 is-border-radius-full" @click="closePopup" />
    </header>
    <section class="modal-card-body">
      <o-notification variant="info" :closable="false" class="mb-4">
        Estimate based on a snapshot of Scaleway's public {{ PRICING_CURRENCY }} list prices
        (as of {{ PRICING_SNAPSHOT_DATE }}, hard-coded for this demo rather than fetched live).
        Compute instances use the type you chose in an element's "Estimated pricing" panel, or
        default to a small reference instance when none is set. Load balancers and database
        nodes don't have a size picker yet, so they always show a reference size. Object &amp;
        block storage are billed per GB actually stored, so they're shown as a rate rather than
        folded into the total below.
      </o-notification>

      <div class="cost-table-wrapper">
        <o-table v-show="pricedItems.length" :data="pricedItems" striped>
          <o-table-column v-slot="{ row }" field="name" label="Element">
            {{ row.name || 'Untitled' }}
          </o-table-column>
          <o-table-column v-slot="{ row }" field="sku" label="Matched SKU">
            {{ row.instanceType }}
            <o-tooltip
              v-if="row.estimated"
              label="No size chosen yet on this element — showing a reference size as a placeholder."
            >
              <span class="tag is-warning is-size-7 ml-1">reference size</span>
            </o-tooltip>
          </o-table-column>
          <o-table-column v-slot="{ row }" field="specs" label="Specs">
            <template v-if="row.vcpu">{{ row.vcpu }} vCPU · {{ row.memory }} GB RAM</template>
            <template v-else>&mdash;</template>
          </o-table-column>
          <o-table-column v-slot="{ row }" field="monthly" label="Cost / month" numeric>
            {{ formatPrice(row.monthlyPriceEur, PRICING_CURRENCY) }}
          </o-table-column>
        </o-table>

        <o-notification v-if="!pricedItems.length" variant="warning" :closable="false">
          Nothing priceable on this diagram yet. Drag a Scaleway compute instance, load
          balancer, or managed database onto the canvas to see it appear here.
        </o-notification>
      </div>

      <div v-if="rateOnlyItems.length" class="mt-4">
        <p class="is-size-7 has-text-weight-semibold mb-1">
          Priced by rate, not included in the total (usage-based, no size set on the diagram):
        </p>
        <o-table :data="rateOnlyItems" striped>
          <o-table-column v-slot="{ row }" field="name" label="Element">
            {{ row.name || 'Untitled' }}
          </o-table-column>
          <o-table-column v-slot="{ row }" field="tier" label="Tier">
            {{ row.tierLabel }}
          </o-table-column>
          <o-table-column v-slot="{ row }" field="rate" label="Rate" numeric>
            {{ formatPrice(row.rateEur, PRICING_CURRENCY) }} {{ row.unitLabel }}
          </o-table-column>
        </o-table>
      </div>

      <div v-if="unsupportedSummary.length" class="mt-4 is-size-7 has-text-grey">
        Not covered in this preview: {{ unsupportedItems.length }} element(s) &mdash;
        <span v-for="(entry, index) in unsupportedSummary" :key="entry.label">
          {{ entry.label }} ({{ entry.count }})<span v-if="index < unsupportedSummary.length - 1">, </span>
        </span>
      </div>
    </section>
    <footer class="modal-card-foot is-flex is-flex-direction-column is-align-items-center">
      <div
        class="has-background-white-ter is-flex is-flex-direction-column is-align-items-center is-border-radius-xl p-5"
        style="width: 100%"
      >
        <span class="is-size-4 has-text-weight-bold">
          {{ formatPrice(result.totals.monthlyPriceEur || 0, PRICING_CURRENCY) }}/month
        </span>
        <span class="is-size-6">
          {{ formatPrice(result.totals.hourlyPriceEur || 0, PRICING_CURRENCY) }}/hour
        </span>
        <span class="is-size-7 has-text-grey mt-2">
          {{ result.totals.pricedCount || 0 }} of {{ result.totals.totalNodes || 0 }} elements in the
          total
          <template v-if="result.totals.estimatedCount">
            ({{ result.totals.estimatedCount }} using a reference size)
          </template>
          <template v-if="result.totals.rateOnlyCount">
            &middot; {{ result.totals.rateOnlyCount }} priced by rate only
          </template>
        </span>
      </div>
    </footer>
  </div>
</template>

<style scoped>
.cost-estimate-modal {
  min-width: 44rem;
  max-width: 90vw;
}
.cost-table-wrapper {
  min-height: 4rem;
  position: relative;
}
</style>
