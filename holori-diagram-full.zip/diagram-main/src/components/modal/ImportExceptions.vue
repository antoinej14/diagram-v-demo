<script setup>
import { OButton, OIcon, ONotification } from '@oruga-ui/oruga-next'

defineProps({
  exceptions: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['close'])
</script>

<template>
  <div class="modal-card">
    <header class="modal-card-head">
      <p class="modal-card-title">Exceptions while importing your project</p>
      <o-button
        icon-left="close"
        class="ml-auto pl-4 is-border-radius-full"
        @click="emit('close')"
      />
    </header>
    <section class="modal-card-body">
      <o-notification type="warning" variant="warning" icon-size="medium">
        We are sorry to inform you that there had been exceptions that occurred while importing your
        project.
        <br />
        Please find them below.
      </o-notification>

      <ul class="my-6">
        <li
          v-for="(exception, index) in props.exceptions"
          :key="'exception-' + index"
          class="is-flex is-align-items-center mb-3"
        >
          <o-icon icon="bell-alert" class="mr-3" />
          {{ exception }}
        </li>
      </ul>

      <o-notification type="info" variant="info" icon-size="medium">
        If you close this window and save your project, this message will not appear anymore.
        <br />
        Autosave has been disabled.
      </o-notification>
    </section>
  </div>
</template>
