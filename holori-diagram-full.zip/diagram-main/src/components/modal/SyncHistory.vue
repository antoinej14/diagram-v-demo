<script setup>
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { OButton, ODatepicker, OField, OTable, OTableColumn } from '@oruga-ui/oruga-next'
import moment from 'moment'

import { useProviderAccountsStore } from '@/store/provider-accounts'

import { useOrganizationMembership } from '@/common/organization-membership.js'

const emit = defineEmits(['close', 'pick'])

const route = useRoute()
const { organizationID } = useOrganizationMembership(false)
const providerID = Number(route.params.providerID)

const today = new Date()
const format = 'L HH:mm'

const loading = ref(true)
const perPage = 20
const currentPage = ref(1)
const syncDateUntil = ref(today)
const syncDateFrom = ref(moment().subtract(1, 'days').toDate())
const thumbnails = ref({})
const lastSync = ref(null)

const providerAccountsStore = useProviderAccountsStore()

watch(syncDateUntil, () => {
  updateDates()
})

watch(syncDateFrom, () => {
  updateDates()
})

function load() {
  loading.value = true
  providerAccountsStore
    .getSynchronizations(organizationID, providerID, {
      offset: (currentPage.value - 1) * perPage,
      limit: perPage
    })
    .then((data) => {
      loading.value = false

      if (!lastSync.value && currentPage.value === 1) {
        lastSync.value = data[0]
      }
    })
}

function updateDates() {
  load()
}

function pickEntry(entry) {
  const { id, imported: date } = entry

  providerAccountsStore
    .getSynchronizationDiagram(organizationID, providerID, entry.id)
    .then((diagram) => {
      emit('pick', {
        id,
        date,
        diagram
      })
      emit('close')
    })
}

function selectMostRecent() {
  pickEntry(lastSync.value)
}

function loadThumbnail(row) {
  if (!thumbnails.value[row.id]) {
    providerAccountsStore
      .getSynchronizationThumbnail(organizationID, providerID, row.id)
      .then((thumbnail) => {
        thumbnails.value[row.id] = thumbnail
      })
  }
}

load()

watch(currentPage, load)
</script>

<template>
  <div class="modal-card" style="width: auto">
    <header class="modal-card-head">
      <p class="modal-card-title">Sync history log</p>
      <o-button
        icon-left="close"
        class="ml-auto pl-4 is-border-radius-full"
        @click="emit('close')"
      />
    </header>
    <section class="modal-card-body">
      <div class="dates is-flex">
        <o-field label="Since" class="is-flex-grow-1">
          <o-datepicker v-model="syncDateFrom" :max-date="today" />
        </o-field>
        <o-field label="Until" class="is-flex-grow-1">
          <o-datepicker v-model="syncDateUntil" :max-date="today" />
        </o-field>
      </div>

      <div class="is-flex is-justify-content-center my-3">
        <o-button variant="primary" icon-left="check" @click="selectMostRecent">
          Pick the most recent version ({{ moment(lastSync?.imported).format(format) }})
        </o-button>
      </div>

      <div class="history-list">
        <o-table
          v-show="providerAccountsStore.synchronizationPagination.total"
          v-model:current-page="currentPage"
          :per-page="perPage"
          :total="providerAccountsStore.synchronizationPagination.total"
          :data="providerAccountsStore.synchronizations"
          :sticky-header="true"
          detail-key="id"
          :loading="loading"
          pagination-order="centered"
          paginated
          backend-pagination
          detailed
          striped
          @details-open="loadThumbnail"
        >
          <template #detail="{ row }">
            <img :src="thumbnails[row.id]" alt="No thumbnail available" style="max-height: 200px" />

            <o-button
              variant="primary"
              class="is-block mt-3 full-width"
              icon-left="check"
              expanded
              @click="pickEntry(row)"
            >
              Pick this entry
            </o-button>
          </template>

          <template #empty> No entries match your request. </template>

          <o-table-column v-slot="{ row }" field="sync_date" label="Date" sortable>
            {{ moment(row.imported).format(format) }}
          </o-table-column>
        </o-table>
      </div>
    </section>
  </div>
</template>

<style scoped>
.history-list {
  min-height: 25vh;
  min-width: 30vw;
}
:deep(.b-table .table tr.is-selected .chevron-cell > .icon) {
  color: #fff !important;
}
.dates {
  gap: 1rem;
}
</style>
