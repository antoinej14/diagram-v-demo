<script setup>
import { ref, onMounted } from 'vue'
import { OButton } from '@oruga-ui/oruga-next'

defineOptions({
  name: 'ConfirmationModal'
})

const emit = defineEmits(['close'])

const props = defineProps({
  title: {
    type: String,
    required: false,
    default: 'Confirm'
  },
  message: {
    type: String,
    required: false,
    default: ''
  },
  no: {
    type: String,
    required: false,
    default: 'no'
  },
  noIcon: {
    type: String,
    required: false,
    default: ''
  },
  includeNo: {
    type: Boolean,
    required: false,
    default: true
  },
  yes: {
    type: String,
    required: false,
    default: 'yes'
  },
  yesIcon: {
    type: String,
    required: false,
    default: ''
  },
  invertColors: {
    type: Boolean,
    required: false,
    default: false
  }
})

const yesRef = ref(null)

onMounted(() => {
  yesRef.value.$el.focus()
})
</script>

<template>
  <div class="modal-card mx-auto">
    <header class="modal-card-head">
      <p class="modal-card-title">
        {{ props.title }}
      </p>
      <o-button
        icon-left="close"
        class="ml-auto pl-4 is-border-radius-full"
        @click="emit('close')"
      />
    </header>
    <section class="modal-card-body">
      <p>
        {{ props.message }}
      </p>
    </section>
    <footer class="modal-card-foot is-justify-content-flex-end">
      <o-button
        v-if="props.includeNo"
        variant="secondary"
        :icon-left="props.noIcon"
        @click="emit('close', false)"
      >
        {{ props.no }}
      </o-button>
      <o-button
        v-if="props.yes"
        ref="yesRef"
        :variant="props.invertColors ? 'danger' : 'primary'"
        :icon-left="props.yesIcon"
        @click="emit('close', true)"
      >
        {{ props.yes }}
      </o-button>
    </footer>
  </div>
</template>
