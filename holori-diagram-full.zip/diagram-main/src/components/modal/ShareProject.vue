<script setup>
import { ref, computed, onMounted } from 'vue'
import { OButton, OField, OInput, OLoading } from '@oruga-ui/oruga-next'

import userApi from '@/api/modules/main-server/users'

import { useProjectStore } from '@/store/project'

import { useMixins } from '@/common/mixins'

import QuotaFeature from '@/components/QuotaFeature.vue'

const props = defineProps({
  project: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['close'])

const { toast } = useMixins()

const invitations = ref([])
const sharedWith = ref([])
const sharedWithTeam = ref(null)
const error = ref(null)
const userLoading = ref(0)
const saveLoading = ref(false)

const projectStore = useProjectStore()

const isAnythingLoading = computed(() => userLoading.value > 0)

onMounted(() => {
  invitations.value = [...props.project.invitations]
  sharedWithTeam.value = props.project.shared_with_team

  for (const userID of props.project.shared_with) {
    userLoading.value += 1
    getUser(userID)
  }
})

const patch = projectStore.patch
const getPage = projectStore.getPage

async function saveSharing() {
  error.value = null
  saveLoading.value = true

  const formData = {
    id: props.project.id,
    shared_with_team: sharedWithTeam.value,
    invitations: invitations.value.filter((email) => email !== '')
  }

  if (invitations.value !== props.project.invitations) {
    await patch(formData)
      .then(() => {
        toast({
          message: `Project "${props.project.name}" has been shared successfully!`,
          variant: 'success'
        })
      })
      .catch((err) => {
        error.value = err
      })
  }

  if (error.value) {
    saveLoading.value = false
    return
  }

  const unyokeUsers = []
  const shareWithIds = sharedWith.value.map((member) => member.id)
  for (const userID of props.project.shared_with) {
    if (!shareWithIds.includes(userID)) {
      unyokeUsers.push(userID)
    }
  }
  if (unyokeUsers.length > 0) {
    await unyokeUsers({ id: props.project.id, unyokeUsers }).catch((err) => {
      error.value = err
    })
  }

  if (error.value) {
    saveLoading.value = false
    return
  }

  saveLoading.value = false
  getPage()
  closePopup()
}

async function getUser(userID) {
  const response = await userApi.getUser(userID)
  sharedWith.value.push(response.data)
  userLoading.value--
}
function closePopup() {
  emit('close')
}
function createInvitation() {
  invitations.value.push('')
}
</script>
<template>
  <div class="modal-card" style="width: auto">
    <header class="modal-card-head">
      <p class="modal-card-title">Share project {{ props.project.name }}</p>
      <o-button icon-left="close" class="ml-auto pl-4 is-border-radius-full" @click="closePopup" />
    </header>
    <section class="modal-card-body">
      <h3 class="has-text-weight-bold mb-2">Individual user sharing</h3>

      <p v-if="!isAnythingLoading && sharedWith.length < 1" class="mb-2">
        This project is not shared to any users
      </p>

      <o-field v-for="(user, index) in sharedWith" :key="user.id" class="mb-2">
        <o-input v-model="user.email" expanded disabled type="email" />
        <o-button icon-left="close-circle-outline" @click="sharedWith.splice(index, 1)" />
      </o-field>

      <o-field v-for="(_email, index) in invitations" :key="index" class="mb-2">
        <o-input v-model="invitations[index]" expanded type="email" placeholder="email to invite" />
        <o-button icon-left="close-circle-outline" @click="invitations.splice(index, 1)" />
      </o-field>

      <QuotaFeature
        quota="project_shared_with"
        :value="sharedWith.length + invitations.length"
        title-valid="Add another invitation"
        title-invalid="You cannot create an invitation to this project because you reached your maximum shared quota."
        wrapper-class="full-width"
        icon-position="top-right"
        @execute="createInvitation"
      >
        <o-button variant="primary" class="mt-2 full-width" icon-left="account-multiple-plus">
          Add invitation
        </o-button>
      </QuotaFeature>

      <o-loading :active="isAnythingLoading > 0" :full-page="false" />
    </section>
    <footer class="modal-card-foot">
      <o-button variant="danger" icon-left="cancel" :disabled="saveLoading" @click="closePopup">
        Cancel
      </o-button>
      <o-button
        class="ml-auto"
        icon-left="content-save"
        variant="primary"
        :disabled="saveLoading"
        @click="saveSharing"
      >
        Save
      </o-button>
    </footer>
  </div>
</template>
