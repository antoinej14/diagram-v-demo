<script setup>
import { onMounted, ref, watch } from 'vue'
import { OButton, OField, OInput, OLoading, OTable, OTableColumn } from '@oruga-ui/oruga-next'
import { useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import moment from 'moment'

import { useProjectStore } from '@/store/project'
import { useDiagramStore } from '@/store/diagram.js'

import { useOrganizationMembership } from '@/common/organization-membership.js'
import { compareTwoDiagrams } from '@/common/diagram/options/methods/compare.js'
import EventBus from '@/common/eventBus.js'

const emit = defineEmits(['close'])

const route = useRoute()
const { organizationID } = useOrganizationMembership(false)

const loading = ref(true)
const selectedRow = ref(null)
const openedDetails = ref([])
const currentPage = ref(1)

const projectStore = useProjectStore()
const diagramStore = useDiagramStore()

const { history } = storeToRefs(projectStore)

function compare(row) {
  projectStore
    .getProjectDiagram(organizationID, Number(route.params.id))
    .then((originalDiagram) => {
      const { highlight } = compareTwoDiagrams(
        JSON.parse(originalDiagram),
        JSON.parse(row.diagram),
        window.graph,
        window.paper
      )
      highlight()
      diagramStore.setComparing(true)
      closePopup()
    })
}

function selectRow(row) {
  selectedRow.value = row
}

function restore() {
  projectStore.editProject(organizationID, Number(route.params.id), selectedRow.value).then(() => {
    projectStore.setProjectDiagram(selectedRow.value.diagram)
    EventBus.dispatch('reloadDiagram')
    closePopup()
  })
}

function closePopup() {
  emit('close')
}

function load() {
  loading.value = true
  projectStore.getProjectHistory(organizationID, Number(route.params.id)).then(() => {
    loading.value = false
  })
}

watch(currentPage, (newPage) => {
  projectStore.setHistoryOffset(newPage)
  load()
})

onMounted(load)
</script>

<template>
  <div class="modal-card" style="width: auto">
    <header class="modal-card-head">
      <p class="modal-card-title">Project history log</p>
      <o-button icon-left="close" class="ml-auto pl-4" @click="closePopup" />
    </header>
    <section class="modal-card-body">
      <o-field>
        <o-input ref="input" type="search" rounded clearable placeholder="Search by date or user" />
      </o-field>
      <div class="history-list">
        <o-table
          v-show="history.data.length"
          v-model:current-page="currentPage"
          :selected="selectedRow"
          :data="history.data"
          :sticky-header="true"
          :opened-detailed="openedDetails"
          detail-key="date"
          :per-page="projectStore.history.limit"
          :total="projectStore.history.total"
          pagination-order="centered"
          detailed
          striped
          backend-pagination
          paginated
          @details-open="selectRow"
        >
          <template #detail="{ row }">
            <div class="is-flex is-justify-content-center">
              <img :src="row.thumbnail" alt="No thumbnail available" style="max-height: 200px" />
            </div>
            <o-button v-if="row.diagram" @click="compare(row)"> Compare</o-button>
          </template>

          <o-table-column v-slot="{ row }" field="date" label="Date">
            {{ moment(row.date).format('DD MMM, YYYY HH:mm:ss') }}
          </o-table-column>

          <o-table-column v-slot="{ row }" field="name" label="Name">
            {{ row.name }}
          </o-table-column>
        </o-table>
        <o-loading :active="loading" :full-page="false" />
      </div>
    </section>
    <footer class="modal-card-foot is-justify-content-center">
      <o-button
        v-if="selectedRow"
        variant="primary"
        icon-left="file-restore-outline"
        @click="restore"
      >
        Restore selected version
      </o-button>
      <p v-else>You can select an history entry to restore it.</p>
    </footer>
  </div>
</template>

<style scoped>
.history-list {
  min-height: 25vh;
  min-width: 30vw;
}
:deep(.b-table .table tr.is-selected .chevron-cell > .icon) {
  color: #fff !important;
}
</style>
