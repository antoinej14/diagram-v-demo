<script setup>
import { ref, computed } from 'vue'
import { OButton } from '@oruga-ui/oruga-next'

import providerAccountsApi from '@/api/modules/main-server/organizations/provider-accounts'

import { useMixins } from '@/common/mixins'
import { useOrganizationMembership } from '@/common/organization-membership'

import { useMappingStore } from '@/store/mapping'

const props = defineProps({
  provider: {
    type: String,
    required: true
  }
})

const { updateQuery } = useMixins()
const { organizationID, isAllowed } = useOrganizationMembership(false)

const accounts = ref(0)
const disabledAccounts = ref(0)

const mappingStore = useMappingStore()

const providerInfo = computed(() => mappingStore.providersData[props.provider])
const providerImage = computed(() => {
  if (props.provider === 'oci') {
    return '/diagram/diagram/oracle.svg'
  }

  return `/diagram/diagram/${props.provider}.svg`
})

function connect() {
  updateQuery({ provider: props.provider, connect: true }, true)
}

function manage() {
  updateQuery({ provider: props.provider }, true)
}

providerAccountsApi
  .getProviderAccounts(organizationID, { provider_name: props.provider })
  .then(({ data }) => {
    accounts.value = data.length
    disabledAccounts.value = data.filter(({ enabled }) => !enabled).length
  })
</script>

<template>
  <div
    class="is-flex is-border-radius-xl has-background-white p-3 round-box integration"
    :class="{ 'round-box--active': accounts > 0 }"
  >
    <figure class="image is-64x64 mr-3 is-align-content-center">
      <img :src="providerImage" :alt="providerInfo?.name || props.provider" />
    </figure>

    <div class="is-flex-grow-1">
      <span class="is-flex is-align-items-center integration__title">
        {{ providerInfo?.name || props.provider }}
      </span>

      <span class="is-flex my-3">
        <span
          class="integration__status mr-3"
          :class="{
            'has-background-grey-lighter': !accounts,
            'has-background-success': accounts > 0
          }"
        />

        <span class="has-text-success">
          {{ accounts }} account{{ accounts > 1 ? 's' : '' }} connected

          <span
            v-if="disabledAccounts"
            class="has-text-grey is-inline-flex is-align-items-center is-gap-1 ml-2"
          >
            (
            <o-icon icon="alert" size="small" />
            {{ disabledAccounts }} inactive )
          </span>
        </span>
      </span>

      <div v-if="isAllowed('edit-cloud-accounts')" class="is-flex is-gap-3">
        <o-button variant="primary" class="is-flex-1" icon-left="plus-thick" @click="connect">
          Connect now
        </o-button>

        <o-button
          v-if="accounts"
          variant="secondary"
          class="is-flex-1"
          icon-left="cog"
          @click="manage"
        >
          Manage
        </o-button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.integration {
  flex: 0 1 max(400px, calc(50% - 0.5rem));
}

.integration__title {
  height: 64px;
}

.integration__status {
  border-radius: 50%;
  height: 20px;
  width: 20px;
}
</style>
