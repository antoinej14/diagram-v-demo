<script setup>
import { ref, computed, watch } from 'vue'
import { useRoute } from 'vue-router'
import { OButton, OTabs, OTabItem, useOruga } from '@oruga-ui/oruga-next'

import providerAccountsApi from '@/api/modules/main-server/organizations/provider-accounts'

import { useMixins } from '@/common/mixins'
import { useOrganizationMembership } from '@/common/organization-membership'

import { useMappingStore } from '@/store/mapping'
import { useProviderAccountsStore } from '@/store/provider-accounts'

import ProviderAccountsTable from '@/components/providers/ProviderAccountsTable.vue'
import NewProviderAccount from '@/components/providers/NewProviderAccount.vue'
import ConfirmationModal from '@/components/modal/Confirmation.vue'

const route = useRoute()
const oruga = useOruga()

const { toast, updateQuery } = useMixins()
const { organizationID } = useOrganizationMembership(false)

const accounts = ref([])

const newProviderAccountRef = ref(null)

const mappingStore = useMappingStore()
const providerAccountsStore = useProviderAccountsStore()

const connecting = computed(() => route.query.connect === 'true')
const provider = computed(() => route.query.provider)
const providerInfo = computed(() => mappingStore.providersData[provider.value])

const activeTab = ref(connecting.value ? 'connect' : 'manage')

watch(connecting, (val) => {
  activeTab.value = val ? 'connect' : 'manage'

  if (!val) {
    load()
  } else {
    newProviderAccountRef.value.load()
  }
})

function connect() {
  updateQuery({ connect: true }, true)
}

function stopAdding() {
  updateQuery({ connect: undefined }, true)
}

watch(activeTab, (val) => {
  if (val === 'manage') {
    stopAdding()
  } else {
    connect()
  }
})

async function confirmDeleteAccount(accountID) {
  const instance = oruga.modal.open({
    component: ConfirmationModal,
    props: {
      title: 'Deleting provider account',
      message: 'Are you sure you want to remove this provider account from this organization?',
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Delete',
      yesIcon: 'delete',
      invertColors: true
    },
    trapFocus: true
  })
  const result = await instance.promise
  if (result === true) {
    providerAccountsStore.deleteProviderAccount(organizationID, accountID).then(
      () => {
        toast({
          variant: 'success',
          message: 'Provider account has been deleted.'
        })
        load()
      },
      () => {
        toast({
          variant: 'danger',
          message: 'Unable to delete provider account. Please contact support.'
        })
      }
    )
  }
}

function addedAccount() {
  load()
  activeTab.value = 'manage'
}

function update(payload) {
  accounts.value = accounts.value.map((account) => {
    if (account.id !== payload.id) {
      return account
    }
    return payload
  })
}

function load() {
  providerAccountsApi
    .getProviderAccounts(organizationID, { provider_name: provider.value })
    .then(({ data }) => {
      accounts.value = data
      if (!data.length) {
        activeTab.value = 'connect'
      }
    })
}

load()
</script>

<template>
  <section>
    <div class="is-flex is-gap-3 mb-5">
      <figure class="image is-64x64 mr-3 is-align-content-center">
        <img
          :src="`/diagram/${provider !== 'oci' ? provider : 'oracle'}.svg`"
          :alt="providerInfo?.name || provider.value"
        />
      </figure>

      <div class="is-flex-1 is-align-content-center">
        Integrations
        <span class="is-block has-text-weight-bold is-size-5">
          {{ providerInfo?.name || provider.value }}
        </span>
      </div>
      <div class="is-flex is-gap-3 is-align-items-center">
        <o-button
          variant="secondary"
          tag="a"
          :href="providerInfo?.docs"
          icon-left="open-in-new"
          size="small"
          target="_blank"
          >Docs</o-button
        >
      </div>
    </div>

    <o-tabs v-model="activeTab">
      <o-tab-item v-if="accounts.length" value="manage" icon="cog" label="Manage">
        <ProviderAccountsTable
          key="accounts"
          :accounts="accounts"
          @delete="confirmDeleteAccount"
          @connect="connect"
          @update="update"
        />
      </o-tab-item>

      <o-tab-item value="connect" icon="power-plug-outline" label="Connect">
        <NewProviderAccount
          key="connect"
          ref="newProviderAccountRef"
          :provider="provider"
          @success="addedAccount"
        />
      </o-tab-item>
    </o-tabs>
  </section>
</template>
