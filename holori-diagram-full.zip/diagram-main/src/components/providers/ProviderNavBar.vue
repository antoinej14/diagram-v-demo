<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { OIcon } from '@oruga-ui/oruga-next'

import { useOrganizationMembership } from '@/common/organization-membership'

import HomeLogo from '@/components/HomeLogo.vue'

const route = useRoute()

const { goTo } = useOrganizationMembership(false)

const views = {
  Visualize: 'pencil-ruler',
  Compare: 'compare',
  Diff: 'vector-difference',
  Export: 'export-variant'
}

const selectedView = computed(() => route.name?.replace('ProviderAccount', '').toLowerCase())

function chooseView(view) {
  const params = route.params
  const q = new URLSearchParams(window.location.search)
  const query = {}

  for (const [key, value] of q.entries()) {
    query[key] = value
  }

  goTo(`ProviderAccount${view}`, {
    params,
    query
  })
}
</script>

<template>
  <nav
    class="nav-bar px-3 is-flex is-align-items-center is-justify-content-space-between is-fixed is-top-0"
    role="navigation"
    aria-label="main navigation"
  >
    <HomeLogo />

    <div class="nav-bar-views p-1 is-border-radius-md is-flex is-gap-3 is-align-items-center">
      <a
        v-for="view in Object.keys(views)"
        :id="'navbar-' + view"
        :key="view"
        role="tab"
        class="is-flex is-align-items-center is-gap-3 is-border-radius-md py-2 px-3"
        :class="{ 'is-active': view.toLowerCase() === selectedView }"
        @click="chooseView(view)"
      >
        <o-icon :icon="views[view]" />
        {{ view }}
      </a>
    </div>

    <div />
  </nav>
</template>
