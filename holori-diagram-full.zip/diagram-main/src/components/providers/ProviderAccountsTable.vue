<script setup>
import { computed, ref, watch } from 'vue'
import { OButton, ODropdown, ODropdownItem, OTable, OTableColumn } from '@oruga-ui/oruga-next'

import { useMixins } from '@/common/mixins.js'
import { useOrganizationMembership } from '@/common/organization-membership.js'

import { useProviderAccountsStore } from '@/store/provider-accounts.js'

const emit = defineEmits(['delete', 'update', 'connect', 'reset'])

const props = defineProps({
  accounts: {
    type: Array,
    required: true
  },
  disableConnect: {
    type: Boolean,
    required: false,
    default: false
  }
})

const { organizationID, goTo } = useOrganizationMembership(false)
const { toast } = useMixins()

const providerAccountsStore = useProviderAccountsStore()

const verifying = ref(false)
const action = ref('')

const accounts = computed(() => props.accounts)

function gotoProvider(providerID, edit = null) {
  const query = {}

  if (edit) {
    query.edit = true
  }

  goTo('ProviderAccount', { params: { providerID }, query })
}

function getRoleID(account) {
  if (account.provider_name === 'aws') {
    const matches = account.authentication_data?.role?.match(/arn:aws:iam::([0-9]+):/)
    if (!matches) {
      return ''
    }
    return matches[1]
  }
  return ''
}

function verify(accountID) {
  verifying.value = true

  providerAccountsStore
    .verifyProviderAccount(organizationID, accountID)
    .then(
      () => {
        toast({
          variant: 'success',
          message: 'Account has been successfully verified.'
        })
      },
      (err) => {
        if (err.response?.data?.detail) {
          toast({
            variant: 'danger',
            message: err.response.data.detail
          })
        }
      }
    )
    .finally(() => {
      verifying.value = false
    })
}

function toggleAccount(account, enabled) {
  const payload = {
    ...account,
    enabled
  }

  providerAccountsStore.editProviderAccount(organizationID, account.id, payload).then(
    () => {
      const message = `Account "${account.name}" has been successfully ${enabled ? 'enabled' : 'disabled'}.`

      toast({
        variant: 'success',
        message
      })

      emit('update', payload)
    },
    () => {
      toast({
        variant: 'warning',
        message: 'Unable to toggle account.'
      })
    }
  )
}

function cellClick(row, col) {
  if (col.field === 'account') {
    gotoProvider(row.id)
  }
}

watch(action, () => {
  action.value = ''
})
</script>

<template>
  <o-table :data="accounts" @cell-click="cellClick">
    <o-table-column
      v-slot="{ row }"
      field="account"
      label="Account"
      :td-attrs="() => ({ class: 'ís-clickable clickable-table-row' })"
    >
      {{ row.name }}
      <span class="is-block has-text-grey">
        {{ getRoleID(row) }}
      </span>
    </o-table-column>
    <o-table-column v-slot="{ row }" label="Status" :td-attrs="() => ({ class: 'is-vcentered' })">
      {{ row.enabled ? 'Enabled' : 'Disabled' }}
    </o-table-column>
    <o-table-column width="50" v-slot="props">
      <o-dropdown v-model="action" position="bottom-right" teleport>
        <template #trigger>
          <o-button
            variant="secondary"
            class="px-3"
            size="small"
            :icon-left="verifying ? 'loading' : 'dots-horizontal'"
            rounded
          />
        </template>

        <o-dropdown-item @click="verify(props.row.id)"> Verify</o-dropdown-item>
        <o-dropdown-item @click="gotoProvider(props.row.id, true)">Edit</o-dropdown-item>
        <o-dropdown-item @click="toggleAccount(props.row, !props.row.enabled)">
          {{ props.row.enabled ? 'Disable' : 'Enable' }}
        </o-dropdown-item>
        <o-dropdown-item class="has-text-danger" @click="emit('delete', props.row.id)">
          Delete
        </o-dropdown-item>
      </o-dropdown>
    </o-table-column>
    <template #empty>
      <p class="p-5 has-text-centered">
        <template v-if="!props.disableConnect">
          No connected account.
          <a @click="emit('connect')">Connect one</a>.
        </template>
        <template v-else>
          No account found.
          <a @click="emit('reset')">Reset search</a>.
        </template>
      </p>
    </template>
  </o-table>
</template>
