<script setup>
import { ref } from 'vue'
import { storeToRefs } from 'pinia'
import { OSkeleton, OTooltip } from '@oruga-ui/oruga-next'

import { useOrganizationMembership } from '@/common/organization-membership.js'
import { useMixins } from '@/common/mixins.js'

import { useProviderAccountsStore } from '@/store/provider-accounts'

const { organizationID } = useOrganizationMembership(false)

const props = defineProps({
  providerAccount: {
    type: Object,
    required: false,
    default: null
  },
  useSync: {
    type: Boolean,
    required: false,
    default: false
  },
  preview: {
    type: Boolean,
    required: false,
    default: false
  },
  centered: {
    type: Boolean,
    required: false,
    default: false
  }
})

const { toast } = useMixins()

const syncDate = ref('')
const project = ref(null)

const providerAccountsStore = useProviderAccountsStore()

const { lastSynchronizationDate, synchronizationThumbnail } = storeToRefs(providerAccountsStore)

function visualize(e) {
  if (!syncDate.value) {
    e.preventDefault()

    toast({
      variant: 'info',
      message: 'Your infrastructure is still being processed. This may take up to a few hours.'
    })

    return false
  }
}

function formatDate(date) {
  if (!date) {
    return 'Not sync'
  }

  const newDate = new Date(date)
  return newDate.toLocaleString()
}

// Information is readily available (provider account page)
if (props.preview) {
  project.value = {
    id: null,
    thumbnail: null,
    name: 'Demo Account',
    provider: 'holori'
  }
} else {
  const { id, name, provider_name: provider } = props.providerAccount

  if (props.useSync) {
    syncDate.value = lastSynchronizationDate.value
    project.value = {
      id: null,
      thumbnail: synchronizationThumbnail.value,
      name,
      provider
    }
  } else {
    // It's not available, fetch the sync data (home)
    providerAccountsStore.getLastSynchronization(organizationID, id).then((sync) => {
      syncDate.value = sync ? sync.imported : ''

      if (sync) {
        providerAccountsStore
          .getSynchronizationThumbnail(organizationID, id, sync.id)
          .then((thumbnail) => {
            project.value = {
              id: null,
              thumbnail,
              name,
              provider
            }
          })
      } else {
        project.value = {
          id: null,
          thumbnail: null,
          name,
          provider
        }
      }
    })
  }
}
</script>

<template>
  <div :class="{ 'is-flex is-justify-content-center': props.centered }">
    <o-skeleton v-if="!project" class="is-width-auto" height="260px" width="260px" animated />
    <template v-else>
      <o-tooltip
        :label="
          syncDate
            ? 'Visualize your infrastructure'
            : 'Your infrastructure is still being processed'
        "
        position="bottom"
        teleport
      >
        <router-link
          :to="
            props.preview
              ? ''
              : {
                  name: 'ProviderAccountVisualize',
                  params: { providerID: props.providerAccount.id }
                }
          "
          v-slot="{ href }"
        >
          <a
            class="card is-flex is-flex-direction-column is-border-radius-xl"
            :class="{ 'is-clickable': !!syncDate }"
            :href="syncDate ? href : ''"
            @click="visualize"
          >
            <div
              class="card-header is-flex is-align-items-center is-justify-content-center px-4 py-2 has-text-weight-medium is-size-6"
            >
              <span class="ellipsis">{{ project.name }}</span>
            </div>
            <div class="card-content p-1 is-flex-grow-1 is-clipped is-relative">
              <div
                class="card-content-preview full-height is-flex is-flex-grow-1 is-justify-content-center is-align-items-center is-clipped"
              >
                <img
                  v-if="project.thumbnail"
                  class="thumbnail"
                  :src="project.thumbnail"
                  alt=""
                  width="200"
                />
                <template v-else>
                  <img
                    v-if="syncDate"
                    :src="`/diagram/${providerAccount.provider_name}.svg`"
                    alt="Holori icon"
                    width="100"
                  />
                  <o-icon v-else icon="loading" class="is-spin" size="large" />
                </template>
              </div>
            </div>
            <footer class="card-footer is-justify-content-center is-size-7 p-2">
              Sync: {{ formatDate(syncDate) }}
            </footer>
          </a>
        </router-link>
      </o-tooltip>
    </template>
  </div>
</template>

<style scoped>
.card {
  width: 260px;
  max-width: 260px;
  min-width: 260px;

  height: 260px;
  min-height: 260px;
  max-height: 260px;

  border: 1px solid var(--secondary-light-lightgray2);
}
.card.is-clickable:hover {
  box-shadow: 0 0 10px lightgray;
}
.card-header {
  border-bottom: 1px solid var(--secondary-light-lightgray2);
  box-shadow: none;
  flex: 0 0 40px;
}
</style>
