<script setup>
import { useRoute } from 'vue-router'
import { computed } from 'vue'
import { OButton, ODropdown, OIcon } from '@oruga-ui/oruga-next'

import { useOrganizationMembership } from '@/common/organization-membership.js'

import HomeLogo from '@/components/HomeLogo.vue'
import HelpMenu from '@/components/HelpMenu.vue'

const emit = defineEmits(['open-history', 'open-keyboard-shortcuts'])

const route = useRoute()
const { goTo } = useOrganizationMembership(false)

const views = {
  Compare: 'compare',
  Diff: 'vector-difference'
}

const selectedView = computed(() => route.name?.replace('Project', '').toLowerCase())

function chooseView(tab) {
  goTo(`Project${tab}`)
}
</script>

<template>
  <nav
    class="nav-bar px-3 is-flex is-align-items-center is-justify-content-space-between is-fixed is-top-0"
    role="navigation"
    aria-label="main navigation"
  >
    <HomeLogo />

    <div class="nav-bar-views p-1 is-border-radius-md is-flex is-gap-3 is-align-items-center">
      <a
        v-for="view in Object.keys(views)"
        :id="'navbar-' + view"
        :key="view"
        role="tab"
        class="is-flex is-align-items-center is-gap-3 is-border-radius-md py-2 px-3"
        :class="{ 'is-active': view.toLowerCase() === selectedView }"
        @click="chooseView(view)"
      >
        <o-icon :icon="views[view]" />
        {{ view }}
      </a>
    </div>

    <div class="is-flex is-gap-3 is-align-items-center">
      <o-button
        variant="primary"
        title="Project history"
        class="is-border-radius-full"
        icon-left="history"
        @click="emit('open-history')"
      />
      <o-dropdown aria-role="list" position="bottom-left" menu-class="help-menu-dropdown">
        <template #trigger>
          <button title="Help" class="button is-primary is-border-radius-full">
            <span class="icon is-small">
              <o-icon icon="help" />
            </span>
          </button>
        </template>

        <HelpMenu can-have-keyboard-shortcuts />
      </o-dropdown>
    </div>
  </nav>
</template>
