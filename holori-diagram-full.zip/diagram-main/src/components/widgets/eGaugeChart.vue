<template>
  <VChart :option="props.option" :loading="props.loading" :autoresize="autoresize" />
</template>

<script setup>
// see https://vue-echarts.dev/

import { use } from 'echarts/core'
import { GaugeChart } from 'echarts/charts'

import {
  AriaComponent,
  GridComponent,
  TitleComponent,
  TooltipComponent,
  LegendComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import VChart from 'vue-echarts'

use([
  AriaComponent,
  GridComponent,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GaugeChart,
  CanvasRenderer
])

const props = defineProps({
  option: {
    type: Object,
    required: true,
    default: () => {}
  },
  loading: {
    type: Boolean,
    required: false,
    default: () => false
  },
  autoresize: {
    type: Boolean,
    required: false,
    default: () => true
  }
})
</script>
