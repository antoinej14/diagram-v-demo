<script setup>
import { ref, watch } from 'vue'
import { OIcon } from '@oruga-ui/oruga-next'

import { useMixins } from '@/common/mixins'
import { groupIcon } from '@/common/diagram/options/shared'

import { useMappingStore } from '@/store/mapping'

const { toast } = useMixins()

const mappingStore = useMappingStore()

const props = defineProps({
  item: {
    type: Object,
    required: true
  },
  disabled: {
    type: Boolean,
    required: false,
    default: false
  }
})

const image = ref(props.item.image)
const name = ref('')

const inputRef = ref(null)

watch(
  () => props.item,
  () => {
    load()
  }
)

function load() {
  if (props.item.path) {
    const { productName } = mappingStore.splitPath(props.item.path)
    name.value = productName
  }

  if (props.item.image) {
    image.value = props.item.image
    return
  }

  image.value = props.item.type === 'Group' ? groupIcon : ''
}

function editImage() {
  if (!props.disabled) {
    inputRef.value.click()
  }
}

/**
 * @param {InputEvent} e
 */
function updateImage(e) {
  /** @type {File} */
  const file = e.target.files[0]
  if (file.size >= 5e5) {
    toast({
      message: 'Please select an image with size lower than 500KB.',
      variant: 'warning'
    })
    return
  }

  const reader = new FileReader()
  reader.onloadend = () => {
    const { graphInstance } = window

    if (!graphInstance) {
      console.error('unable to access the graphInstance')
      return
    }

    const { id, type } = props.item
    const img = reader.result

    graphInstance.updateItem(id, { image: img }, false)

    const imageShape = graphInstance.findById(id).getContainer().get('children')[
      type === 'group' ? 3 : 1
    ]

    if (imageShape) {
      imageShape.attr('img', img)
    }
    image.value = img
  }
  reader.readAsDataURL(file)
}

load()
</script>

<template>
  <div class="is-flex is-flex-direction-column is-align-items-center mb-3">
    <div
      class="item-image is-inline-flex is-align-items-center is-justify-content-center is-relative mx-auto my-3"
      :class="{ 'is-clickable': !disabled }"
      :title="!disabled && 'Click here to pick another image for this item'"
      @click="editImage"
    >
      <img v-if="image" :src="image" />
      <span class="edit is-flex is-align-items-center is-justify-content-center">
        <o-icon icon="image-edit" />
      </span>
      <input ref="inputRef" type="file" @input="updateImage" />
    </div>

    <strong v-if="name">
      {{ name }}
    </strong>
  </div>
</template>

<style scoped>
.item-image {
  border-radius: 10px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.25);
  overflow: hidden;
  height: 80px;
  width: 80px;
  transition: box-shadow 0.2s ease;
}
.item-image.is-clickable:hover {
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
}
.edit {
  position: absolute;
  color: #fff;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 0;
  transition: opacity 0.2s ease;
}
.item-image.is-clickable:hover .edit {
  opacity: 1;
}
.item-image img {
  width: 100%;
}
.item-image input {
  visibility: hidden;
  width: 0;
}
</style>
