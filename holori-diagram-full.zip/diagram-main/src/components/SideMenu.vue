<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { ODropdown, OIcon } from '@oruga-ui/oruga-next'

import { useOrganizationMembership } from '@/common/organization-membership'

import HelpMenu from '@/components/HelpMenu.vue'
import HomeLogo from '@/components/HomeLogo.vue'

const route = useRoute()
const { organizationID } = useOrganizationMembership(false)

const helpMenuActive = ref(false)

const isProject = computed(() => {
  return route.name && route.name !== 'Projects' && route.name.startsWith('Project')
})

const isProjects = computed(() => {
  return route.name === 'Projects'
})

const canHaveKeyboardShortcuts = computed(() => {
  return isProject.value || isProjects.value
})

const savedQuery = ref({})

const getTo = computed(() => (name, otherParams, keepViewAndSegment = false) => {
  const params = {
    organizationID,
    ...otherParams
  }

  const query = {}

  if (keepViewAndSegment) {
    const { view, segment } = savedQuery.value
    if (!view && segment) {
      query.segment = segment
    }
    if (!segment && view) {
      query.view = view
    }
  }

  return {
    name,
    params,
    query
  }
})

let previousSearchParams = ''
const queryObserver = new MutationObserver(() => {
  if (location.search !== previousSearchParams) {
    previousSearchParams = location.search
    const searchParams = new URLSearchParams(previousSearchParams)
    savedQuery.value = {
      view: searchParams.get('view'),
      segment: searchParams.get('segment')
    }
  }
})
const observerConfig = {
  subtree: true,
  childList: true
}

onMounted(() => {
  queryObserver.observe(document, observerConfig)
})

onBeforeUnmount(() => {
  queryObserver.disconnect()
})
</script>

<template>
  <aside class="sidebar is-flex is-flex-direction-column px-3">
    <HomeLogo class="mt-5" />

    <div class="sidebar-inside holori-scrollbar mt-5">
      <ul class="menu-list">
        <li class="py-1">
          <a
            class="is-flex is-align-items-center"
            href="/"
          >
            <!-- this navigate to the main frontend -->
            <o-icon icon="home" class="mr-3" />
            Home
          </a>
        </li>

        <li class="py-1">
          <router-link
            class="is-flex is-align-items-center"
            :class="{ 'is-active': route.name === 'ProjectsOverview' }"
            :to="getTo('ProjectsOverview')"
          >
            <o-icon icon="graph-outline" class="mr-3" />
            Project Planning
          </router-link>
        </li>

        <li class="py-1">
          <router-link
            class="is-flex is-align-items-center"
            :class="{
              'is-active': route.name === 'InventoryDiagramView'
            }"
            :to="getTo('InventoryDiagramView')"
          >
            <o-icon icon="cube" class="mr-3" />
            Infrastructure view
          </router-link>
        </li>
      </ul>
    </div>

    <hr class="separator" />

    <ul class="menu-list mt-3">
      <li class="py-1">
        <o-dropdown
          v-model:active="helpMenuActive"
          aria-role="list"
          position="top-left"
          class="full-width help-menu"
          menu-class="help-menu-dropdown help-menu-dropdown-sidemenu"
          trigger-class="full-width"
        >
          <template #trigger="{ active }">
            <a class="is-flex is-align-items-center full-width" :class="{ 'is-active': active }">
              <o-icon icon="book-open-variant" class="mr-3" />

              Help &amp; Support

              <o-icon icon="chevron-right" class="ml-auto" />
            </a>
          </template>

          <HelpMenu
            v-model:active="helpMenuActive"
            :can-have-keyboard-shortcuts="canHaveKeyboardShortcuts"
          />
        </o-dropdown>
      </li>
    </ul>

    <hr class="separator" />

    <!-- TODO link to account, navigate to main frontend -->
  </aside>
</template>

<style scoped>
.menu-list .is-active {
  background-color: var(--primary);
  position: relative;
}
.menu-list a:not(.is-active):hover {
  background-color: #8877e8;
}
.menu-label a {
  display: none;
}
.menu-label:hover a {
  display: block;
}

.more {
  opacity: 0;
  transition:
    opacity 0.2s ease,
    transform 0.2s ease;
  transform-origin: top center;
  transform: scaleY(0);
  height: 0;
  padding-left: 2.2rem;
}
.more--open {
  height: auto;
  opacity: 1;
  transform: none;
}

.separator {
  background-color: var(--secondary-dark-darkgray);
  margin: 1rem 0 0.5rem;
}

.menu-toggle {
  border-radius: 50%;
  transition: background-color 0.2s ease;
  height: 21px;
  width: 21px;
}
.menu-toggle:hover {
  background: var(--primary);
}

.help-menu-dropdown-sidemenu {
  right: auto !important;
  top: auto !important;
  bottom: calc(2.25rem + 60px) !important;
  left: calc(var(--sidebar-width) + 1px) !important;
  position: fixed;
  z-index: 31;
}
</style>
