import { dia, g } from '@joint/plus'
import Color from 'color'
import { GRID_SIZE, sizeToZ, DEFAULT_NODE_BACKGROUND, DEFAULT_NODE_BORDER } from './constants'
import { borderStyleToDasharray } from '@/common/diagram/options/shapes/group.js'
import { wrapLabel } from '@/common/diagram/options/shapes/shared.js'

const Cylinder = dia.Element.define(
  'Cylinder',
  {
    attrs: {
      base: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        cx: 20,
        cy: 20,
        rx: 20,
        ry: 20,
        strokeWidth: 1,
        strokeLineJoin: 'round',
        stroke: DEFAULT_NODE_BORDER
      },
      side: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      top: {
        cx: 20,
        cy: 20,
        rx: 20,
        ry: 20,
        fill: DEFAULT_NODE_BACKGROUND,
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      image: {
        width: 30,
        height: 30,
        style: 'clip-path: inset(0 0 0 0 round 50%)'
      },
      text: {
        fill: '#000000',
        x: 25,
        textAnchor: 'middle',
        fontSize: 12,
        fontFamily: 'sans-serif'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'ellipse',
        selector: 'base'
      },
      {
        tagName: 'path',
        selector: 'side'
      },
      {
        tagName: 'ellipse',
        selector: 'top'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'text',
        selector: 'text'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createCylinder = ({
  id,
  name,
  image,
  position,
  size,
  variant,
  backgroundColor,
  borderColor,
  borderStyle
}) => {
  const d = {
    x: GRID_SIZE,
    y: GRID_SIZE,
    z: Math.round(GRID_SIZE * sizeToZ[variant || 'normal'])
  }

  const fill = backgroundColor || DEFAULT_NODE_BACKGROUND
  const stroke = borderColor || DEFAULT_NODE_BORDER
  const strokeDasharray = borderStyleToDasharray(borderStyle)

  const baseRect = new g.Rect(0, 0, GRID_SIZE, GRID_SIZE)

  const baseDiagonal = new g.Line(baseRect.bottomLeft(), baseRect.topRight())
  const base = g.Ellipse.fromRect(baseRect)
  const [bottomLeftIntersection, bottomRightIntersection] = baseDiagonal.intersect(base)

  const top = new g.Rect(-d.z, -d.z, d.x, d.y)

  const topLeftIntersection = bottomLeftIntersection.clone().translate(-d.z, -d.z)
  const topRightIntersection = topLeftIntersection.reflection(top.center())

  return {
    id,
    type: 'Cylinder',
    position,
    size,
    attrs: {
      top: {
        points: `0,0 ${d.x},0 ${d.x},${d.y} 0,${d.y}`,
        fill,
        stroke,
        strokeDasharray,
        transform: `translate(${-d.z},${-d.z})`
      },
      side: {
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        strokeDasharray,
        d: `
        M ${bottomLeftIntersection.x} ${bottomLeftIntersection.y}
        L ${topLeftIntersection.x} ${topLeftIntersection.y}
        L ${topRightIntersection.x} ${topRightIntersection.y}
        L ${bottomRightIntersection.x} ${bottomRightIntersection.y}
    `
      },
      base: {
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        strokeDasharray
      },
      image: {
        href: image,
        transform: `translate(${-d.z + 5},${-d.z + 5})`
      },
      text: {
        text: wrapLabel(name, false, true),
        transform: `translate(0,${d.y + 5})`
      }
    }
  }
}

export { Cylinder, createCylinder }
