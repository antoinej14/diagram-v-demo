import { dia, shapes, V, format } from '@joint/plus'
import { GRID_SIZE, SCALE, ISOMETRIC_SCALE, ROTATION_DEGREES } from './constants'
import { Cube, createCube } from './cube'
import { Group, createGroup } from './group'
import { TextBox, createTextBox } from './text-box'
import { sortElements } from './sort'
import { getMax } from './coords'
import { Cylinder, createCylinder } from './cylinder'
import { Octogon, createOctogon } from './octogon'
import { Network, createNetwork } from './network'
import { Pyramid, createPyramid } from './pyramid'
import { anonymous_instance } from '@/api/index'

const generate3DDiagram = (diagram, callback, progressRef) => {
  window.notes3d = {}

  const cleanDiagram = {
    // nodes: diagram.nodes.map(cleanNode),
    nodes: diagram.nodes,
    edges: diagram.edges.map(({ source, target }) => ({
      source,
      target
    })),
    groups: diagram.groups
  }

  const nodesWithPathAndNoCategory = cleanDiagram.nodes.filter(
    ({ path, category }) => !!path && !category
  )
  const paths = new Set()
  nodesWithPathAndNoCategory.forEach(({ path }) => {
    paths.add(path)
  })
  const promises = Array.from(paths).map((path) =>
    // TODO why not use DiagramApi.get() ?
    anonymous_instance.get(`/diagram${path}.json`, { headers: { path } })
  )

  const categories = {}

  if (promises.length) {
    progressRef.value = 'Gathering shapes information…'
  }

  // Wait until all the promises have completed...
  Promise.allSettled(promises)
    .then((responses) => {
      progressRef.value = 'Setting shapes…'
      responses.forEach((res) => {
        if (res.value) {
          const { path } = res.value.config.headers
          const { category } = res.value.data

          // Affect the path and the category
          categories[path] = category
        }
      })

      // Go through all the nodes...
      for (const i in cleanDiagram.nodes) {
        const node = cleanDiagram.nodes[i]

        for (const path in categories) {
          if (node.path === path) {
            cleanDiagram.nodes[i] = {
              ...cleanDiagram.nodes[i],
              category: categories[path]
            }
          }
        }
      }

      progressRef.value = 'Checking empty groups…'
      cleanDiagram.groups = cleanDiagram.groups.map((group) => {
        const { id } = group
        const children = [...diagram.nodes, ...diagram.groups].filter(
          (item) => item.parentId === id || item.groupId === id || item.parent === id
        )
        const empty = children.length === 0

        return {
          ...group,
          empty
        }
      })

      const maxNodes = getMax(cleanDiagram.nodes)
      const maxGroups = getMax(cleanDiagram.groups)

      const max = {
        x: Math.max(maxNodes.x, maxGroups.x),
        y: Math.max(maxNodes.y, maxGroups.y)
      }

      const GRID_COUNT = Math.max(max.x, max.y) / GRID_SIZE + 1

      const transformationMatrix = () => {
        return V.createSVGMatrix()
          .translate(GRID_COUNT * GRID_SIZE * SCALE * ISOMETRIC_SCALE + GRID_SIZE, 0)
          .rotate(ROTATION_DEGREES)
          .skewX(-ROTATION_DEGREES)
          .scaleNonUniform(SCALE, SCALE * ISOMETRIC_SCALE)
      }

      // Paper

      const cellNamespace = {
        Link: shapes.standard.Link,
        TextBox,
        Cube,
        Group,
        Cylinder,
        Octogon,
        Network,
        Pyramid
      }

      progressRef.value = 'Preparing render…'
      const graph = new dia.Graph({}, { cellNamespace })

      const cellBBoxes = {}

      const el = document.createElement('canvas')
      el.setAttribute('class', 'is-absolute')

      progressRef.value = 'Creating paper…'
      const paper = new dia.Paper({
        el,
        model: graph,
        width: 800,
        height: 600,
        gridSize: GRID_SIZE,
        async: true,
        sorting: dia.Paper.sorting.APPROX,
        cellViewNamespace: cellNamespace
      })

      const generateImage = () => {
        progressRef.value = 'Generating SVG image…'

        let svgContent = {
          width: 0,
          height: 0,
          content: ''
        }

        setTimeout(() => {
          const opts = {
            padding: 10,
            beforeSerialize(doc) {
              progressRef.value = 'Calculating image size…'
              const { a, b, c, d, e, f } = transformationMatrix()
              const appended = document.body.appendChild(doc)
              appended.removeAttribute('viewBox')
              appended.style = 'position: absolute; top: 0; left: 0; width: 100%; height: 100%;'
              appended
                .querySelector('.joint-layers')
                .setAttribute('transform', `matrix(${a}, ${b}, ${c}, ${d}, ${e}, ${f})`)

              const { x, y, width, height } = appended
                .querySelector('.joint-layers')
                .getBoundingClientRect()

              appended.setAttribute('width', width)
              appended.setAttribute('height', height)
              appended.setAttribute('viewBox', `${x} ${y} ${width} ${height}`)

              svgContent.width = width
              svgContent.height = height

              document.body.removeChild(appended)
            },
            convertImagesToDataUris: true,
            useComputedStyles: false
          }

          format.toSVG(
            paper,
            (dataURL) => {
              svgContent.content = dataURL
              callback(dataURL)
            },
            opts
          )
        }, 1000)
      }

      if (![...cleanDiagram.nodes, ...cleanDiagram.groups].length) {
        generateImage()
      }

      const allShapes = {}

      progressRef.value = 'Drawing groups…'
      cleanDiagram.groups.forEach((group) => {
        allShapes[group.id] = createGroup(group)
      })

      progressRef.value = 'Drawing nodes…'
      cleanDiagram.nodes.forEach((node) => {
        const { type, category } = node

        let createShape = createCube
        let variant = 'normal'

        if (type === 'TextBox') {
          createShape = createTextBox
        } else {
          switch (category) {
            case 'storage':
              createShape = createCylinder
              variant = 'large'
              break
            case 'database':
              createShape = createOctogon
              break
            case 'network':
              createShape = createNetwork
              variant = 'extraLarge'
              break
            case 'serverless':
              createShape = createPyramid
              break
            // No category defined, default to normal sized cube.
            default:
              break
          }
        }

        allShapes[node.id] = createShape({
          ...node,
          variant
        })
      })

      graph.addCells(Object.values(allShapes))

      progressRef.value = 'Combining elements…'
      const allItems = [...cleanDiagram.nodes, ...cleanDiagram.groups]
      allItems.forEach((item) => {
        const { id, parent } = item
        if (parent) {
          graph.getCell(parent).embed(graph.getCell(id))
        }
      })

      progressRef.value = 'Linking objects…'
      cleanDiagram.edges.forEach((edge) => {
        const link = new shapes.standard.Link()
        link.source(graph.getCell(edge.source))
        link.target(graph.getCell(edge.target))
        link.router('metro')
        link.connector('jumpover', { size: 10 })
        link.addTo(graph)
      })

      graph.getCells().forEach((cell) => {
        cellBBoxes[cell.id] = V('rect')
      })

      paper.unfreeze()
      paper.render()

      progressRef.value = 'Sorting elements…'
      sortElements(graph, cellBBoxes)

      generateImage()
    })
    .catch(() => {})
}

export { generate3DDiagram }
