import { GRID_SIZE } from './constants'

export const calculateGridPosition = ({ x, y }) => {
  const { abs } = Math
  const absX = abs(Math.round(x))
  const absY = abs(Math.round(y))
  let finalX, finalY
  const modX = absX % GRID_SIZE
  const modY = absY % GRID_SIZE

  if (modX < GRID_SIZE / 2) {
    finalX = absX - modX
  } else {
    finalX = absX + (GRID_SIZE - modX)
  }

  if (modY < GRID_SIZE / 2) {
    finalY = absY - modY
  } else {
    finalY = absY + (GRID_SIZE - modY)
  }

  if (x < 0) {
    finalX *= -1
  }
  if (y < 0) {
    finalY *= -1
  }

  return {
    x: finalX,
    y: finalY
  }
}

export const getMin = (nodes) => {
  const min = {
    x: 0,
    y: 0
  }

  for (const node of nodes) {
    if (node.x < min.x) {
      min.x = node.x
    }
    if (node.y < min.y) {
      min.y = node.y
    }
  }

  return min
}

export const getMax = (nodes) => {
  const max = {
    x: 0,
    y: 0
  }

  for (const node of nodes) {
    const width = node.width || 0
    const height = node.height || 0

    if (node.x + width > max.x) {
      max.x = node.x + width
    }
    if (node.y + height > max.y) {
      max.y = node.y + height
    }
  }

  return max
}
