import { dia, V } from '@joint/plus'
import Color from 'color'
import { GRID_SIZE, DEFAULT_NODE_BACKGROUND, DEFAULT_NODE_BORDER } from './constants'
import { borderStyleToDasharray } from '@/common/diagram/options/shapes/group.js'
import { wrapLabel } from '@/common/diagram/options/shapes/shared.js'

const Pyramid = dia.Element.define(
  'Pyramid',
  {
    attrs: {
      image: {
        width: 25,
        height: 25
      },
      top: {
        fill: DEFAULT_NODE_BORDER,
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BACKGROUND
      },
      front: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.15).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      side: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      text: {
        fill: '#000000',
        x: 25,
        textAnchor: 'middle',
        fontSize: 12,
        fontFamily: 'sans-serif'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'polygon',
        selector: 'top'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'polygon',
        selector: 'front'
      },
      {
        tagName: 'polygon',
        selector: 'side'
      },
      {
        tagName: 'text',
        selector: 'text'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createPyramid = ({
  id,
  name,
  image,
  position,
  size,
  backgroundColor,
  borderColor,
  borderStyle
}) => {
  const d = {
    x: GRID_SIZE,
    y: GRID_SIZE,
    z: GRID_SIZE
  }

  const fill = backgroundColor || DEFAULT_NODE_BACKGROUND
  const stroke = borderColor || DEFAULT_NODE_BORDER
  const strokeDasharray = borderStyleToDasharray(borderStyle)

  return {
    id,
    type: 'Pyramid',
    position,
    size,
    attrs: {
      top: {
        points: `15,15 ${d.x},15 ${d.x},${d.y} 15,${d.y}`,
        transform: `translate(${-d.z},${-d.z})`,
        fill,
        stroke,
        strokeDasharray
      },
      image: {
        href: image,
        transform: `translate(${-d.z + 15.5},${-d.z + 15.5})`
      },
      front: {
        points: `0,15 ${d.z},0 ${d.z},${d.y} 0,${d.y}`,
        fill: Color(fill).darken(0.15).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z + d.x, -d.z).skewY(45)
        )
      },
      side: {
        points: `15,0 ${d.x},0 ${d.x},${d.z} 0,${d.z}`,
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z, -d.z + d.y).skewX(45)
        )
      },
      text: {
        text: wrapLabel(name, false, true),
        transform: `translate(0,${d.y + 5})`
      }
    }
  }
}

export { Pyramid, createPyramid }
