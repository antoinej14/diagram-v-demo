import { dia, V } from '@joint/plus'
import Color from 'color'
import { GRID_SIZE, sizeToZ, DEFAULT_NODE_BACKGROUND, DEFAULT_NODE_BORDER } from './constants'
import { borderStyleToDasharray } from '@/common/diagram/options/shapes/group.js'
import { wrapLabel } from '@/common/diagram/options/shapes/shared.js'

const Octogon = dia.Element.define(
  'Octogon',
  {
    attrs: {
      image: {
        width: 30,
        height: 30,
        style:
          'clip-path: polygon(16.66% 0%, 83.33% 0%, 100% 16.66%, 100% 83.33%, 83.33% 100%, 16.66% 100%, 0% 83.33%, 0% 16.66%)'
      },
      top: {
        fill: DEFAULT_NODE_BACKGROUND,
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      front: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.15).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      side: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      middle: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.125),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      text: {
        fill: '#000000',
        x: 25,
        textAnchor: 'middle',
        fontSize: 12,
        fontFamily: 'sans-serif'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'polygon',
        selector: 'top'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'polygon',
        selector: 'middle'
      },
      {
        tagName: 'polygon',
        selector: 'front'
      },
      {
        tagName: 'polygon',
        selector: 'side'
      },
      {
        tagName: 'text',
        selector: 'text'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createOctogon = ({
  id,
  name,
  image,
  position,
  size,
  variant,
  backgroundColor,
  borderColor,
  borderStyle
}) => {
  const d = {
    x: GRID_SIZE,
    y: GRID_SIZE,
    z: Math.round(GRID_SIZE * sizeToZ[variant || 'normal'])
  }

  const fill = backgroundColor || DEFAULT_NODE_BACKGROUND
  const stroke = borderColor || DEFAULT_NODE_BORDER
  const strokeDasharray = borderStyleToDasharray(borderStyle)

  return {
    id,
    type: 'Octogon',
    position,
    size,
    attrs: {
      top: {
        // 10,0 30,0 40,10 40,30 30,40 10,40 0,30 0,10
        points: `10,0 30,0 ${d.x},10 ${d.x},30 30,${d.y} 10,${d.y} 0,30 0,10`,
        stroke,
        strokeDasharray,
        fill,
        transform: `translate(${-d.z},${-d.z})`
      },
      image: {
        href: image,
        transform: `translate(${-d.z + 5},${-d.z + 5})`
      },
      side: {
        // 10,0 30,0 30,20 10,20
        points: `10,0 30,0 30,${d.z} 10,${d.z}`,
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z, -d.z + d.y).skewX(45)
        )
      },
      front: {
        // 0,10 20,10 20,30 0,30
        points: `0,10 ${d.z},10 ${d.z},30 0,30`,
        fill: Color(fill).darken(0.15).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z + d.x, -d.z).skewY(45)
        )
      },
      middle: {
        points: `${d.y - d.z - 10},${d.y - d.z} 30,40 40,30 ${d.y - d.z},${d.y - d.z - 10}`,
        fill: Color(fill).darken(0.125),
        stroke,
        strokeDasharray
      },
      text: {
        text: wrapLabel(name, false, true),
        transform: `translate(0,${d.y + 5})`
      }
    }
  }
}

export { Octogon, createOctogon }
