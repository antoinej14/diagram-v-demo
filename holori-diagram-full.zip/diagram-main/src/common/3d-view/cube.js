import { dia, V } from '@joint/plus'
import Color from 'color'
import { GRID_SIZE, sizeToZ, DEFAULT_NODE_BACKGROUND, DEFAULT_NODE_BORDER } from './constants'
import { borderStyleToDasharray } from '@/common/diagram/options/shapes/group.js'
import { wrapLabel } from '@/common/diagram/options/shapes/shared.js'

const Cube = dia.Element.define(
  'Cube',
  {
    attrs: {
      image: {
        width: 30,
        height: 30
      },
      top: {
        fill: DEFAULT_NODE_BORDER,
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      front: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.15).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      side: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      text: {
        fill: '#000000',
        x: 25,
        textAnchor: 'middle',
        fontSize: 12,
        fontFamily: 'sans-serif'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'polygon',
        selector: 'top'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'polygon',
        selector: 'front'
      },
      {
        tagName: 'polygon',
        selector: 'side'
      },
      {
        tagName: 'text',
        selector: 'text'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createCube = ({
  id,
  name,
  image,
  position,
  variant,
  size,
  backgroundColor,
  borderColor,
  borderStyle
}) => {
  const d = {
    x: GRID_SIZE,
    y: GRID_SIZE,
    z: Math.round(GRID_SIZE * sizeToZ[variant || 'normal'])
  }

  const fill = backgroundColor || DEFAULT_NODE_BACKGROUND
  const stroke = borderColor || DEFAULT_NODE_BORDER
  const strokeDasharray = borderStyleToDasharray(borderStyle)

  return {
    id,
    type: 'Cube',
    position,
    size,
    attrs: {
      top: {
        points: `0,0 ${d.x},0 ${d.x},${d.y} 0,${d.y}`,
        fill,
        stroke,
        strokeDasharray,
        transform: `translate(${-d.z},${-d.z})`
      },
      image: {
        href: image,
        transform: `translate(${-d.z + 5},${-d.z + 5})`
      },
      front: {
        points: `0,0 ${d.z},0 ${d.z},${d.y} 0,${d.y}`,
        fill: Color(fill).darken(0.15).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z + d.x, -d.z).skewY(45)
        )
      },
      side: {
        points: `0,0 ${d.x},0 ${d.x},${d.z} 0,${d.z}`,
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        strokeDasharray,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z, -d.z + d.y).skewX(45)
        )
      },
      text: {
        text: wrapLabel(name, false, true),
        transform: `translate(0,${d.y + 5})`
      }
    }
  }
}

export { Cube, createCube }
