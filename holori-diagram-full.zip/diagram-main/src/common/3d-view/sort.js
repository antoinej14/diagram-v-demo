const topologicalSort = (nodes) => {
  let depth = 0

  const visitNode = (node) => {
    if (!node.visited) {
      node.visited = true

      for (let i = 0; i < node.behind.length; ++i) {
        if (node.behind[i] == null) {
          break
        } else {
          visitNode(node.behind[i])
          delete node.behind[i]
        }
      }

      node.depth = depth++
      node.el.set('z', node.depth)
    }
  }

  for (let i = 0; i < nodes.length; ++i) {
    visitNode(nodes[i])
  }

  return depth
}

const sortElements = (graph, cellBBoxes) => {
  const elements = graph.getElements()
  const nodes = elements.map((el) => {
    return {
      el,
      behind: [],
      visited: false
    }
  })

  for (let i = 0; i < nodes.length; ++i) {
    const a = nodes[i].el
    const aBBox = a.getBBox()
    cellBBoxes[a.id].setAttribute('width', aBBox.width)
    cellBBoxes[a.id].setAttribute('height', aBBox.height)
    cellBBoxes[a.id].setAttribute('x', aBBox.x)
    cellBBoxes[a.id].setAttribute('y', aBBox.y)

    const aMax = aBBox.bottomRight()

    for (let j = 0; j < nodes.length; ++j) {
      if (i !== j) {
        const b = nodes[j].el
        const bBBox = b.getBBox()
        const bMin = bBBox.topLeft()

        if (bMin.x < aMax.x && bMin.y < aMax.y) {
          nodes[i].behind.push(nodes[j])
        }
      }
    }
  }

  topologicalSort(nodes)

  const groups = nodes.filter((node) => node.el.attributes.type === 'Group')

  const increaseZ = (item) => {
    const min = item.get('z')
    item.getEmbeddedCells().forEach((cell) => {
      cell.set('z', cell.get('z') + min)
    })
  }

  groups.forEach((group) => {
    increaseZ(group.el)
  })

  graph.getLinks().forEach((edge) => {
    edge.set('z', 999)
  })

  return nodes
}

export { sortElements }
