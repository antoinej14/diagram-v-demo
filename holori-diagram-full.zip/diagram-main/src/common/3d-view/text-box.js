import { dia, V } from '@joint/plus'
import Color from 'color'
import { GRID_SIZE, sizeToZ, DEFAULT_NODE_BACKGROUND, DEFAULT_NODE_BORDER } from './constants'

const TextBox = dia.Element.define(
  'TextBox',
  {
    attrs: {
      top: {
        fill: DEFAULT_NODE_BORDER,
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      front: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.15).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      side: {
        fill: Color(DEFAULT_NODE_BACKGROUND).darken(0.1).hex(),
        strokeWidth: 1,
        stroke: DEFAULT_NODE_BORDER
      },
      text: {
        fill: '#000000',
        fontSize: 12,
        fontFamily: 'sans-serif'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'polygon',
        selector: 'top'
      },
      {
        tagName: 'polygon',
        selector: 'front'
      },
      {
        tagName: 'polygon',
        selector: 'side'
      },
      {
        tagName: 'text',
        selector: 'text'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createTextBox = ({ id, position, size, notes }) => {
  const d = {
    x: size.width,
    y: size.height,
    z: Math.round(GRID_SIZE * sizeToZ.small)
  }

  const fill = '#ffffff'
  const stroke = '#000000'

  return {
    id,
    type: 'TextBox',
    position,
    size,
    attrs: {
      top: {
        points: `0,0 ${d.x},0 ${d.x},${d.y} 0,${d.y}`,
        fill,
        stroke,
        transform: `translate(${-d.z},${-d.z})`
      },
      front: {
        points: `0,0 ${d.z},0 ${d.z},${d.y} 0,${d.y}`,
        fill: Color(fill).darken(0.15).hex(),
        stroke,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z + d.x, -d.z).skewY(45)
        )
      },
      side: {
        points: `0,0 ${d.x},0 ${d.x},${d.z} 0,${d.z}`,
        fill: Color(fill).darken(0.1).hex(),
        stroke,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z, -d.z + d.y).skewX(45)
        )
      },
      text: {
        text: notes
      }
    }
  }
}

export { TextBox, createTextBox }
