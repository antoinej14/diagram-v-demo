import { dia, V } from '@joint/plus'
import Color from 'color'
import { borderStyleToDasharray } from '@/common/diagram/options/shapes/group.js'
import { groupIcon, pinIcon } from '@/common/diagram/options/shared.js'
import { wrapLabel } from '@/common/diagram/options/shapes/shared.js'

const fill = '#ffffff'
const stroke = '#000000'

const Group = dia.Element.define(
  'Group',
  {
    attrs: {
      surface: {
        fill,
        strokeWidth: 1,
        stroke
      },
      image: {
        height: 16,
        width: 16
      },
      text: {
        fill: '#000000',
        fontSize: 12,
        fontFamily: 'sans-serif'
      },
      front: {
        fill: Color(fill).darken(0.15).hex(),
        stroke
      },
      side: {
        fill: Color(fill).darken(0.1).hex(),
        stroke
      }
    }
  },
  {
    markup: [
      {
        tagName: 'polygon',
        selector: 'surface'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'text',
        selector: 'text'
      },
      {
        tagName: 'polygon',
        selector: 'front'
      },
      {
        tagName: 'polygon',
        selector: 'side'
      }
    ]
  }
)

// converting dimension parameters into path properties of markup parts
// so the element can be created in a more flexible way
const createGroup = ({
  id,
  position,
  location,
  size,
  image,
  name,
  backgroundColor,
  borderColor,
  borderStyle,
  empty
}) => {
  const d = {
    x: size.width,
    y: size.height,
    z: 5
  }

  const opacity = empty ? 0.25 : 1
  const fallbackIcon = location ? pinIcon : groupIcon

  return {
    id,
    position,
    size,
    type: 'Group',
    attrs: {
      surface: {
        fill: backgroundColor,
        stroke: borderColor,
        strokeDasharray: borderStyleToDasharray(borderStyle),
        points: `0,0 ${d.x},0 ${d.x},${d.y} 0,${d.y}`,
        transform: `translate(${-d.z},${-d.z})`,
        opacity
      },
      image: {
        href: image || fallbackIcon,
        clipPath: 'inset(0% round 5px)',
        transform: `translate(0,${d.y + 3})`
      },
      text: {
        text: wrapLabel(name, true, true),
        transform: `translate(20,${d.y + 5})`,
        opacity
      },
      side: {
        fill: Color(backgroundColor || fill)
          .darken(0.15)
          .hex(),
        stroke: Color(borderColor || stroke)
          .darken(0.15)
          .hex(),
        strokeDasharray: borderStyleToDasharray(borderStyle),
        points: `0,0 ${d.x},0 ${d.x},${d.z} 0,${d.z}`,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z, -d.z + d.y).skewX(45)
        ),
        opacity
      },
      front: {
        fill: Color(backgroundColor || fill)
          .darken(0.1)
          .hex(),
        stroke: Color(borderColor || stroke)
          .darken(0.1)
          .hex(),
        strokeDasharray: borderStyleToDasharray(borderStyle),
        points: `0,0 ${d.z},0 ${d.z},${d.y} 0,${d.y}`,
        transform: V.matrixToTransformString(
          new DOMMatrixReadOnly().translate(-d.z + d.x, -d.z).skewY(45)
        ),
        opacity
      }
    }
  }
}

export { Group, createGroup }
