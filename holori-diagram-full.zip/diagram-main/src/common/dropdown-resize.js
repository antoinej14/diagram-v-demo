import { nextTick, onBeforeUnmount, onMounted, watch } from 'vue'

export function useDropdownResize(activeRef, dropdownRef, resizeHeight = false) {
  function updateDropdown(dropdown) {
    const width = dropdown.$el.getBoundingClientRect().width
    const menu = document.querySelector('.dropdown-menu-animation.is-z-99.is-active.is-expanded')
    menu.style.width = width + 'px'

    if (resizeHeight) {
      nextTick(() => {
        const content = menu.querySelector('.dropdown-content')
        const maxHeight = window.innerHeight - content.getBoundingClientRect().y - 10
        content.style.maxHeight = maxHeight + 'px'
        content.style.overflowY = 'auto'
      }).then()
    }
  }

  function updateDropdownWidth() {
    nextTick(() => {
      if (activeRef.value) {
        updateDropdown(dropdownRef.value)
      }
    }).then(() => {})
  }

  watch(activeRef, (newVal) => {
    if (newVal) {
      updateDropdownWidth()
    }
  })

  onMounted(() => {
    addEventListener('resize', updateDropdownWidth)
  })

  onBeforeUnmount(() => {
    removeEventListener('resize', updateDropdownWidth)
  })
}
