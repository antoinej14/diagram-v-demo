import { computed, nextTick, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useOruga } from '@oruga-ui/oruga-next'

import EventBus from '@/common/eventBus'
import { makeTitle } from '@/common/meta'

/**
 * TODO
 */
const toastIcons = {
  warning: 'alert',
  info: 'information',
  success: 'check-circle',
  danger: 'close-circle'
}

/**
 * TODO
 */
const toastOptions = {
  hasIcon: true,
  iconSize: 'medium',
  rootClass: 'toast-notification',
  position: 'bottom',
  closable: true,
  duration: 5000,
  queue: true
}

/**
 * TODO
 * @returns
 */
export const useMixins = () => {
  const route = useRoute()
  const router = useRouter()
  const oruga = useOruga()

  function setPageTitle(title) {
    EventBus.dispatch('setPageTitle', title)
    nextTick().then(() => {
      document.title = makeTitle(title)
    })
  }

  function navigate(name, more = {}) {
    router.push({ name, ...more }).catch(() => { })
  }

  function updateQuery(update, push = false) {
    const call = push ? router.push : router.replace
    return call({
      ...route,
      query: {
        ...route.query,
        ...update
      }
    }).catch(() => { })
  }

  function updateQueryJS(update) {
    const { location } = window
    const searchParams = new URLSearchParams(location.search)
    for (const key in update) {
      if (update[key] === null) {
        searchParams.delete(key)
      } else {
        searchParams.set(key, update[key])
      }
    }
    const { protocol, host, pathname } = location
    const newURL = protocol + '//' + host + pathname + '?' + searchParams
    window.history.replaceState({}, '', newURL)
  }

  function parseQuery() {
    const { location } = window
    const searchParams = new URLSearchParams(location.search)
    return Object.fromEntries(searchParams)
  }

  function closeAllToasts() {
    oruga.notification.closeAll({ action: 'closeAll' })
  }

  function toast(options) {
    oruga.notification.open({
      ...toastOptions,
      icon: toastIcons[options.variant || 'info'],
      ...options
    })
  }

  function displayErrors(errors) {
    if (!Array.isArray(errors) || !errors.length) {
      return
    }

    if (!('errorMessages' in window)) {
      window.errorMessages = []
    }

    window.errorMessages.push(errors)
  }

  function scrollToBottom() {
    setTimeout(() => {
      window.scrollTo({
        top: document.body.offsetHeight,
        behavior: 'smooth'
      })
    }, 300)
  }

  function notAllowed(e) {
    if (e?.response?.status === 403) {
      toast({
        variant: 'warning',
        message: 'You are not allowed to do that.'
      })
    } else {
      toast({
        variant: 'warning',
        message: e.toString()
      })
    }
  }

  function notFound() {
    navigate('NotFound')
  }

  function setFavicon(isSaved) {
    const icon = `/icons/favicon${isSaved ? '' : '-unsaved'}`
    document.getElementById('favicon-16').href = `${icon}-16x16.png`
    document.getElementById('favicon-32').href = `${icon}-32x32.png`
  }

  return {
    setPageTitle,
    navigate,
    updateQuery,
    updateQueryJS,
    parseQuery,
    closeAllToasts,
    toast,
    displayErrors,
    scrollToBottom,
    notAllowed,
    notFound,
    setFavicon
  }
}

/**
 * TODO
 * 
 * @returns 
 */
export function usePreviousRoute() {
  const router = useRouter()
  const previousRoute = computed(() => {
    const backURL = router.options.history.state.back
    return router.resolve({ path: backURL })
  })

  return { previousRoute }
}

/**
 * TODO
 */
export function useCrisp() {
  function crispDo(action) {
    if (import.meta.env.PROD && location.hostname === 'app.holori.com') {
      window.$crisp.push(['do', action])
    }
  }

  function hideCrisp() {
    crispDo('chat:hide')
  }

  function showCrisp() {
    crispDo('chat:show')
  }

  onMounted(hideCrisp)
  onUnmounted(showCrisp)
}
