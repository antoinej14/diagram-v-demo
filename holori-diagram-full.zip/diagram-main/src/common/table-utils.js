export const verticallyCentered = () => ({ class: 'is-vcentered' })

export const verticallyCenteredRight = () => ({ class: 'is-vcentered has-text-right' })
