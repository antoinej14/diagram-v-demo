/**
 * TODO
 * @param {*} fn
 * @param {*} delay
 * @returns
 */
export const debounce = (fn, delay = 300) => {
  let timer
  return function () {
    const context = this
    const args = arguments
    clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(context, args)
    }, delay)
  }
}

/**
 * TODO
 */
const ticks = {
  color: '#6F6F77',
  font: {
    family: 'Inter, sans-serif',
    size: 12
  }
}

/**
 * TODO
 */
export const chartjsOptions = {
  scales: {
    x: {
      ticks
    },
    y: {
      min: 0,
      ticks
    }
  },
  plugins: {
    datalabels: {
      display: false
    },
    legend: {
      labels: {
        color: '#6F6F77',
        font: {
          family: 'Inter, sans-serif',
          size: 12
        }
      }
    }
  }
}

/**
 * TODO
 */
export const availableRoles = [
  {
    name: 'owner',
    description: 'Owners have full access to billing, views and team management.',
    permissions: [
      'edit-billing',
      'edit-views',
      'edit-teams',
      'edit-cloud-accounts',
      'edit-notifications'
    ]
  },
  {
    name: 'editor',
    description: 'Editors have full access to billing and views but can’t manage teams.',
    permissions: ['edit-billing', 'edit-views']
  },
  {
    name: 'viewer',
    description:
      'Viewers can see billing, recommendations but won’t be able to modify elements or create views.',
    permissions: []
  }
]

/**
 * TODO
 * @param {*} content
 * @param {*} fileName
 * @param {*} format
 */
export function downloadFile(content, fileName, format) {
  const link = document.createElement('a')
  link.setAttribute('download', fileName)

  if (format === 'image/svg') {
    link.setAttribute('href', `data:image/svg+xml;base64,${btoa(content)}`)
  } else {
    link.setAttribute('href', content)
  }

  link.click()
}

/**
 * TODO
 */
const providerColors = {
  'alibaba cloud': '#FE6900',
  alibaba: '#FE6900',
  aws: '#FF9900',
  'amazon web services': '#FF9900',
  azure: '#36B9ED',
  'microsoft azure': '#36B9ED',
  cloudflare: '#f4811f',
  gcp: '#FF3D00',
  linode: '#1CB35C',
  ovh: '#000E9C',
  oracle: '#F80102',
  oci: '#F80102',
  'digital ocean': '#0080FF',
  scaleway: '#4F0699',
  datadog: '#632ba6'
}

/**
 * TODO
 * @param {*} provider
 * @returns
 */
export function getProviderColor(provider) {
  return providerColors[provider.toLowerCase()]
}

/**
 * Extracts the fulfilled values from Promise.allSettled.
 * @param {PromiseSettledResult<Awaited<any>>} results The array of promises results.
 * @returns {{allData: Array<Object>, allErrors: Array<String>}}
 */
export function extractFulfilledValues(results) {
  const allData = []
  const allErrors = []

  for (const result of results) {
    const { status } = result

    switch (status) {
      case 'fulfilled':
        // success
        allData.push(result.value)
        break
      case 'rejected':
        // there was an error
        allErrors.push(result.reason)
        break
      case 'cancelled':
        // request got cancelled
        break
      default:
        console.warn('unhandled request status :', status)
        console.debug(result)
    }
  }

  return { allData, allErrors }
}

/**
 * TODO
 */
export const na = 'N/A'

/**
 * TODO
 * @param {*} hex
 * @returns
 */
export function invertColor(hex) {
  if (hex.indexOf('#') === 0) {
    hex = hex.slice(1)
  }
  // convert 3-digit hex to 6-digits.
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2]
  }
  if (hex.length !== 6) {
    throw new Error('Invalid HEX color.')
  }
  const r = parseInt(hex.slice(0, 2), 16)
  const g = parseInt(hex.slice(2, 4), 16)
  const b = parseInt(hex.slice(4, 6), 16)

  // https://stackoverflow.com/a/3943023/112731
  return r * 0.299 + g * 0.587 + b * 0.114 > 186 ? '#000000' : '#FFFFFF'
}

/**
 * Test deep equality between two objects
 * Works only with JSON data types
 *
 * @param {*} x first object
 * @param {*} y second object
 * @returns true if equals, false otherwise
 */
export function areObjectsEqual(x, y) {
  // test the basis
  if (x === y) {
    // they are exactly equals
    //   they might be the exact same "reference"
    //   or the same "basic" type and their values are equals
    return true
  }

  // get the type of each variable
  const typeX = typeof x
  const typeY = typeof y

  // ensure the two variables have the same data type
  if (typeX !== typeY) {
    // two different things can not be the same
    return false
  }

  if (typeX === 'object') {
    // the two variables are objects

    // test the keys in both objects
    const keysX = new Set(Object.keys(x))
    const keysY = new Set(Object.keys(y))

    if (keysX.difference(keysY).size > 0) {
      // some keys of x are not in y
      return false
    }

    if (keysY.difference(keysX).size > 0) {
      // some keys of y are not in z
      return false
    }

    // both objects have the same keys
    for (const key of Object.keys(x)) {
      // compare values in each object under the same key
      //  recursive call to this method
      if (!areObjectsEqual(x[key], y[key])) {
        // same key have different values
        return false
      }
    }

    // no difference found, the two objects are equals
    return true
  }

  if (typeX === 'array') {
    // the two variables are lists

    // ensure the list have the same size
    //   to not get index out of range later
    if (x.size !== y.size) {
      // the lists do not have the same size
      return false
    }

    // both list have the same size
    for (const i in x) {
      // compare value in each list under the same index
      //  recursive call to this method
      if (!areObjectsEqual(x[i], y[i])) {
        // same index have different values
        return false
      }
    }

    // no difference found, the two lists are equals
    return true
  }

  // other types : null, bool, number, string
  //  are already evaluated in the very first comparison
  return false
}

/**
 * Capitalize first letter of a string
 *
 * @param {*} str string to capitalize first letter from
 * @returns string with first letter capitalized
 */
export function capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}
