import { expect, test } from 'vitest'
import { calculatePagination } from './paginate.js'

test('calculatePagination()', () => {
  const page0Headers = {
    'content-range': 'bytes 0-10/10'
  }

  expect(calculatePagination(page0Headers)).toStrictEqual({
    total: 10,
    current: 1
  })

  const page1Headers = {
    'content-range': 'bytes 1025-2048/4096'
  }

  expect(calculatePagination(page1Headers)).toStrictEqual({
    total: 4096,
    current: 2
  })

  const page20Headers = {
    'content-range': 'bytes 191-200/200'
  }

  expect(calculatePagination(page20Headers)).toStrictEqual({
    total: 200,
    current: 20
  })
})
