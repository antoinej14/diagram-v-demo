const appName = 'Holori'

const separator = '-'

export const makeTitle = (title) => `${appName} ${separator} ${title}`
