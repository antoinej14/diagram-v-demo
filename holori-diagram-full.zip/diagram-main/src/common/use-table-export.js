import moment from 'moment'
import { useOruga } from '@oruga-ui/oruga-next'

import { downloadFile } from '@/common/utils.js'
import { REQUEST } from '@/common/cost-dashboard/dates.js'

import ExportCsvModal from '@/components/modal/ExportCsv.vue'

const numberFormats = {
  international(value) {
    return value
  },

  european(value) {
    return ('' + value).replace('.', ',')
  }
}

export function useTableExport(tableRef) {
  const oruga = useOruga()

  function exportTableData(options, title) {
    const { separator, includeLabels, numberFormat } = options

    const { data } = tableRef.value

    if (!data || data.length < 1) {
      console.info('no data to export as a csv')
      // TODO message to the user ?
      return
    }

    let columns = tableRef.value.columns

    if (!columns || columns.length < 1) {
      console.info('no table columns found, extracting them from table data')
      // extract all columns from first line/object of data
      columns = Object.keys(data[0]).map((colName) => ({
        field: colName,
        label: colName
      }))
    }

    const lines = data
      .map((row) => {
        // iterate over columns for each row of data
        return columns
          .map((col) => {
            if ('value' in col) {
              return col.value[row]
            }

            return row[col.field]
          })
          .map((value) => {
            if (isNaN(parseFloat(value))) {
              return JSON.stringify(value)
            }

            return numberFormats[numberFormat](value)
          })
          .join(separator)
      })
      .join('\n')

    let labels = ''

    if (includeLabels) {
      labels = columns.map((col) => col.label).join(separator) + '\n'
    }

    const content = `data:text/csv;charset=utf-8,${encodeURIComponent(labels + lines)}`

    const filename = `${title}-${moment().format(REQUEST)}.csv`

    downloadFile(content, filename, 'text/csv')
  }

  async function startExport(title) {
    const instance = oruga.modal.open({
      component: ExportCsvModal,
      trapFocus: true,
      props: {
        title
      }
    })

    const options = await instance.promise

    if (options) {
      exportTableData(options, title)
    }
  }

  return {
    startExport
  }
}
