import { expect, test } from 'vitest'
import { debounce, availableRoles, na, areObjectsEqual } from './utils.js'

test('debounce(fn, 300) should trigger "fn" once every 300ms at most', () => {
  const a = { count: 0 }

  const inc = debounce((a) => {
    a.count++
  }, 300)

  expect(a.count).toBe(0)

  // call the function 3 times
  inc(a)
  inc(a)
  inc(a)

  // wait for debounce to end
  setTimeout(() => {
    // inc should have been run only once
    expect(a.count).toBe(1)
  }, 400)
})

// TODO chartjsOptions

test('availableRoles = Array(owner, editor, viewer)', () => {
  const roles = ['owner', 'editor', 'viewer']

  for (const role of availableRoles) {
    expect(Object.keys(role)).toStrictEqual(['name', 'description', 'permissions'])
    expect(role.name).toBeOneOf(roles)
  }
})

// TODO downloadFile

// TODO getProviderColor

// TODO extractFulfilledValues

test('na = "N/A"', () => {
  expect(na).toBe('N/A')
})

// TODO invertColor

test('areObjectEqual() should test objects in depth', () => {
  let x = {}
  let y = {}
  expect(areObjectsEqual(x, y)).toBeTruthy()

  x = { a: 1 }
  y = x
  expect(areObjectsEqual(x, y)).toBeTruthy()

  x.a = 2
  y = { a: 2, b: 1 }
  expect(areObjectsEqual(x, y)).toBeFalsy()

  x.b = 1
  expect(areObjectsEqual(x, y)).toBeTruthy()

  x = { a: { a: { a: 1, b: [1, 2, { z: 'zzz', 0: null }] }, c: true }, d: 'test', e: null, f: 666 }
  y = { a: { a: { a: 1, b: [1, 2, { z: 'zzz', 0: null }] }, c: true }, d: 'test', e: null, f: 666 }
  expect(areObjectsEqual(x, y)).toBeTruthy()

  y.e = 123
  expect(areObjectsEqual(x, y)).toBeFalsy()

  x.e = 123
  expect(areObjectsEqual(x, y)).toBeTruthy()

  y.d = false
  expect(areObjectsEqual(x, y)).toBeFalsy()

  x.d = false
  expect(areObjectsEqual(x, y)).toBeTruthy()

  y.a.a.a = x.f
  expect(areObjectsEqual(x, y)).toBeFalsy()

  y.a.a.a = x.a.a.a
  expect(areObjectsEqual(x, y)).toBeTruthy()

  y.a.a.a = x.a
  expect(areObjectsEqual(x, y)).toBeFalsy()

  y.a = x.a
  expect(areObjectsEqual(x, y)).toBeTruthy()
})
