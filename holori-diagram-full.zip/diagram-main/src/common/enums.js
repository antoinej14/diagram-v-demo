export const FRONTEND_DIMENSIONS = {
  PROVIDER: 'provider', // not supported by API
  ACCOUNT: 'account', // not supported by API
  USAGE: 'usage', // not supported by API
  VIRTUAL_TAG: 'virtual_tag', // not supported by API
  SEGMENT: 'segment' // not supported by API
}

export const API_DIMENSIONS = {
  SERVICE: 'service',
  REGION: 'region',
  RESOURCE_ID: 'resource_id',
  USAGE_TYPE: 'usage_type',
  TAG: 'tag',
  TAG_KEY: 'tag_key',
  TAG_VALUE: 'tag_value',
  VIRTUAL_TAG: 'virtual_tag',
  VIRTUAL_TAG_KEY: 'virtual_tag_key',
  VIRTUAL_TAG_VALUE: 'virtual_tag_value',
  ACCOUNT_ID: 'account_id',
  K8S_CLUSTER: 'k8s_cluster',
  K8S_NAMESPACE: 'k8s_namespace',
  K8S_WORKLOAD_TYPE: 'k8s_workload_type',
  K8S_WORKLOAD_NAME: 'k8s_workload_name'
}

export const DIMENSIONS = {
  ...FRONTEND_DIMENSIONS,
  ...API_DIMENSIONS
}

export const GRANULARITIES = {
  DAILY: 'daily',
  WEEKLY: 'weekly', // not supported by API
  MONTHLY: 'monthly',
  YEARLY: 'yearly'
}

export const FILTERS = {
  ...API_DIMENSIONS,
  PROVIDER: 'provider', // cloud provider name
  ACCOUNT: 'account', // holori provider account id
  ACCOUNT_NAME: 'account_name',
  RESOURCE_NAME: 'resource_name',
  UNTAGGED: 'untagged'
}

export const COST_TYPES = {
  AMORTIZED: 'amortized',
  UNBLENDED: 'unblended'
}

export const COMMITMENT_TYPES = {
  DISCOUNT: 'discount',
  RESERVATION: 'reservation',
  CONTRACT: 'contract'
}

export const OPERATORS = {
  // generic
  IS: 'is',
  IS_NOT: 'is not',
  IS_IN: 'is in',
  IS_NOT_IN: 'is not in',
  // nullable
  IS_NULL: 'is null',
  IS_NOT_NULL: 'is not null',
  // text
  CONTAINS: 'contains',
  DOES_NOT_CONTAIN: 'does not contain'
}

export const ORDER_BY = {
  ASC: 'asc',
  DESC: 'desc'
}

// WIDGETS

export const WIDGET_GRAPH_TYPE = {
  BAR: 'bar',
  HORIZONTAL: 'horizontal',
  LINE: 'line',
  MAP: 'map',
  PIE: 'pie',
  SINGLE_DIGIT: 'single digit',
  AVERAGE: 'average',
  PROGRESS: 'progress',
  TABLE: 'table'
}

export const WIDGET_DATA_TYPE = {
  COST: 'cost',
  USAGE: 'usage',
  BUDGET: 'budget'
}

const DATA_TYPE_FIELD = {
  [WIDGET_DATA_TYPE.COST]: 'cost',
  [WIDGET_DATA_TYPE.USAGE]: 'quantity'
}

/**
 * Get the field name for a data type
 * @param {*} dataType WIDGET_DATA_TYPE to get the field name for
 * @returns field name for this data type
 */
export function getDataTypeField(dataType) {
  return DATA_TYPE_FIELD[dataType]
}
