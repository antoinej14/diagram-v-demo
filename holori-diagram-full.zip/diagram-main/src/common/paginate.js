/**
 * TODO
 *
 * start and end of the range must align with total divided by the page size
 * otherwise, data are out of alignment and this might return a page number inferior to expected
 *
 * @param {*} headers
 * @returns
 */
export const calculatePagination = (headers) => {
  // parse fields
  const [, value] = headers['content-range'].split(' ', 2)
  const [range, totalAsText] = value.split('/', 2)
  const [startAsText, endAsText] = range.split('-', 2)

  // convert them to numbers
  const total = +totalAsText
  const start = +startAsText
  const end = +endAsText

  // compute the page
  const limit = end - (start - 1)
  const current = start >= total ? -1 : Math.round(start / limit) + 1

  return { total, current }
}
