/**
 * TODO
 */
const eventBus = {
  /**
   * TODO
   *
   * @param {*} event
   * @param {*} callback
   */
  on(event, callback) {
    document.addEventListener(event, (e) => callback(e.detail))
  },

  /**
   * TODO
   *
   * @param {*} event
   * @param {*} data
   */
  dispatch(event, data) {
    document.dispatchEvent(new CustomEvent(event, { detail: data }))
  },

  /**
   * TODO
   *
   * @param {*} event
   * @param {*} callback
   */
  remove(event, callback) {
    document.removeEventListener(event, callback)
  }
}

export default eventBus
