export function createClickableAxisLabelPlugin(onLabelClick) {
  return {
    id: 'customHover',
    afterEvent: (chart, event) => {
      const yScale = chart.scales.y
      const {
        event: { x: offsetX, y: offsetY }
      } = event

      if (!yScale || event.event.type !== 'click') return

      const widest = yScale._labelSizes.widest.width

      const labelPositions = yScale.ticks.map((tick, index) => {
        const split = tick.label.split(' - ')
        split.shift()
        const y = yScale.getPixelForTick(index)
        const width = yScale._labelSizes.widths[index]
        const height = yScale._labelSizes.heights[index]
        return {
          label: split.join(' - '),
          index,
          x: widest - width,
          x2: widest,
          y: y - height,
          y2: y
        }
      })

      labelPositions.forEach((pos) => {
        if (offsetY >= pos.y && offsetY <= pos.y2 && offsetX >= pos.x && offsetX <= pos.x2) {
          onLabelClick(pos.label)
        }
      })
    }
  }
}
