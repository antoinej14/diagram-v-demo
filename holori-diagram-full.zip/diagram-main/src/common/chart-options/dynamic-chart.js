import { useAppStore } from '@/store/app'
import { chartjsOptions } from '@/common/utils'

export function getDynamicChartOptions(
  includeBusinessMetric = false,
  emit = null,
  horizontal = false,
  stacked = true,
  costOrUsage = null
) {
  const appStore = useAppStore()

  let xTicks = {}

  if (horizontal) {
    xTicks = {
      ...chartjsOptions.scales.y.ticks,
      callback(value) {
        if (costOrUsage === 'cost') {
          return appStore.makeCurrencyLabel(value)
        }

        const unit = '' // TODO where to find it ????

        return appStore.makeUsageLabel(value, unit)
      }
    }
  }

  let yTicks = {}

  if (!horizontal) {
    yTicks = {
      ...chartjsOptions.scales.y.ticks,
      callback(value) {
        if (costOrUsage === 'cost') {
          return appStore.makeCurrencyLabel(value)
        }

        return appStore.makeUsageLabel(value, null)
      }
    }
  }

  const options = {
    indexAxis: horizontal ? 'y' : 'x',
    responsive: true,
    maintainAspectRatio: false,
    animation: false,
    scales: {
      x: {
        ...chartjsOptions.scales.x,
        stacked: true,
        ticks: xTicks
      },
      y: {
        min: 0,
        stacked: stacked,
        ticks: yTicks
      }
    },
    plugins: {
      datalabels: {
        display: false
      },
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label(item) {
            let label = item.label || ''

            if (!horizontal) {
              label = item.dataset.label || ''
            }

            if (item.dataset.yAxisID === 'businessMetric') {
              return `${label}: ${item.raw}`
            }

            if (costOrUsage === 'cost') {
              return `${label}: ${appStore.makeCurrencyLabel(item.raw)}`
            }

            let unit = item.dataset.unit || ''
            if (horizontal) {
              unit = item.dataset.units[label] || ''
            }

            return `${label}: ${appStore.makeUsageLabel(item.raw, unit)}`
          }
        }
      }
    },
    onClick: (e) => {
      if (emit) {
        const { chart } = e
        const points = chart.getElementsAtEventForMode(e, 'nearest', { intersect: true }, true)

        const [firstPoint] = points
        if (firstPoint) {
          const cell = chart.data.datasets[firstPoint.datasetIndex].id + '-' + firstPoint.index
          emit && emit('highlight', cell)
        }
      }
    }
  }

  if (includeBusinessMetric) {
    options.scales.businessMetric = {
      display: true,
      position: 'top',
      grid: {
        drawOnChartArea: false // only want the grid lines for one axis to show up
      },
      ticks: {
        display: false
      }
    }
  }

  return options
}
