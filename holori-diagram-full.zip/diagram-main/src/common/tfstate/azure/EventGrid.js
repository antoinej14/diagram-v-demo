export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'System data',
    key: 'system_data',
    icon: 'information-outline'
  },
  {
    type: 'array',
    name: 'Private endpoint connections',
    key: 'private_endpoint_connections',
    icon: 'power-plug'
  },
  {
    type: 'simple',
    name: 'Provisioning state',
    key: 'provisioning_state',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Endpoint',
    key: 'endpoint',
    icon: 'power-plug'
  },
  {
    type: 'boolean',
    name: 'Disable local auth',
    key: 'disable_local_auth',
    icon: 'lock'
  }
]
