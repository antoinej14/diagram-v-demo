export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  },
  {
    type: 'simple',
    name: 'Private endpoint network policies',
    key: 'private_endpoint_network_policies',
    icon: 'network'
  }
]
