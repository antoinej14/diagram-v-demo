export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'OS type',
    key: 'os_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Restart policy',
    key: 'restart_policy',
    icon: 'restart'
  },
  {
    type: 'simple',
    name: 'Provisioning state',
    key: 'provisioning_state',
    icon: 'information-outline'
  },
  {
    type: 'section',
    name: 'Containers',
    key: 'containers.resources',
    entries: {
      fields: [
        {
          name: 'Memory (GB)',
          key: 'memory_in_gb'
        },
        {
          name: 'CPU',
          key: 'cpu'
        }
      ]
    }
  }
]
