export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Go to console',
    key: 'id',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Created by',
    key: 'system_data.created_by',
    icon: 'account'
  },
  {
    type: 'date',
    name: 'Created at',
    key: 'system_data.created_at',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Last modified by',
    key: 'system_data.last_modified_by',
    icon: 'account'
  },
  {
    type: 'date',
    name: 'Last modified at',
    key: 'system_data.last_modified_at',
    icon: 'calendar'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  }
]
