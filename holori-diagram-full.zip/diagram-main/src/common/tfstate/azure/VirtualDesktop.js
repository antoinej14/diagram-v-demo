export default [
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Created by',
    key: 'system_data.created_by',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Created by type',
    key: 'system_data.created_by_type',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Created at',
    key: 'system_data.created_at',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Last modified by',
    key: 'system_data.last_modified_by',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Last modified by type',
    key: 'system_data.last_modified_by_type',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Last modified at',
    key: 'system_data.last_modified_at',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Description',
    key: 'description',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'File path',
    key: 'file_path',
    icon: 'map-marker-path'
  },
  {
    type: 'simple',
    name: 'Application type',
    key: 'application_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Icon path',
    key: 'icon_path',
    icon: 'map-marker-path'
  }
]
