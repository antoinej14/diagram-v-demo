export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Go to console',
    key: 'id',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Created at',
    key: 'createdAt',
    icon: 'calendar'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  },
  {
    type: 'simple',
    name: 'Max number of record sets',
    key: 'max_number_of_record_sets',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Max number of virtual network links',
    key: 'max_number_of_virtual_network_links',
    icon: 'network-outline'
  },
  {
    type: 'simple',
    name: 'Max number of virtual network links with registration',
    key: 'max_number_of_virtual_network_links_with_registration',
    icon: 'network-outline'
  },
  {
    type: 'simple',
    name: 'Number of record sets',
    key: 'number_of_record_sets',
    icon: 'counter'
  }
]
