export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  },
  {
    type: 'simple',
    name: 'DNS name',
    key: 'dns_name',
    icon: 'dns-outline'
  }
]
