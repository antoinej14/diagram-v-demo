export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Lease state',
    key: 'lease_state',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Last modified',
    key: 'last_modified_time',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Share quota',
    key: 'share_quota',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Access tier',
    key: 'access_tier',
    icon: 'information-outline'
  }
]
