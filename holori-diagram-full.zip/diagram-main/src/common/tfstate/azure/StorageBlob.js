export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Lease state',
    key: 'lease_state',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Public Access',
    key: 'public_access',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Default encryption scope',
    key: 'default_encryption_scope',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Last modified',
    key: 'last_modified_time',
    icon: 'calendar'
  }
]
