export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'created_date',
    icon: 'calendar'
  },
  {
    type: 'date',
    name: 'Modification date',
    key: 'modified_date',
    icon: 'calendar'
  },
  {
    type: 'computed',
    name: 'Retention',
    key: 'retention_in_days',
    icon: 'counter',
    value: '$val day(s)'
  },
  {
    type: 'simple',
    name: 'Access for ingestion',
    key: 'public_network_access_for_ingestion',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Access for query',
    key: 'public_network_access_for_query',
    icon: 'information-outline'
  }
]
