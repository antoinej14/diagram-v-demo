export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Power state',
    key: 'power_state',
    icon: 'power'
  },
  {
    type: 'simple',
    name: 'Kubernetes version',
    key: 'kubernetes_version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Max agent pools',
    key: 'max_agent_pools',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Current Kubernetes version',
    key: 'current_kubernetes_version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'DNS prefix',
    key: 'dns_prefix',
    icon: 'dns-outline'
  },
  {
    type: 'simple',
    name: 'Linux profile',
    key: 'linux_profile',
    icon: 'linux'
  },
  {
    type: 'simple',
    name: 'Linux profile',
    key: 'linux_profile',
    icon: 'linux'
  },
  {
    type: 'simple',
    name: 'Windows profile',
    key: 'windows_profile',
    icon: 'microsoft-windows'
  },
  {
    type: 'simple',
    name: 'Windows profile',
    key: 'windows_profile',
    icon: 'microsoft-windows'
  },
  {
    type: 'simple',
    name: 'Pod identity profile',
    key: 'pod_identity_profile',
    icon: 'account'
  },
  {
    type: 'simple',
    name: 'Node resource group',
    key: 'node_resource_group',
    icon: 'group'
  },
  {
    type: 'boolean',
    name: 'Enable pod security policy',
    key: 'enable_pod_security_policy',
    icon: 'security'
  },
  {
    type: 'simple',
    name: 'Disk encryption set ID',
    key: 'disk_encryption_set_id',
    icon: 'lock'
  },
  {
    type: 'simple',
    name: 'Cluster resource ID',
    key: 'cluster_resource_id',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Properties',
    key: 'properties',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Hub profile',
    key: 'hub_profile',
    icon: 'account'
  },
  {
    type: 'simple',
    name: 'VM size',
    key: 'icon_size',
    icon: 'memory'
  },
  {
    type: 'computed',
    name: 'OS disk size',
    key: 'os_disk_size_gb',
    icon: 'disk',
    value: '$val GB'
  },
  {
    type: 'simple',
    name: 'OS disk type',
    key: 'os_disk_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Kubelet disk type',
    key: 'kubelet_disk_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Kubelet disk type',
    key: 'kubelet_disk_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Kubelet disk type',
    key: 'kubelet_disk_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Workload runtime',
    key: 'workload_runtime',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Max pods',
    key: 'max_pods',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'OS type',
    key: 'os_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Max count',
    key: 'max_count',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Min count',
    key: 'min_count',
    icon: 'counter'
  },
  {
    type: 'boolean',
    name: 'Enable auto-scaling',
    key: 'enable_auto_scaling',
    icon: 'check'
  },
  {
    type: 'simple',
    name: 'Scale down mode',
    key: 'scale_down_mode',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'GPU instance profile',
    key: 'gpu_instance_profile',
    icon: 'gpu'
  },
  {
    type: 'simple',
    name: 'Creation data',
    key: 'creation_data',
    icon: 'information-outline'
  }
]
