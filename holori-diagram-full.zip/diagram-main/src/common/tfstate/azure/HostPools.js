export default [
  {
    type: 'url',
    name: 'ID',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Created by',
    key: 'system_data.created_by',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Created at',
    key: 'system_data.created_at',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Last modified by type',
    key: 'system_data.last_modified_by_type',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Last modified at',
    key: 'system_data.last_modified_at',
    icon: 'calendar'
  },
  {
    type: 'array',
    name: 'Tags',
    key: 'tags',
    icon: 'tag-multiple-outline'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Friendly name',
    key: 'friendly_name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Host pool type',
    key: 'host_pool_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Max session limit',
    key: 'max_session_limit',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Load balancer type',
    key: 'load_blancer_type',
    icon: 'scale-balance'
  },
  {
    type: 'simple',
    name: 'Ring',
    key: 'ring',
    icon: 'circle-outline'
  },
  {
    type: 'boolean',
    name: 'Start VM on connect',
    key: 'start_vm_on_connect',
    icon: 'lan-connect'
  },
  {
    type: 'boolean',
    name: 'Cloud PC resource',
    key: 'cloud_pc_resource',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Maintenance windows hour',
    key: 'maintenance_windows.hour',
    icon: 'calendar-clock'
  },
  {
    type: 'simple',
    name: 'Maintenance windows day of week',
    key: 'maintenance_windows.day_of_week',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Public network access',
    key: 'public_network_access',
    icon: 'network-outline'
  },
  {
    type: 'simple',
    name: 'Preferred App Group type',
    key: 'preferred_app_group_type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Personal desktop assignment type',
    key: 'personal_desktop_assignment_type',
    icon: 'desktop-classic'
  }
]
