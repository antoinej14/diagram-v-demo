export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Operational state',
    key: 'operational_state'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Port',
    key: 'frontend_ports.port',
    icon: 'power-plug'
  },
  {
    type: 'boolean',
    name: 'Enable HTTP2',
    key: 'enable_http2',
    icon: 'check'
  }
]
