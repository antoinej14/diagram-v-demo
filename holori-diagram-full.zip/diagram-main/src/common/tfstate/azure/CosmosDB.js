export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Document endpoint',
    key: 'documentEndpoint',
    icon: 'power-plug'
  },
  {
    type: 'simple',
    name: 'Default consistency level',
    key: 'consistencypolicy.defaultConsistencyLevel',
    icon: 'information-outline'
  },
  {
    type: 'computed',
    name: 'Max interval',
    key: 'consistencypolicy.maxIntervalInSeconds',
    icon: 'timer-outline',
    value: '$val s'
  },
  {
    type: 'simple',
    name: 'Staleness prefix',
    key: 'consistencypolicy.maxStalenessPrefix',
    icon: 'ínformation-outline'
  },
  {
    type: 'simple',
    name: 'Account offer type',
    key: 'databaseAccountOfferType',
    icon: 'offer'
  }
]
