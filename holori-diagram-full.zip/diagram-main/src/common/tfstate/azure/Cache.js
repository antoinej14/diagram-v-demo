export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioning_state'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'System data',
    key: 'system_data',
    icon: 'information-outline'
  },
  {
    type: 'computed',
    name: 'Cache size',
    key: 'cache_size',
    icon: 'disk',
    value: '$val GB'
  },
  {
    type: 'array',
    name: 'Mount addresses',
    key: 'mount_addresses',
    icon: 'ip'
  }
]
