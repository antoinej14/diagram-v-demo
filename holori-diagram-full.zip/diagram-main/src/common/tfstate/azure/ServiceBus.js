export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Created at',
    key: 'createdAt',
    icon: 'calendar'
  },
  {
    type: 'state',
    name: 'Provisioning state',
    key: 'provisioningState'
  }
]
