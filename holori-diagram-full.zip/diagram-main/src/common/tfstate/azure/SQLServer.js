export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'State',
    key: 'state'
  },
  {
    type: 'simple',
    name: 'Version',
    key: 'version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Fully qualified domain name',
    key: 'fully_qualified_domain_name',
    icon: 'domain'
  },
  {
    type: 'simple',
    name: 'Public network access',
    key: 'public_network_access',
    icon: 'network-outline'
  },
  {
    type: 'simple',
    name: 'Administrator type',
    key: 'administrators.administrator_type',
    icon: 'account-key'
  }
]
