export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Disk state',
    key: 'disk_state',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'computed',
    name: 'Disk size',
    key: 'disk_size_gb',
    icon: 'harddisk',
    value: '$val GB'
  },
  {
    type: 'simple',
    name: 'OS type',
    key: 'os_type',
    icon: 'linux'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'time_created',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'SKU',
    key: 'sku.name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'IOPS',
    key: 'disk_iops_read_write',
    icon: 'speedometer'
  },
  {
    type: 'computed',
    name: 'Read/write speed',
    key: 'disk_m_bps_read_write',
    value: '$val MBPs',
    icon: 'speedometer'
  },
  {
    type: 'simple',
    name: 'Encryption',
    key: 'encryption.type',
    icon: 'lock'
  }
]
