export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Provisioning state',
    key: 'provisioning_state',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Max fragmentation memory reserved',
    key: 'redis_configuration.maxfragmentationmemory_reserved',
    icon: 'memory'
  },
  {
    type: 'simple',
    name: 'Max memory reserved',
    key: 'redis_configuration.maxmemory_reserved',
    icon: 'memory'
  },
  {
    type: 'simple',
    name: 'Max memory reserved',
    key: 'redis_configuration.maxmemory_delta',
    icon: 'delta'
  },
  {
    type: 'simple',
    name: 'Max clients',
    key: 'redis_configuration.maxclients',
    icon: 'account-multiple'
  },
  {
    type: 'simple',
    name: 'Redis version',
    key: 'redis_version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Port',
    key: 'port',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'SSL Port',
    key: 'ssl_port',
    icon: 'information-outline'
  },
  {
    type: 'array',
    name: 'Tags',
    key: 'tags',
    icon: 'tag-multiple'
  }
]
