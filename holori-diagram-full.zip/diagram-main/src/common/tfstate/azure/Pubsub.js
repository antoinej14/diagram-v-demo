export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'System data',
    key: 'system_data',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Provisioning state',
    key: 'provisioning_state',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'External IP',
    key: 'external_ip',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'Public port',
    key: 'public_port',
    icon: 'power-plug'
  },
  {
    type: 'simple',
    name: 'Server port',
    key: 'server_port',
    icon: 'power-plug'
  },
  {
    type: 'simple',
    name: 'TLS settings',
    key: 'tls',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Public network access',
    key: 'public_network_access',
    icon: 'network'
  },
  {
    type: 'boolean',
    name: 'Disable local auth',
    key: 'disable_local_auth',
    icon: 'lock'
  },
  {
    type: 'boolean',
    name: 'Disable AAD auth',
    key: 'disable_aad_auth',
    icon: 'lock'
  }
]
