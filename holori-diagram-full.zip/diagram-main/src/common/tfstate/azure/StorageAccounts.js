export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Kind',
    key: 'kind',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'Status of primary',
    key: 'status_of_primary'
  },
  {
    type: 'simple',
    name: 'Access tier',
    key: 'sku.tier',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Secondary location',
    key: 'secondary_location',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'Status of secondary',
    key: 'status_of_secondary'
  }
]
