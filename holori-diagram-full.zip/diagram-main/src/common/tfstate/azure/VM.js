export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'VM size',
    key: 'hardware_profile.vm_size',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'Power state',
    key: 'power_state'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'VM ID',
    key: 'vm_id',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'time_created',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Provisioning state',
    key: 'provisioning_state',
    icon: 'information-outline'
  },
  {
    type: 'section',
    name: 'Attached disks',
    key: 'os_disk',
    entries: {
      id: 'name',
      icon: 'aws/Storage/Elastic-Block-Store.svg',
      fields: [
        {
          name: 'Name',
          key: 'name'
        },
        {
          name: 'OS type',
          key: 'os_type'
        },
        {
          name: 'Disk Size (GB)',
          key: 'disk_size_gb'
        },
        {
          name: 'Storage account type',
          key: 'managed_disk.storage_account_type'
        }
      ]
    }
  }
]
