export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Private IP address',
    key: 'frontend_ip_configurations.0.private_ip_address',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'Private IP address version',
    key: 'frontend_ip_configurations.0.private_ip_address_version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Private IP allocation method',
    key: 'frontend_ip_configurations.0.private_ip_allocation_method',
    icon: 'information-outline'
  }
]
