export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Kind',
    key: 'kind',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'id',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'State',
    key: 'state'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Container size',
    key: 'container_size',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Daily memory time quota',
    key: 'daily_memory_time_quota',
    icon: 'memory'
  },
  {
    type: 'simple',
    name: 'Number of workers',
    key: 'site_config.number_of_workers',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Linux FX version',
    key: 'site_config.linux_fx_version',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'App scale limit',
    key: 'site_config.function_app_scale_limit',
    icon: 'scale-balance'
  },
  {
    type: 'array',
    name: 'Tags',
    key: 'tags.tags-tes',
    icon: 'tag'
  }
]
