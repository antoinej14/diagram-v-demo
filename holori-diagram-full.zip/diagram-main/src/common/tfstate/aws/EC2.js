export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'State',
    key: 'State.Name'
  },
  {
    type: 'simple',
    name: 'Instance type',
    key: 'InstanceType',
    icon: 'check-circle-outline'
  },
  {
    type: 'computed',
    name: 'Key name',
    key: 'KeyName',
    icon: 'information-outline',
    value(val, tf) {
      if (!tf || tf.tags) {
        return val
      }
      return Object.values(tf.tags || {}).find(({ key }) => key === 'Name')?.value || val
    }
  },
  {
    type: 'simple',
    name: 'Instance ID',
    key: 'InstanceId',
    icon: 'server-outline'
  },
  {
    type: 'url',
    name: 'Instance URL',
    key: 'PublicDnsName',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Availability zone',
    key: 'Placement.AvailabilityZone',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Launch time',
    key: 'LaunchTime',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Public IP address',
    key: 'PublicIpAddress',
    icon: 'ip',
    label: true
  },
  {
    type: 'simple',
    name: 'Private IP address',
    key: 'PrivateIpAddress',
    icon: 'ip',
    label: true
  },
  {
    type: 'section',
    name: 'EBS attached',
    key: 'BlockDeviceMappings',
    entries: {
      id: 'Ebs.VolumeId',
      icon: 'aws/Storage/Elastic-Block-Store.svg',
      fields: [
        {
          name: 'VolumeID',
          key: 'VolumeId'
        },
        {
          name: 'Size',
          key: 'Size'
        }
      ]
    }
  }
]
