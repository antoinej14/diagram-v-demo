export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Availability zone',
    key: 'AvailabilityZone',
    icon: 'map-marker'
  },
  {
    type: 'state',
    name: 'State',
    key: 'State'
  },
  {
    type: 'simple',
    name: 'Volume ID',
    key: 'VolumeId',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Snapshot ID',
    key: 'SnapshotId',
    icon: 'cog'
  },
  {
    type: 'computed',
    name: 'Size',
    key: 'Size',
    icon: 'harddisk',
    value: '$val GB'
  },
  {
    type: 'simple',
    name: 'IOPS',
    key: 'Iops',
    icon: 'speedometer',
    label: true
  },
  {
    type: 'simple',
    name: 'Volume type',
    key: 'VolumeType',
    icon: 'package-variant'
  },
  {
    type: 'date',
    name: 'Create date',
    key: 'CreateTime',
    icon: 'calendar',
    label: true
  }
]
