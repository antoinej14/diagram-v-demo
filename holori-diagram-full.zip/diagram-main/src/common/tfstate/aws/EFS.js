export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'File system ID',
    key: 'FileSystemId',
    icon: 'check-circle-outline'
  },
  {
    type: 'state',
    name: 'State',
    key: 'LifeCycleState'
  },
  {
    type: 'simple',
    name: 'File System ARN',
    key: 'FileSystemArn',
    icon: 'earth'
  },
  {
    type: 'date',
    name: 'Create date',
    key: 'CreationTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'computed',
    name: 'Number of mount targets',
    key: 'NumberOfMountTargets',
    icon: 'cog',
    value: '$val mount targets'
  },
  {
    type: 'simple',
    name: 'Performance mode',
    key: 'PerformanceMode',
    icon: 'speedometer'
  },
  {
    type: 'simple',
    name: 'Throughput',
    key: 'ThroughputMode',
    icon: 'package-variant'
  },
  {
    type: 'computed',
    name: 'Size',
    key: 'SizeInBytes.Value',
    icon: 'harddisk',
    value: '$val Bytes'
  },
  {
    type: 'boolean',
    name: 'Encrypted',
    key: 'Encrypted',
    icon: 'lock',
    values: {
      true: 'Encrypted',
      false: 'Not encrypted'
    }
  },
  {
    type: 'section',
    name: 'Mount targets',
    key: 'mount_targets',
    entries: {
      hideName: true,
      icon: 'aws/Storage/EFS.svg',
      fields: [
        {
          name: 'Mount target ID',
          key: 'MountTargetId'
        },
        {
          name: 'IP address',
          icon: 'ip',
          key: 'IpAddress'
        },
        {
          name: 'Network interface ID',
          key: 'NetworkInterfaceId'
        }
      ]
    }
  }
]
