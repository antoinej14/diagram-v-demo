export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'State',
    key: 'State.Name'
  },
  {
    type: 'simple',
    name: 'ARN',
    key: 'Arn',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Availability zone',
    key: 'Location.AvailabilityZone',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Resource type',
    key: 'ResourceType',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'Blueprint name',
    key: 'BlueprintName',
    icon: 'information-outline'
  },
  {
    type: 'computed',
    name: 'CPUs',
    key: 'Hardware.CpuCount',
    icon: 'chip',
    value: '$val CPUs'
  },
  {
    type: 'computed',
    name: 'Disk',
    key: 'Hardware.Disks.0.SizeInGb',
    icon: 'harddisk',
    value: '$val GB',
    label: true
  },
  {
    type: 'computed',
    name: 'Memory',
    key: 'Hardware.RamSizeInGb',
    icon: 'memory',
    value: '$val GB',
    label: true
  },
  {
    type: 'date',
    name: 'Launch date',
    key: 'CreatedAt',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Public IP',
    key: 'PublicIpAddress',
    icon: 'ip',
    label: true
  },
  {
    type: 'simple',
    name: 'Private IP',
    key: 'PrivateIpAddress',
    icon: 'ip',
    label: true
  }
]
