export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'computeEnvironmentName',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'State',
    key: 'state'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'check-circle-outline'
  },
  {
    type: 'url',
    name: 'ECS Cluster ARN',
    key: 'ecsClusterArn',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Compute resources',
    key: 'computeResources.type',
    icon: 'chip'
  },
  {
    type: 'simple',
    name: 'Container orchestration type',
    key: 'containerOrchestrationType',
    icon: 'package-variant'
  }
]
