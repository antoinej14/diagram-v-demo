export default [
  {
    type: 'simple',
    name: 'ID',
    key: 'TransitGatewayId',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'ARN',
    key: 'TransitGatewayArn',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'State'
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'CreationTime',
    icon: 'calendar'
  },
  {
    type: 'list',
    name: 'Tags',
    key: 'Tags',
    icon: 'tag'
  }
]
