export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'LoadBalancerName',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'ARN',
    key: 'LoadBalancerArn',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'State'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'CreatedTime',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'IP address type',
    key: 'IpAddressType',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'DNS name',
    key: 'DNSName',
    icon: 'dns'
  },
  {
    type: 'section',
    name: 'Associated subnets',
    key: 'BlockDeviceMappings',
    entries: {
      id: 'Ebs.VolumeId',
      icon: 'aws/Storage/Elastic-Block-Store.svg',
      fields: [
        {
          name: 'VolumeID',
          key: 'VolumeId'
        },
        {
          name: 'Size',
          key: 'Size'
        }
      ]
    }
  }
]
