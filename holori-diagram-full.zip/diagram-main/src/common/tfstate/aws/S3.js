export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'Name',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Creation',
    key: 'CreationDate',
    icon: 'calendar',
    label: true
  }
]
