export default [
  {
    type: 'simple',
    name: 'Gateway ID',
    key: 'VpnGatewayId',
    icon: 'check-circle-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'State'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'Type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Side Asn',
    key: 'AmazonSideAsn',
    icon: 'information-outline'
  },
  {
    type: 'list',
    name: 'Tags',
    key: 'Tags',
    icon: 'tag'
  }
]
