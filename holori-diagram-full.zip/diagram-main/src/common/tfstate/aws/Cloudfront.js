export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'DomainName',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'ARN',
    key: 'arn',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'ID',
    key: 'Id',
    icon: 'check-circle-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'date',
    name: 'Last modified date',
    key: 'LastModifiedDate',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'HTTP version',
    key: 'HttpVersion',
    icon: 'web'
  }
]
