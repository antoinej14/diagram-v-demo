export default [
  {
    type: 'simple',
    name: 'Function name',
    key: 'FunctionName',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Description',
    key: 'Description',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'Availability zone',
    key: 'Placement.AvailabilityZone',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Runtime',
    key: 'Runtime',
    icon: 'cog'
  },
  {
    type: 'computed',
    name: 'Code size',
    key: 'CodeSize',
    icon: 'harddisk',
    value: '$val in size'
  },
  {
    type: 'computed',
    name: 'Timeout',
    key: 'Timeout',
    icon: 'timer',
    value: '$valsec timeout'
  },
  {
    type: 'computed',
    name: 'Memory size',
    key: 'MemorySize',
    icon: 'memory',
    value: '$val MB'
  },
  {
    type: 'simple',
    name: 'Package type',
    key: 'PackageType',
    icon: 'zip-box-outline'
  },
  {
    type: 'date',
    name: 'Last modified',
    key: 'LastModified',
    icon: 'calendar',
    label: true
  }
]
