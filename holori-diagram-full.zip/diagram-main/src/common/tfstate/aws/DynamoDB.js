export default [
  {
    type: 'simple',
    name: 'Table name',
    key: 'TableName',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Table ARN',
    key: 'TableArn',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Table status',
    key: 'TableStatus'
  },
  {
    type: 'TableId',
    name: 'Table ID',
    key: 'TableId',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Billing mode',
    key: 'BillingModeSummary',
    icon: 'cash'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'CreationDateTime',
    icon: 'calendar'
  },
  {
    type: 'computed',
    name: 'Table size',
    key: 'TableSizeBytes',
    value: '$val bytes'
  }
]
