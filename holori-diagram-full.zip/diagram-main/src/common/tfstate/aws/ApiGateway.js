export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'Name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Url',
    key: 'Url',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'API ID',
    key: 'ApiId',
    icon: 'check-circle-outline'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'CreatedDate',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'API endpoint',
    key: 'ApiEndpoint',
    icon: 'api'
  }
]
