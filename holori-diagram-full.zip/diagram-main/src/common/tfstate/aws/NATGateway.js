export default [
  {
    type: 'simple',
    name: 'ID',
    key: 'NatGatewayId',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'State'
  },
  {
    type: 'date',
    name: 'Create date',
    key: 'CreateDate',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Connection type',
    key: 'ConnectionType',
    icon: 'connection'
  },
  {
    type: 'simple',
    name: 'Allocation ID',
    key: 'NatGatewayAddresses.AllocationId',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'Network interface ID',
    key: 'NatGatewayAddresses.NetworkInterfaceId',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'Private IP',
    key: 'NatGatewayAddresses.PrivateIp',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'Private IP',
    key: 'NatGatewayAddresses.PublicIp',
    icon: 'ip'
  },
  {
    type: 'list',
    name: 'Tags',
    key: 'Tags',
    icon: 'tag'
  }
]
