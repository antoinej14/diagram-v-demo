export default [
  {
    type: 'simple',
    name: 'Instance identifier',
    key: 'DBInstanceIdentifier',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'ARN',
    key: 'DBInstanceArn',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Instance class',
    key: 'DBInstanceClass',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'DBInstanceStatus'
  },
  {
    type: 'simple',
    name: 'Availability zone',
    key: 'Availability zone',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Instance port',
    key: 'DBInstancePort',
    icon: 'check-circle-outline'
  },
  {
    type: 'simple',
    name: 'Name',
    key: 'DBName',
    icon: 'check-circle-outline'
  },
  {
    type: 'list',
    name: 'Tags',
    key: 'TagList',
    icon: 'tag'
  },
  {
    type: 'computed',
    name: 'Allocated storage',
    key: 'AllocatedStorage',
    icon: 'harddisk',
    value: '$val GB'
  },
  {
    type: 'simple',
    name: 'Backup retention period',
    key: 'BackupRetentionPeriod',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Engine',
    key: 'Engine',
    icon: 'cog'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'InstanceCreateTime',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Endpoint',
    key: 'Endpoint',
    icon: 'api'
  },
  {
    type: 'simple',
    name: 'Storage type',
    key: 'StorageType',
    icon: 'package-variant'
  },
  {
    type: 'boolean',
    name: 'Encrypted',
    key: 'StorageEncrypted',
    icon: 'lock',
    values: {
      true: 'Encrypted',
      false: 'Not encrypted'
    }
  },
  {
    type: 'simple',
    name: 'IOPS',
    key: 'Iops',
    icon: 'speedometer'
  }
]
