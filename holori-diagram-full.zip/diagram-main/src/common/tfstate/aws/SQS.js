export default [
  {
    type: 'url',
    name: 'Queue ARN',
    key: 'QueueArn',
    icon: 'earth'
  },
  {
    type: 'simple',
    name: 'Approximate number of messages',
    key: 'ApproximateNumberOfMessages',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Approximate number of delayed messages',
    key: 'ApproximateNumberOfMessagesDelayed',
    icon: 'counter'
  },
  {
    type: 'simple',
    name: 'Approximate number of not visible messages',
    key: 'ApproximateNumberOfMessagesNotVisible',
    icon: 'counter'
  },
  {
    type: 'date',
    name: 'Create date',
    key: 'CreatedTimestamp',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Maximum message size',
    key: 'MaximumMessageSize',
    icon: 'harddisk'
  },
  {
    type: 'simple',
    name: 'Message retention period',
    key: 'MessageRetentionPeriod',
    icon: 'clock'
  },
  {
    type: 'computed',
    name: 'Receive message wait time',
    key: 'ReceiveMessageWaitTimeSeconds',
    icon: 'timer',
    value: '$val s'
  },
  {
    type: 'computed',
    name: 'Delay',
    key: 'DelaySeconds',
    icon: 'timer',
    value: '$val s'
  }
]
