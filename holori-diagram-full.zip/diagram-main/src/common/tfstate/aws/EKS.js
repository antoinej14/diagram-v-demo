export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'ARN',
    key: 'arn',
    icon: 'earth'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'date',
    name: 'Creation date',
    key: 'createdAt',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'IP address',
    key: 'kubernetesNetworkConfig.serviceIpv4Cidr',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'Platform version',
    key: 'platformVersion',
    icon: 'check-circle-outline'
  }
]
