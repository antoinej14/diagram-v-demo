// Add a product here to add it to the supported list of displaying TfState.
import AWSEBS from './aws/EBS'
import AWSEC2 from './aws/EC2'
import AWSEFS from './aws/EFS'
import AWSLambda from './aws/Lambda'
import AWSLightsail from './aws/Lightsail'
import AWSS3 from './aws/S3'
import AWSAWSBatch from './aws/Batch'
import AWSDynamoDB from './aws/DynamoDB'
import AWSApiGateway from './aws/ApiGateway'
import AWSEKS from './aws/EKS'
import AWSRDS from './aws/RDS'
import AWSELB from './aws/ELB'
import AWSCloudfront from './aws/Cloudfront'
import AWSNATGateway from './aws/NATGateway'
import AWSTransitGateway from './aws/TransitGateway'
import AWSSQS from './aws/SQS'
import AWSVPNGateway from './aws/VPNGateway'
import AzureDisks from './azure/Disks.js'
import AzureVM from './azure/VM.js'
import AzureStorageBlob from './azure/StorageBlob.js'
import AzureFileShare from './azure/FileShare.js'
import AzureCacheRedis from './azure/CacheRedis.js'
import AzureServiceBus from './azure/ServiceBus.js'
import AzureStorageQueue from './azure/StorageQueue.js'
import AzureDNSZones from './azure/DNSZones.js'
import AzureKeyVaults from './azure/KeyVaults.js'
import AzureSQLServer from './azure/SQLServer.js'
import AzureStorageAccounts from './azure/StorageAccounts.js'
import AzureRelays from './azure/Relays.js'
import AzureApplicationGateways from './azure/ApplicationGateways.js'
import AzureBastions from './azure/Bastions.js'
import AzureCosmosDB from './azure/CosmosDB.js'
import AzureLoadBalancers from './azure/LoadBalancers.js'
import AzureLogAnalytics from './azure/LogAnalytics.js'
import AzureSubnet from './azure/Subnet.js'
import AzurePubsub from './azure/Pubsub.js'
import AzureVirtualNetwork from './azure/VirtualNetwork.js'
import AzureEventGrid from './azure/EventGrid.js'
import AzureCache from './azure/Cache.js'
import AzureKubernetes from './azure/Kubernetes.js'
import AzureContainerInstances from './azure/ContainerInstances.js'
import AzureApplicationGroup from './azure/ApplicationGroup.js'
import AzureHostPools from './azure/HostPools.js'
import AzureVirtualDesktop from './azure/VirtualDesktop.js'
import AzureFunction from './azure/Function.js'
import GCPWorkflow from './gcp/Workflow'
import GCPCloudSpanner from './gcp/CloudSpanner'
import GCPComputeEngine from './gcp/ComputeEngine'
import GCPMemoryStore from './gcp/MemoryStore'
import GCPFirestore from './gcp/Firestore'
import GCPDocumentAI from './gcp/DocumentAI'
import GCPDisk from './gcp/Disk'
import GCPDatastream from './gcp/Datastream'
import GCPDataproc from './gcp/Dataproc'
import GCPCloudScheduler from './gcp/CloudScheduler'
import GCPCloudRun from './gcp/CloudRun'
import GCPCloudFunctions from './gcp/CloudFunctions'
import GCPBigQuery from './gcp/BigQuery'
import GCPGCPBatch from './gcp/Batch'
import GCPAutoML from './gcp/AutoML'
import GCPArtifactRegistry from './gcp/ArtifactRegistry'
import GCPPubSub from './gcp/PubSub'
import GCPCloudFirewall from './gcp/CloudFirewall'

export default {
  'aws/Elastic-Block-Store': AWSEBS,
  'aws/EC2': AWSEC2,
  'aws/EFS': AWSEFS,
  'aws/Lambda': AWSLambda,
  'aws/Lightsail': AWSLightsail,
  'aws/Simple-Storage-Service': AWSS3,
  'aws/Batch': AWSAWSBatch,
  'aws/DynamoDB': AWSDynamoDB,
  'aws/API-Gateway': AWSApiGateway,
  'aws/EKS-Cloud': AWSEKS,
  'aws/EKS-Distro': AWSEKS,
  'aws/EKS-Anywhere': AWSEKS,
  'aws/RDS': AWSRDS,
  'aws/ELB': AWSELB,
  'aws/Cloudfront': AWSCloudfront,
  'aws/NAT-Gateway': AWSNATGateway, // Not sure about this one...
  'aws/Transit-Gateway': AWSTransitGateway,
  'aws/Simple-Queue-Service': AWSSQS,
  'aws/Site-to-Site-VPN': AWSVPNGateway,

  // Azure
  'azure/Application-Gateways': AzureApplicationGateways,
  'azure/Azure-Cosmos-DB': AzureCosmosDB,
  'azure/Azure-Service-Bus': AzureServiceBus,
  'azure/Bastions': AzureBastions,
  'azure/Blob-Block': AzureStorageBlob,
  'azure/Cache': AzureCache,
  'azure/Cache-Redis': AzureCacheRedis,
  'azure/Container-Instances': AzureContainerInstances,
  'azure/Disks': AzureDisks,
  'azure/DNS-Zones': AzureDNSZones,
  'azure/Event-Grid-Domains': AzureEventGrid,
  'azure/Event-Grid-Topics': AzureEventGrid,
  'azure/Key-Vaults': AzureKeyVaults,
  'azure/Kubernetes-Services': AzureKubernetes,
  'azure/Load-Balancers': AzureLoadBalancers,
  'azure/Log-Analytics-Workspaces': AzureLogAnalytics,
  'azure/Relays': AzureRelays,
  'azure/Subnet': AzureSubnet,
  'azure/SQL-Server': AzureSQLServer,
  'azure/SQL-Managed-Instance': AzureSQLServer,
  'azure/SQL-Elastic-Pools': AzureSQLServer,
  'azure/Storage-Accounts': AzureStorageAccounts,
  'azure/Storage-Azure-Files': AzureFileShare,
  'azure/Azure-Fileshares': AzureFileShare,
  'azure/Storage-Queue': AzureStorageQueue,
  'azure/Virtual-Machine': AzureVM,
  'azure/compute': AzureVM,
  'azure/Virtual-Networks': AzureVirtualNetwork,
  'azure/Website-Staging': AzurePubsub,
  'azure/Application-Group': AzureApplicationGroup,
  'azure/Host-Pools': AzureHostPools,
  'azure/Azure-Virtual-Desktop': AzureVirtualDesktop,
  'azure/Function-Apps': AzureFunction,
  'azure/Static-Apps': AzureFunction,
  'azure/App-Services': AzureFunction,

  // GCP
  'gcp/workflows': GCPWorkflow,
  'gcp/cloud_spanner': GCPCloudSpanner,
  'gcp/compute_engine': GCPComputeEngine,
  'gcp/memorystore': GCPMemoryStore,
  'gcp/firestore': GCPFirestore,
  'gcp/document_ai': GCPDocumentAI,
  'gcp/persistent_disk': GCPDisk,
  'gcp/datastream': GCPDatastream,
  'gcp/dataproc': GCPDataproc,
  'gcp/cloud_scheduler': GCPCloudScheduler,
  'gcp/cloud_run': GCPCloudRun,
  'gcp/cloud_functions': GCPCloudFunctions,
  'gcp/bigquery': GCPBigQuery,
  'gcp/batch': GCPGCPBatch,
  'gcp/automl': GCPAutoML,
  'gcp/artifact_registry': GCPArtifactRegistry,
  'gcp/pubsub': GCPPubSub,
  'gcp/cloud_firewall_rules': GCPCloudFirewall
}
