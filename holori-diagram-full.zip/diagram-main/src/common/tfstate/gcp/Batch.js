export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'simple',
    name: 'UID',
    key: 'uid',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Priority',
    key: 'priority',
    icon: 'priority-high'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Task groups',
    key: 'taskgroups',
    icon: 'folder-outline'
  },
  {
    type: 'array',
    name: 'Labels',
    key: 'labels',
    icon: 'tag-outline'
  }
]
