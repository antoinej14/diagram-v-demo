export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'simple',
    name: 'Dataset ID',
    key: 'dataset_id',
    icon: 'identifier'
  },
  {
    type: 'simple',
    name: 'Example count',
    key: 'example_count',
    icon: 'counter'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'create_time',
    icon: 'calendar'
  },
  {
    type: 'simple',
    name: 'Deployment state',
    key: 'deployment_state',
    icon: 'swap-vertical-bold'
  },
  {
    type: 'simple',
    name: 'Etag',
    key: 'etag',
    icon: 'tag-outline'
  },
  {
    type: 'array',
    name: 'Labels',
    key: 'labels',
    icon: 'tag-multiple-outline'
  }
]
