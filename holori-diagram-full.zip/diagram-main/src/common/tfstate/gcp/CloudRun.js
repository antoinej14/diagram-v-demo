export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value: '$val GB'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'link'
  },
  {
    type: 'simple',
    name: 'Timeout',
    key: 'template.timeout',
    icon: 'timer-outline'
  },
  {
    type: 'simple',
    name: 'Runtime',
    key: 'labels.goog-cloudfunctions-runtime',
    icon: 'cog'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Max instance count',
    key: 'scaling.maxInstanceCount',
    icon: 'counter',
    label: true
  },
  {
    type: 'section',
    name: 'Ports',
    key: 'ports',
    entries: {
      fields: [
        {
          name: 'Name',
          key: 'name'
        },
        {
          name: 'Container port',
          key: 'containerPort'
        }
      ]
    }
  }
]
