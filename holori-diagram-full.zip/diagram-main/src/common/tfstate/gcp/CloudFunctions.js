export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'link'
  },
  {
    type: 'state',
    name: 'State',
    key: 'state'
  },
  {
    type: 'simple',
    name: 'Runtime',
    key: 'runtime',
    icon: 'cog'
  },
  {
    type: 'simple',
    name: 'Trigger region',
    key: 'eventTrigger.triggerRegion',
    icon: 'map-marker'
  },
  {
    type: 'computed',
    name: 'Timeout',
    key: 'timeoutSeconds',
    icon: 'timer',
    value: '$val s'
  },
  {
    type: 'simple',
    name: 'Max instance count',
    key: 'maxInstanceCount',
    icon: 'counter'
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Ingress settings',
    key: 'ingressSettings',
    icon: 'cog'
  },
  {
    type: 'simple',
    name: 'Entry point',
    key: 'entryPoint',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Source bucket',
    key: 'source.storageSource.bucket',
    icon: 'bucket-outline'
  },
  {
    type: 'simple',
    name: 'Source object',
    key: 'source.storageSource.object',
    icon: 'harddisk'
  }
]
