export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'link'
  },
  {
    type: 'simple',
    name: 'Format',
    key: 'format',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Mode',
    key: 'mode',
    icon: 'cog'
  }
]
