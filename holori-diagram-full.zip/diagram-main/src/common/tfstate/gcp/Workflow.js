export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'link',
    value(val) {
      return 'https://google.com/' + val
    }
  },
  {
    type: 'state',
    name: 'State',
    key: 'State'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  }
]
