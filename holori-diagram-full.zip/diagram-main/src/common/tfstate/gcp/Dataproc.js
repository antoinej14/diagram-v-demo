export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'state',
    name: 'State',
    key: 'status'
  },
  {
    type: 'simple',
    name: 'Kind',
    key: 'kind',
    icon: 'help-circle-outline'
  },
  {
    type: 'computed',
    name: 'Size',
    key: 'sizeGb',
    value: '$val GB'
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'creationTimestamp',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Last attach time',
    key: 'lastAttachTimestamp',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'labels.goog-dataproc-location',
    icon: 'map-marker'
  }
]
