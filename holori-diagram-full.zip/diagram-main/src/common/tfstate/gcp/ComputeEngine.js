export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'name',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'ID',
    key: 'id',
    icon: 'identifier'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'selfLink',
    icon: 'link'
  },
  {
    type: 'simple',
    name: 'Machine type',
    key: 'machineType',
    icon: 'server'
  },
  {
    type: 'simple',
    name: 'Zone',
    key: 'zone',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'creationTimestamp',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Last start',
    key: 'lastStartTimestamp',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Network IP',
    key: 'networkIP',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'CPU platform',
    key: 'cpuPlatform',
    icon: 'chip'
  },
  {
    type: 'simple',
    name: 'Provisioning model',
    key: 'scheduling.provisioningModel',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Tags',
    key: 'tags',
    icon: 'tag-outline'
  },
  {
    type: 'section',
    name: 'Disks',
    key: 'disks',
    entries: {
      fontIcon: 'disk',
      fields: [
        {
          name: 'Type',
          key: 'type'
        },
        {
          name: 'Disk size (GB)',
          key: 'diskSizeGb'
        },
        {
          name: 'Go to console',
          key: 'source'
        }
      ]
    }
  }
]
