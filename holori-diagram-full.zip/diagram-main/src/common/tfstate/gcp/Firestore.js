export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'type',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Location ID',
    key: 'locationId',
    icon: 'map-marker'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Version retention period',
    key: 'versionRetentionPeriod',
    icon: 'clock'
  },
  {
    type: 'simple',
    name: 'Etag',
    key: 'etag',
    icon: 'tag-outline'
  }
]
