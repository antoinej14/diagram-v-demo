export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'state',
    name: 'State',
    key: 'State'
  },
  {
    type: 'simple',
    name: 'Tier',
    key: 'tier',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Redis version',
    key: 'redisVersion',
    icon: 'cached'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Location ID',
    key: 'locationId',
    icon: 'map-marker'
  },
  {
    type: 'computed',
    name: 'Memory size',
    key: 'memorySizeGb',
    icon: 'harddisk',
    value: '$val GB'
  },
  {
    type: 'simple',
    name: 'Reserved IP range',
    key: 'reservedIpRange',
    icon: 'ip'
  },
  {
    type: 'simple',
    name: 'Host',
    key: 'host',
    icon: 'server'
  },
  {
    type: 'simple',
    name: 'Port',
    key: 'port',
    icon: 'power-plug-outline'
  }
]
