export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    value(val) {
      return 'https://google.com/' + val
    }
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  }
]
