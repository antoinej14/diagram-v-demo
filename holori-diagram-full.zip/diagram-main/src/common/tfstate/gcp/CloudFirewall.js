export default [
  {
    type: 'simple',
    name: 'Kind',
    key: 'kind',
    icon: 'cog'
  },
  {
    type: 'simple',
    name: 'Identifier',
    key: 'id',
    icon: 'identifier'
  },
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'creationTimestamp',
    icon: 'calendar'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'earth',
    value(val) {
      return 'https://google.com/' + val
    }
  },
  {
    type: 'array',
    name: 'Target tags',
    key: 'targetTags',
    icon: 'tag-multiple-outline'
  },
  {
    type: 'simple',
    name: 'Direction',
    key: 'direction',
    icon: 'sign-direction'
  },
  {
    type: 'simple',
    name: 'Source ranges',
    key: 'sourceRanges.0',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Priority',
    key: 'priority',
    icon: 'priority-high'
  }
]
