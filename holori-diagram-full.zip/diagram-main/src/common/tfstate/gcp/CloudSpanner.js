export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'state',
    name: 'State',
    key: 'State'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Version Retention Period',
    key: 'versionRetentionPeriod',
    icon: 'clock'
  },
  {
    type: 'simple',
    name: 'Encryption info',
    key: 'encryptionInfo',
    icon: 'lock'
  },
  {
    type: 'simple',
    name: 'Database dialect',
    key: 'databaseDialect',
    icon: 'database'
  }
]
