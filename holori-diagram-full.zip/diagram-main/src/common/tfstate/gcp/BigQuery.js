export default [
  {
    type: 'simple',
    name: 'Name',
    key: 'friendlyName',
    icon: 'information-outline'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'name',
    icon: 'link'
  },
  {
    type: 'simple',
    name: 'Location',
    key: 'location',
    icon: 'map-marker'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Description',
    key: 'description',
    icon: 'text-box-outline'
  },
  {
    type: 'simple',
    name: 'Etag',
    key: 'etag',
    icon: 'tag-outline'
  },
  {
    type: 'boolean',
    name: 'Use legacy SQL',
    key: 'view_use_legacy_sql',
    values: {
      true: 'Yes',
      false: 'No'
    }
  },
  {
    type: 'simple',
    name: 'Query',
    key: 'view_query',
    icon: 'database-search-outline'
  },
  {
    type: 'simple',
    name: 'Materialized view',
    key: 'materializedView',
    icon: 'information-outline'
  },
  {
    type: 'simple',
    name: 'Snapshot definition',
    key: 'snapshotDefinition',
    icon: 'monitor-screenshot'
  }
]
