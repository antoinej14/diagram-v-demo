export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'simple',
    name: 'ID',
    key: 'id',
    icon: 'identifier'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'url',
    name: 'Go to console',
    key: 'selfLink',
    icon: 'link'
  },
  {
    type: 'simple',
    name: 'Kind',
    key: 'kind',
    icon: 'help-circle-outline'
  },
  {
    type: 'simple',
    name: 'Type',
    key: 'type',
    icon: 'help-circle-outline'
  },
  {
    type: 'computed',
    name: 'Size',
    key: 'sizeGb',
    icon: 'harddisk',
    value: '$val GB'
  },
  {
    type: 'date',
    name: 'Creation time',
    key: 'creationTimestamp',
    icon: 'calendar',
    label: true
  }
]
