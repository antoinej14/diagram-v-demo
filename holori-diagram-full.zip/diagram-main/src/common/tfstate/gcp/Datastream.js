export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    icon: 'information-outline',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'state',
    name: 'State',
    key: 'state'
  },
  {
    type: 'date',
    name: 'Create time',
    key: 'createTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Update time',
    key: 'updateTime',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Source config',
    key: 'sourceConfig',
    icon: 'cog'
  },
  {
    type: 'simple',
    name: 'Destination config',
    key: 'destinationConfig',
    icon: 'cog'
  }
]
