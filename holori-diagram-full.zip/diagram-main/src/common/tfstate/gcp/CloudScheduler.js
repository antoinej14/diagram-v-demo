export default [
  {
    type: 'computed',
    name: 'Name',
    key: 'name',
    value(val, tf) {
      return val || tf.displayName
    }
  },
  {
    type: 'simple',
    name: 'State',
    key: 'state',
    icon: 'help-circle-outline'
  },
  {
    type: 'state',
    name: 'Status',
    key: 'status'
  },
  {
    type: 'date',
    name: 'Schedule time',
    key: 'schedule_time',
    icon: 'calendar',
    label: true
  },
  {
    type: 'date',
    name: 'Last attempt time',
    key: 'last_attempt_time',
    icon: 'calendar',
    label: true
  },
  {
    type: 'simple',
    name: 'Retry config',
    key: 'retry_config',
    icon: 'cog'
  },
  {
    type: 'simple',
    name: 'Attempt deadline',
    key: 'attempt_deadline',
    icon: 'octagon-outline'
  }
]
