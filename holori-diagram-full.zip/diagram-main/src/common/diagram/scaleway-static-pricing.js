/**
 * Hand-curated snapshot of Scaleway's public list prices, in EUR.
 *
 * Why static instead of a live API call:
 * - The existing per-node "Estimated pricing" panel (ScalewayPricing.vue) calls a
 *   third-party crawled catalog (Supabase) that only covers Compute Instances and
 *   reports prices in USD. For a demo in front of the European Commission about EU
 *   sovereign cloud, showing "$" is an unforced error, and depending on a live
 *   third-party API (venue wifi, CORS, rate limits, catalog drift) is an avoidable
 *   risk right before presenting.
 * - Scaleway does publish an official, unauthenticated Product Catalog API
 *   (GET https://api.scaleway.com/product-catalog/v2alpha1/public-catalog/products)
 *   that covers far more of the catalog and reports EUR. It's the right long-term
 *   source, but calling it live from the browser has one open question (whether it
 *   sends CORS headers) that couldn't be verified from this environment. Rather than
 *   bet the demo on an unverified live call, the numbers below were read directly off
 *   Scaleway's own pricing pages and hard-coded.
 *
 * Coverage & freshness:
 * - Source: scaleway.com/en/pricing/{virtual-instances,managed-databases,network,storage}
 * - Snapshot date: 2026-09-16. Scaleway revises prices occasionally (they did in 2022
 *   and again in 2026) — re-check the source pages before relying on this for anything
 *   beyond a demo, and prefer wiring up the real API once its CORS behaviour is confirmed.
 * - Prices are list/on-demand hourly rates and do not vary by region for compute
 *   (Scaleway, unlike AWS, prices its zones uniformly), so `region` on a node is kept
 *   for display only and never affects the matched price here.
 */

export const PRICING_SNAPSHOT_DATE = '2026-09-16'
export const PRICING_CURRENCY = 'EUR'

// --- Compute instances (€/hour) ------------------------------------------------
// Source: https://www.scaleway.com/en/pricing/virtual-instances/
export const COMPUTE_INSTANCES = [
  // Development
  { type: 'STARDUST1-S', vcpu: 1, ramGb: 1, hourlyEur: 0.0006 },
  { type: 'DEV1-S', vcpu: 2, ramGb: 2, hourlyEur: 0.00898 },
  { type: 'DEV1-M', vcpu: 3, ramGb: 4, hourlyEur: 0.0202 },
  { type: 'DEV1-L', vcpu: 4, ramGb: 8, hourlyEur: 0.04284 },
  { type: 'DEV1-XL', vcpu: 4, ramGb: 12, hourlyEur: 0.06508 },
  { type: 'PLAY2-PICO', vcpu: 1, ramGb: 2, hourlyEur: 0.01428 },
  { type: 'PLAY2-NANO', vcpu: 2, ramGb: 4, hourlyEur: 0.02754 },
  { type: 'PLAY2-MICRO', vcpu: 4, ramGb: 8, hourlyEur: 0.05508 },
  // General purpose - GP1 (legacy) / PRO2
  { type: 'GP1-XS', vcpu: 4, ramGb: 16, hourlyEur: 0.09282 },
  { type: 'GP1-S', vcpu: 8, ramGb: 32, hourlyEur: 0.19074 },
  { type: 'GP1-M', vcpu: 16, ramGb: 64, hourlyEur: 0.38352 },
  { type: 'GP1-L', vcpu: 32, ramGb: 128, hourlyEur: 0.77418 },
  { type: 'GP1-XL', vcpu: 48, ramGb: 256, hourlyEur: 1.67382 },
  { type: 'PRO2-XXS', vcpu: 2, ramGb: 8, hourlyEur: 0.0561 },
  { type: 'PRO2-XS', vcpu: 4, ramGb: 16, hourlyEur: 0.1122 },
  { type: 'PRO2-S', vcpu: 8, ramGb: 32, hourlyEur: 0.22338 },
  { type: 'PRO2-M', vcpu: 16, ramGb: 64, hourlyEur: 0.44676 },
  { type: 'PRO2-L', vcpu: 32, ramGb: 128, hourlyEur: 0.89454 },
  // General purpose - POP2
  { type: 'POP2-2C-8G', vcpu: 2, ramGb: 8, hourlyEur: 0.0735 },
  { type: 'POP2-4C-16G', vcpu: 4, ramGb: 16, hourlyEur: 0.147 },
  { type: 'POP2-6C-24G', vcpu: 6, ramGb: 24, hourlyEur: 0.2205 },
  { type: 'POP2-8C-32G', vcpu: 8, ramGb: 32, hourlyEur: 0.29 },
  { type: 'POP2-12C-48G', vcpu: 12, ramGb: 48, hourlyEur: 0.435 },
  { type: 'POP2-16C-64G', vcpu: 16, ramGb: 64, hourlyEur: 0.59 },
  { type: 'POP2-24C-96G', vcpu: 24, ramGb: 96, hourlyEur: 0.885 },
  { type: 'POP2-32C-128G', vcpu: 32, ramGb: 128, hourlyEur: 1.18 },
  { type: 'POP2-48C-192G', vcpu: 48, ramGb: 192, hourlyEur: 1.77 },
  { type: 'POP2-64C-256G', vcpu: 64, ramGb: 256, hourlyEur: 2.35 },
  // General purpose - BASIC2 / BASIC3 / STANDARD2 / STANDARD3
  { type: 'BASIC2-A2C-4G', vcpu: 2, ramGb: 4, hourlyEur: 0.023 },
  { type: 'BASIC2-A2C-8G', vcpu: 2, ramGb: 8, hourlyEur: 0.0345 },
  { type: 'BASIC2-A4C-8G', vcpu: 4, ramGb: 8, hourlyEur: 0.0517 },
  { type: 'BASIC2-A4C-16G', vcpu: 4, ramGb: 16, hourlyEur: 0.0689 },
  { type: 'BASIC3-X2C-4G', vcpu: 2, ramGb: 4, hourlyEur: 0.03945 },
  { type: 'BASIC3-X2C-8G', vcpu: 2, ramGb: 8, hourlyEur: 0.05923 },
  { type: 'BASIC3-X4C-8G', vcpu: 4, ramGb: 8, hourlyEur: 0.079 },
  { type: 'BASIC3-X4C-16G', vcpu: 4, ramGb: 16, hourlyEur: 0.11845 },
  { type: 'STANDARD2-A2C-8G', vcpu: 2, ramGb: 8, hourlyEur: 0.0586 },
  { type: 'STANDARD2-A4C-16G', vcpu: 4, ramGb: 16, hourlyEur: 0.1171 },
  { type: 'STANDARD3-X2C-8G', vcpu: 2, ramGb: 8, hourlyEur: 0.0809 },
  { type: 'STANDARD3-X4C-16G', vcpu: 4, ramGb: 16, hourlyEur: 0.1617 },
  { type: 'STANDARD3-X6C-24G', vcpu: 6, ramGb: 24, hourlyEur: 0.2345 },
  { type: 'STANDARD3-X8C-32G', vcpu: 8, ramGb: 32, hourlyEur: 0.319 },
  // Compute optimized
  { type: 'COMPUTE3-X2C-4G', vcpu: 2, ramGb: 4, hourlyEur: 0.0585 },
  { type: 'COMPUTE3-X4C-8G', vcpu: 4, ramGb: 8, hourlyEur: 0.117 },
  { type: 'COMPUTE3-X8C-16G', vcpu: 8, ramGb: 16, hourlyEur: 0.2341 },
  { type: 'POP2-HC-2C-4G', vcpu: 2, ramGb: 4, hourlyEur: 0.0532 },
  { type: 'POP2-HC-4C-8G', vcpu: 4, ramGb: 8, hourlyEur: 0.1064 },
  // Memory optimized
  { type: 'MEMORY3-X2C-16G', vcpu: 2, ramGb: 16, hourlyEur: 0.1133 },
  { type: 'MEMORY3-X4C-32G', vcpu: 4, ramGb: 32, hourlyEur: 0.2266 },
  { type: 'POP2-HM-2C-16G', vcpu: 2, ramGb: 16, hourlyEur: 0.103 },
  { type: 'POP2-HM-4C-32G', vcpu: 4, ramGb: 32, hourlyEur: 0.206 },
  // Network optimized
  { type: 'POP2-HN-3', vcpu: 3, ramGb: 4, hourlyEur: 0.2554 },
  { type: 'POP2-HN-5', vcpu: 5, ramGb: 8, hourlyEur: 0.4524 }
]

// Sensible default when a node has no instance type chosen yet. Deliberately NOT
// "cheapest of the whole list" (that would be STARDUST1-S, a dev-only/near-free SKU
// that would make a default estimate look like a rounding error). DEV1-S is
// Scaleway's own smallest general-purpose recommendation.
export const DEFAULT_COMPUTE_INSTANCE_TYPE = 'DEV1-S'

// --- Managed Database (€/hour, cost-optimized "DB-*" range) --------------------
// Source: https://www.scaleway.com/en/pricing/managed-databases/ (Paris region)
// Note: no per-node "pick a size" UI exists yet for database nodes on the diagram
// (unlike compute instances), so every Managed Database node is priced against the
// single DEFAULT_DATABASE_NODE_TYPE below and flagged as an estimate.
export const MANAGED_DATABASE_NODES = [
  { type: 'DB-DEV-S', vcpu: 2, ramGb: 2, hourlyEur: 0.0156 },
  { type: 'DB-DEV-M', vcpu: 3, ramGb: 4, hourlyEur: 0.0382 },
  { type: 'DB-DEV-L', vcpu: 4, ramGb: 8, hourlyEur: 0.0756 },
  { type: 'DB-DEV-XL', vcpu: 4, ramGb: 12, hourlyEur: 0.1129 },
  { type: 'DB-GP-XS', vcpu: 4, ramGb: 16, hourlyEur: 0.1906 },
  { type: 'DB-GP-S', vcpu: 8, ramGb: 32, hourlyEur: 0.3803 },
  { type: 'DB-GP-M', vcpu: 16, ramGb: 64, hourlyEur: 0.7595 },
  { type: 'DB-GP-L', vcpu: 32, ramGb: 128, hourlyEur: 1.2569 },
  { type: 'DB-GP-XL', vcpu: 48, ramGb: 256, hourlyEur: 2.55 },
  { type: 'DB-PRO2-XXS', vcpu: 2, ramGb: 8, hourlyEur: 0.11 },
  { type: 'DB-PRO2-XS', vcpu: 4, ramGb: 16, hourlyEur: 0.22 },
  { type: 'DB-PRO2-S', vcpu: 8, ramGb: 32, hourlyEur: 0.438 },
  { type: 'DB-PRO2-M', vcpu: 16, ramGb: 64, hourlyEur: 0.876 },
  { type: 'DB-PRO2-L', vcpu: 32, ramGb: 128, hourlyEur: 1.64 }
]

export const DEFAULT_DATABASE_NODE_TYPE = 'DB-DEV-S'

// --- Load Balancer (€/hour, flat rate incl. bandwidth) -------------------------
// Source: https://www.scaleway.com/en/pricing/network/
export const LOAD_BALANCERS = [
  { type: 'LB-S', bandwidth: '200 Mbps', hourlyEur: 0.023 },
  { type: 'LB-GP-M', bandwidth: '500 Mbps', hourlyEur: 0.054 },
  { type: 'LB-GP-L', bandwidth: '1 Gbps', hourlyEur: 0.094 },
  { type: 'LB-GP-XL', bandwidth: '4 Gbps', hourlyEur: 0.941 }
]

export const DEFAULT_LOAD_BALANCER_TYPE = 'LB-S'

// --- Object Storage & Block Storage (usage-based, no fixed node to price) ------
// Source: https://www.scaleway.com/en/pricing/storage/
// These are genuinely usage-based (billed per GB actually stored/transferred), and
// the diagram doesn't currently capture a size for these nodes, so they are reported
// as a RATE (for transparency that the product is "covered") rather than folded into
// a fabricated euro total.
export const OBJECT_STORAGE_TIERS = [
  { tier: 'Standard Multi-AZ', monthlyPerGbEur: 0.01606 },
  { tier: 'Standard One Zone', monthlyPerGbEur: 0.00803 },
  { tier: 'Glacier', monthlyPerGbEur: 0.00254 }
]

export const BLOCK_STORAGE_TIERS = [
  { tier: 'Block Storage 5k IOPS', hourlyPerGbEur: 0.00013 },
  { tier: 'Block Storage 15k IOPS', hourlyPerGbEur: 0.000177 }
]

export const HOURS_PER_MONTH = 730
