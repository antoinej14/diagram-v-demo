import { format } from '@joint/plus'
import { Base64 } from 'js-base64'
import { useMixins } from '@/common/mixins.js'
import { debounce, downloadFile } from '@/common/utils.js'

/**
 * TODO
 * @param {*} obj
 * @returns
 */
export const lowercaseKeys = (obj) => {
  const entries = Object.entries(obj)

  return Object.fromEntries(
    entries.map(([key, value]) => {
      return [key.toLowerCase(), typeof value === 'object' ? lowercaseKeys(value) : value]
    })
  )
}

/**
 * TODO
 * @param {*} price
 * @param {*} currency
 * @returns
 */
export function formatPrice(price, currency = 'USD') {
  const formatter = new Intl.NumberFormat(undefined, {
    style: 'currency',
    currencyDisplay: 'narrowSymbol',
    maximumSignificantDigits: 4,
    maximumFractionDigits: 4,
    currency
  })
  return formatter.format(price)
}

/**
 * TODO
 * @param {*} svg
 * @param {*} fileFormat
 * @param {*} finish
 * @param {*} addWhiteBackground
 * @param {*} customDimensions
 */
export function exportToRaster(
  svg,
  fileFormat,
  finish,
  addWhiteBackground = false,
  customDimensions = null
) {
  let width, height
  if (!customDimensions) {
    const area = window.paper.getContentArea()
    width = area.width
    height = area.height
  } else {
    width = customDimensions.width
    height = customDimensions.height
  }
  const img = new Image()
  img.width = width
  img.height = height
  img.onload = () => {
    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height

    const ctx = canvas.getContext('2d')

    if (addWhiteBackground) {
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, 0, width, height)
    }

    ctx.drawImage(img, 0, 0, width, height)

    const canvasData = canvas.toDataURL(fileFormat)
    finish(canvasData)
  }
  img.setAttribute('crossOrigin', 'Anonymous')
  img.src = `data:image/svg+xml;base64,${Base64.encode(svg)}`
}

/**
 * TODO
 */
export const exportDiagramImage = debounce(
  (whiteBackground, fileFormat, filenameOrCallback, cb, displayToast = true) => {
    const { toast, closeAllToasts } = useMixins()

    if (displayToast) {
      toast({
        variant: 'info',
        infinite: true,
        message:
          'Your image is being generated.<br>Once it is ready, you will be prompted to download it.',
        position: 'top-right'
      })
    }

    const finish = (blob) => {
      if (displayToast) {
        closeAllToasts()
      }

      if (typeof filenameOrCallback === 'string') {
        downloadFile(blob, filenameOrCallback, fileFormat)
      } else {
        filenameOrCallback(blob)
      }

      if (typeof cb === 'function') {
        cb()
      }
    }

    format.toSVG(
      window.paper,
      (svg) => {
        if (fileFormat !== 'image/svg') {
          exportToRaster(svg, fileFormat, finish, whiteBackground)
        } else {
          finish(svg)
        }
      },
      {
        backgroundColor: whiteBackground ? '#ffffff' : 'transparent',
        useComputedStyles: false,
        convertImagesToDataUris: true,
        padding: 30,
        preserveDimensions: true
      }
    )
  },
  100
)

/**
 * TODO
 * @param {*} paper
 * @returns
 */
export function generateThumbnail(paper = window.paper) {
  return new Promise((resolve) => {
    format.toJPEG(
      paper,
      (dataURI) => {
        resolve(dataURI)
      },
      {
        width: 200,
        height: 130,
        quality: 0.8,
        padding: 10,
        useComputedStyles: false
      }
    )
  })
}
