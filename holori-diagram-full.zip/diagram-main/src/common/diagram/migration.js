import migration0 from './migrations/migration-0-1'

/**
 * Currently supported version of the diagram data format
 */
export const MIGRATION_VERSION = 2

/**
 * TODO
 * @param {*} version
 * @returns
 */
export const needsMigration = (version) => version < MIGRATION_VERSION

/**
 * TODO
 *
 * @param {*} data
 * @param {*} progress
 */
export const migrate = (data, progress) => {
  if (!needsMigration(data.version)) {
    // this diagram does not need any migration
    return
  }

  // migration runner
  const playMigration = (migration, targetVersion) => {
    const updateProgress = (max, counter) => {
      progress.max = max
      progress.value = counter

      if (counter >= max) {
        data.version = targetVersion
      }
    }

    migration0(data, updateProgress)
  }

  switch (data.version) {
    case 0:
      playMigration(migration0, 1)
  }
}
