/**
 * Cost estimate for a diagram, matched against a static snapshot of Scaleway's
 * public EUR list prices (see scaleway-static-pricing.js for the numbers and why
 * they're hard-coded rather than fetched live).
 *
 * Every node ends up in exactly one of four states:
 *  - "priced":       exact SKU chosen by the user, contributes a real euro amount.
 *  - "estimated":    no SKU chosen (or product has no picker yet), we used a fixed
 *                     default SKU as a placeholder. Contributes a euro amount, but
 *                     flagged so it's never mistaken for a deliberate choice.
 *  - "rate-only":     usage-based product (storage) where we know the €/GB rate but
 *                     the diagram doesn't capture a quantity yet. Shown separately,
 *                     never folded into the total (that would be a fabricated number).
 *  - "unsupported":   anything this snapshot doesn't cover at all (other providers,
 *                     or other Scaleway products not listed below).
 */

import {
  COMPUTE_INSTANCES,
  DEFAULT_COMPUTE_INSTANCE_TYPE,
  MANAGED_DATABASE_NODES,
  DEFAULT_DATABASE_NODE_TYPE,
  LOAD_BALANCERS,
  DEFAULT_LOAD_BALANCER_TYPE,
  OBJECT_STORAGE_TIERS,
  BLOCK_STORAGE_TIERS,
  HOURS_PER_MONTH,
  PRICING_CURRENCY
} from './scaleway-static-pricing.js'

export { PRICING_CURRENCY }

// Kept for backward compatibility with existing per-node code (Details.vue) that
// checks `path?.startsWith(SCALEWAY_INSTANCE_PATH)`.
export const SCALEWAY_INSTANCE_PATH = '/scaleway/Compute/Instance'

function bySku(catalog, type) {
  return catalog.find((row) => row.type === type) || null
}

function skuResult(row, { estimated, unitLabel }) {
  if (!row) return null
  return {
    priced: true,
    status: estimated ? 'estimated' : 'priced',
    estimated,
    instanceType: row.type,
    vcpu: row.vcpu,
    memory: row.ramGb,
    hourlyPriceEur: row.hourlyEur,
    monthlyPriceEur: row.hourlyEur * HOURS_PER_MONTH,
    unitLabel: unitLabel || 'node'
  }
}

function rateOnlyResult(rateEur, unitLabel, tierLabel) {
  return {
    priced: false,
    status: 'rate-only',
    reason: 'usage-based',
    rateEur,
    unitLabel,
    tierLabel
  }
}

function unsupportedResult() {
  return { priced: false, status: 'unsupported', reason: 'unsupported' }
}

/**
 * Product matchers, in priority order. `prefix` is matched against node.path with
 * startsWith — first match wins, so more specific prefixes must come first when
 * they share a stem (Compute/Instance vs Compute/Block-storage don't collide, but
 * keep this in mind if new icon paths are added).
 */
function matchComputeInstance(node) {
  if (!node.path?.startsWith('/scaleway/Compute/Instance')) return null

  const chosen = node.scalewayInstanceType ? bySku(COMPUTE_INSTANCES, node.scalewayInstanceType) : null
  if (chosen) return skuResult(chosen, { estimated: false, unitLabel: 'instance' })

  const fallback = bySku(COMPUTE_INSTANCES, DEFAULT_COMPUTE_INSTANCE_TYPE)
  return skuResult(fallback, { estimated: true, unitLabel: 'instance' })
}

function matchBlockStorage(node) {
  if (!node.path?.startsWith('/scaleway/Compute/Block-storage')) return null
  const tier = BLOCK_STORAGE_TIERS[0] // "5k IOPS", the entry-level tier, as a reference rate
  return rateOnlyResult(tier.hourlyPerGbEur, '€/GB/hour', tier.tier)
}

function matchObjectStorage(node) {
  if (node.path?.startsWith('/scaleway/Storage/Cold-storage')) {
    const tier = OBJECT_STORAGE_TIERS.find((t) => t.tier === 'Glacier')
    return rateOnlyResult(tier.monthlyPerGbEur, '€/GB/month', tier.tier)
  }
  if (node.path?.startsWith('/scaleway/Storage/Object-storage')) {
    const tier = OBJECT_STORAGE_TIERS.find((t) => t.tier === 'Standard Multi-AZ')
    return rateOnlyResult(tier.monthlyPerGbEur, '€/GB/month', tier.tier)
  }
  return null
}

function matchLoadBalancer(node) {
  if (!node.path?.startsWith('/scaleway/Network/Load-balancers')) return null
  // No per-node size picker exists yet for load balancers, so this is always the
  // default tier, always flagged as an estimate.
  const row = bySku(LOAD_BALANCERS, DEFAULT_LOAD_BALANCER_TYPE)
  return skuResult(row, { estimated: true, unitLabel: 'load balancer' })
}

function matchManagedDatabase(node) {
  if (!node.path?.startsWith('/scaleway/Managed-Databases/')) return null
  // Same story as load balancers: no per-node engine/size picker yet, so every
  // database node (including Redis-for-cache, which isn't priced separately here)
  // is estimated against one reference node type.
  const row = bySku(MANAGED_DATABASE_NODES, DEFAULT_DATABASE_NODE_TYPE)
  return skuResult(row, { estimated: true, unitLabel: 'database node' })
}

const MATCHERS = [
  matchComputeInstance,
  matchBlockStorage,
  matchObjectStorage,
  matchLoadBalancer,
  matchManagedDatabase
]

/**
 * @param {Object} node Raw diagram node (diagramStore.getNodes entry).
 */
export function isScalewayInstanceNode(node) {
  return Boolean(node?.path?.startsWith(SCALEWAY_INSTANCE_PATH))
}

/**
 * Estimates a single node's cost. See module doc for the four possible states.
 */
export function estimateNodeCost(node) {
  if (!node?.path) return unsupportedResult()

  for (const matcher of MATCHERS) {
    const result = matcher(node)
    if (result) return result
  }

  return unsupportedResult()
}

/**
 * Estimates the cost of a whole diagram.
 *
 * @param {Array} nodes diagramStore.getNodes (or equivalent node attribute list)
 */
export function estimateDiagramCost(nodes) {
  const items = (nodes || []).map((node) => ({
    id: node.id,
    name: node.name,
    path: node.path,
    ...estimateNodeCost(node)
  }))

  const totals = items.reduce(
    (acc, item) => {
      acc.totalNodes += 1
      if (item.status === 'priced' || item.status === 'estimated') {
        acc.pricedCount += 1
        acc.monthlyPriceEur += item.monthlyPriceEur || 0
        acc.hourlyPriceEur += item.hourlyPriceEur || 0
        if (item.status === 'estimated') acc.estimatedCount += 1
      } else if (item.status === 'rate-only') {
        acc.rateOnlyCount += 1
      } else {
        acc.unsupportedCount += 1
      }
      return acc
    },
    {
      totalNodes: 0,
      pricedCount: 0,
      estimatedCount: 0,
      rateOnlyCount: 0,
      unsupportedCount: 0,
      monthlyPriceEur: 0,
      hourlyPriceEur: 0
    }
  )

  return { items, totals }
}
