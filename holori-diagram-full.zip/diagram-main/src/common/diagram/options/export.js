export const getScaledWatermarkSize = (diagramImage, watermarkImage) => {
  const ratio = diagramImage.width / 2 / watermarkImage.width

  return {
    width: watermarkImage.width * ratio,
    height: watermarkImage.height * ratio
  }
}

export const exportImage = (image, watermark = null) => {
  const dataPart = 'data:image/svg+xml;charset=utf8,'
  const svg = decodeURIComponent(image.replace(dataPart, ''))
  const div = document.createElement('div')
  div.innerHTML = svg
  const svgTag = div.querySelector('svg')

  // Process to fix the edges.
  const markers = Array.from(svgTag.querySelectorAll('marker'))
  markers.forEach((marker) => {
    marker.setAttribute('viewBox', '0 0 10 10')
    marker.setAttribute('refX', 5)
    marker.setAttribute('refY', 5)
    marker.setAttribute('markerWidth', 6)
    marker.setAttribute('markerHeight', 6)

    const path = marker.querySelector('path')
    path.setAttribute('fill', path.getAttribute('stroke'))
    // This `d` attribute comes from this page:
    // https://developer.mozilla.org/en-US/docs/Web/SVG/Element/marker
    path.setAttribute('d', 'M 0 0 L 10 5 L 0 10 z')
  })

  const circles = Array.from(svgTag.querySelectorAll('circle'))
  circles.forEach((circle) => {
    circle.parentNode.removeChild(circle)
  })

  const texts = [
    ...Array.from(svgTag.querySelectorAll('text[alignment-baseline="central"]')),
    ...Array.from(svgTag.querySelectorAll('text[dominant-baseline="central"]'))
  ]

  texts.forEach((text) => {
    const content = text.innerHTML

    // Label is empty, remove both the text node and the previous path.
    if (content === '') {
      const parentNode = text.parentNode
      parentNode.removeChild(text.previousSibling)
      parentNode.removeChild(text)
    }
  })

  const shadows = svgTag.querySelectorAll(
    'feDropShadow[flood-color]:not([flood-color="transparent"])'
  )

  shadows.forEach((shadow) => {
    shadow.setAttribute('stdDeviation', '10')
  })

  const makeResult = () => `${dataPart}${encodeURIComponent(svgTag.outerHTML)}`

  if (!watermark) {
    return makeResult()
  }

  const diagramWidth = svgTag.width.baseVal.value
  const diagramHeight = svgTag.height.baseVal.value
  const watermarkImage = document.createElement('image')

  const watermarkData = `data:image/svg+xml;base64,${btoa(watermark)}`
  const { width, height } = getScaledWatermarkSize(
    {
      width: diagramWidth,
      height: diagramHeight
    },
    {
      width: 1700,
      height: 330
    }
  )

  watermarkImage.setAttribute('href', watermarkData)
  watermarkImage.setAttribute('x', diagramWidth / 2 - width / 2)
  watermarkImage.setAttribute('y', diagramHeight / 2 - height / 2)
  watermarkImage.setAttribute('width', width)
  watermarkImage.setAttribute('height', height)
  svgTag.appendChild(watermarkImage)
  return makeResult()
}
