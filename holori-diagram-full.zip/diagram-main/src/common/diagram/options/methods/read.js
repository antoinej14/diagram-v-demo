import g6ToJoint from './g6-to-joint'
import exportData from './export'

export default (json, graph, paper, linkToolsView) => {
  const allItems = [
    ...json.groups.map((group) => ({
      ...group,
      type: group.type || 'Group'
    })),
    ...json.nodes.map((node) => ({
      ...node,
      type: !node.type || node.type === 'custom' ? 'Node' : node.type
    }))
  ]
  const items = {}

  for (const item of allItems) {
    items[item.id] = item
  }

  let maxZ = 1
  let isZero = false

  const addZ = () => {
    for (let i = 0; i < allItems.length; i++) {
      const item = allItems[i]
      const { id, parent } = item

      if (!parent) {
        item.z = 1
        items[id] = item
        continue
      }

      item.z = !items[parent].z ? 0 : items[parent].z + 1
      items[id] = item
      allItems[i] = item

      if (!item.z) {
        isZero = true
      }

      maxZ = Math.max(maxZ, item.z)
    }
  }

  do {
    isZero = false
    addZ()
  } while (isZero)

  const data = g6ToJoint({
    groups: allItems.filter(({ type }) => type === 'Group'),
    nodes: allItems.filter(({ type }) => type === 'Node' || type === 'TextBox'),
    edges: json.edges.map((edge) => ({
      ...edge,
      z: maxZ
    }))
  })

  graph.fromJSON(data)

  if (linkToolsView) {
    data.cells
      .filter((cell) => cell.type === 'Edge')
      .forEach((edge) => {
        const cellView = graph.getCell(edge.id).findView(paper)
        cellView.addTools(linkToolsView)
      })
  }

  return exportData(data.cells)
}
