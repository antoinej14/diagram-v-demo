import readG6Diagram from './read'
import highlighters from '../shapes/highlighters'

export const compareTwoDiagrams = (diagram, compareTo, graph, paper, addUpdatedTerraformKey) => {
  const hasItem = (id, type, from) => from[type].findIndex((item) => item.id === id) !== -1
  const findById = (id, where) => where.nodes.find((node) => node.id === id)

  const added = {
    nodes: [],
    edges: [],
    groups: []
  }
  const removed = {
    nodes: [],
    edges: [],
    groups: []
  }
  const unchanged = {
    nodes: [],
    edges: [],
    groups: []
  }
  const updated = {
    nodes: [],
    groups: []
  }

  const compareObj = (valueBefore, valueAfter, item, type, key) => {
    Object.keys(valueBefore).forEach((subkey) => {
      let valBefore = valueBefore[subkey]
      let valAfter = valueAfter[subkey]

      // Compare two strings and not two objects
      if (typeof valueBefore[subkey] === 'object') {
        valBefore = JSON.stringify(valBefore)
        valAfter = JSON.stringify(valAfter)
      }

      if (valBefore !== valAfter) {
        updated[type].push({
          ...item,
          updated: true
        })
        if (typeof addUpdatedTerraformKey === 'function') {
          addUpdatedTerraformKey({
            id: item.id,
            key: `${key}/${subkey}`,
            value: valueBefore[subkey]
          })
        }
      } else {
        unchanged[type].push(item)
      }
    })
  }

  const types = ['groups', 'nodes', 'edges']

  types.forEach((type) => {
    // Check for added
    const fromDiagram = diagram[type] || []
    fromDiagram.forEach((item) => {
      // Skip placeholder
      if (item.type === 'text-box' && item.notes === 'empty') {
        return
      }

      const unchange = () => unchanged[type].push(item)

      if (!hasItem(item.id, type, compareTo)) {
        added[type].push({
          ...item,
          added: true
        })
      } else {
        if (type === 'nodes' || type === 'groups') {
          const before = findById(item.id, compareTo)
          const after = findById(item.id, diagram)

          if (before !== undefined && after !== undefined) {
            const beforeTerraform = before.terraform
            const afterTerraform = after.terraform

            if (beforeTerraform && afterTerraform) {
              const keys = Object.keys(afterTerraform)
              if (keys.length) {
                keys.forEach((key) => {
                  const valueBefore = beforeTerraform[key]
                  const valueAfter = afterTerraform[key]

                  if (typeof valueBefore === 'object') {
                    compareObj(valueBefore, valueAfter, item, type, key)
                  } else {
                    if (valueBefore !== valueAfter) {
                      updated[type].push({
                        ...item,
                        updated: true
                      })
                      if (typeof addUpdatedTerraformKey === 'function') {
                        addUpdatedTerraformKey({
                          id: item.id,
                          key,
                          value: valueBefore
                        })
                      }
                    } else {
                      unchange()
                    }
                  }
                })
              } else {
                unchange()
              }
            } else {
              unchange()
            }
          } else {
            unchange()
          }
        } else {
          unchange()
        }
      }
    })

    const fromCompare = compareTo[type] || []

    fromCompare.forEach((item) => {
      // Skip placeholder
      if (item.type === 'text-box' && item.notes === 'empty') {
        return
      }

      if (!hasItem(item.id, type, diagram)) {
        removed[type].push({
          ...item,
          removed: true
        })
      }
    })
  })

  const newEdges = Array.prototype.concat([], added.edges, removed.edges, unchanged.edges)
  const newNodes = Array.prototype.concat(
    [],
    added.nodes,
    removed.nodes,
    unchanged.nodes,
    updated.nodes
  )
  const newGroups = Array.prototype.concat(
    [],
    added.groups,
    removed.groups,
    unchanged.groups,
    updated.groups
  )

  const data = {
    edges: Array.from(new Set(newEdges)),
    nodes: Array.from(new Set(newNodes)),
    groups: Array.from(new Set(newGroups))
  }

  readG6Diagram(data, graph, paper)

  const states = {
    added: [...added.edges, ...added.groups, ...added.nodes],
    updated: [...updated.groups, ...updated.nodes],
    removed: [...removed.edges, ...removed.groups, ...removed.nodes]
  }

  const highlight = () => {
    for (const state in states) {
      const items = states[state]

      for (const item of items) {
        const element = graph.getCell(item.id)
        if (element) {
          element.set(state, true)
          element.findView(paper).highlight(null, {
            highlighter: highlighters[state]
          })
        }
      }
    }
  }

  return { data, highlight }
}
