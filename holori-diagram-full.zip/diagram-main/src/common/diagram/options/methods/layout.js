import { shapes, layout } from '@joint/plus'
import exportData from './export'

export const defaultMargin = 50

export const resizeGroup = (group) => {
  group.fitToChildren({ padding: 50 })
}

export const toFront = (element, graph, paper) => {
  element.model.toFront()
  for (const cell of element.model.getEmbeddedCells()) {
    toFront(cell.findView(paper), graph, paper)
  }
  for (const link of graph.getLinks()) {
    link.toFront()
  }
}

// --- Noise filtering ---

const NOISE_PREFIXES = ['igw-', 'nat-', 'eigw-', 'rtb-', 'acl-', 'vgw-', 'dopt-', 'eni-']
const NOISE_PATHS = [
  '/aws/NetworkingAndContentDelivery/VPC/InternetGateway',
  '/aws/NetworkingAndContentDelivery/VPC/NATGateway',
  '/aws/NetworkingAndContentDelivery/VPC/RouteTable',
  '/aws/NetworkingAndContentDelivery/VPC/NetworkACL',
]

function isMeaningful(cell) {
  const name = cell.attributes.name || ''
  const path = cell.attributes.path || ''
  if (NOISE_PREFIXES.some((p) => name.startsWith(p))) return false
  if (NOISE_PATHS.some((p) => path.startsWith(p))) return false
  return true
}

export function filterNoise(graph) {
  // Pass 1: remove noise nodes
  graph
    .getCells()
    .filter((c) => c.attributes.type !== 'Group' && !isMeaningful(c))
    .forEach((c) => c.remove())

  // Pass 2: recursively remove groups left with no children
  let removed
  do {
    removed = 0
    graph
      .getCells()
      .filter((c) => c.attributes.type === 'Group')
      .filter((g) => g.getEmbeddedCells().length === 0)
      .forEach((g) => {
        g.remove()
        removed++
      })
  } while (removed > 0)
}

export function hideEmptyEnvironments(graph) {
  let deleted = 0
  const cells = graph.getCells()
  const igws = cells.filter(({ attributes }) => attributes.name?.startsWith('igw-'))
  const groups = cells.filter(({ attributes }) => attributes.type === 'Group')

  for (const igw of igws) {
    deleted++
    igw.remove()
  }

  for (const group of groups) {
    const hasChildren = group.getEmbeddedCells().length > 0
    if (!hasChildren) {
      deleted++
      group.remove()
    }
  }

  if (deleted) {
    hideEmptyEnvironments(graph)
  }

  return exportData(graph.toJSON().cells)
}

// --- Hierarchy detectors ---

// Region group: location is "us-east-1" format (not "us-east-1a")
const isRegionGroup = (g) =>
  g.attributes.location !== undefined &&
  /^[a-z]+-[a-z]+-\d+$/.test(g.attributes.location)

// VPC group: path contains 'Virtual-Private-Cloud'
const isVpcGroup = (g) => Boolean(g.attributes.path?.includes('Virtual-Private-Cloud'))

// Subnet group: name starts with subnet-, public-subnet-, or private-subnet-
const isSubnetGroup = (g) => {
  const name = g.attributes.name || ''
  return (
    name.startsWith('subnet-') ||
    name.startsWith('public-subnet-') ||
    name.startsWith('private-subnet-')
  )
}

// AZ: top-level location if set, else terraform.AvailabilityZone
const getAZ = (subnet) =>
  subnet.attributes.location ||
  subnet.attributes.terraform?.AvailabilityZone ||
  'unknown'

// Subnet type: from name prefix, then terraform.MapPublicIpOnLaunch
const getSubnetType = (subnet) => {
  const name = (subnet.attributes.name || '').toLowerCase()
  if (name.includes('public')) return 0
  if (name.includes('data') || name.includes('db')) return 2
  const tf = subnet.attributes.terraform
  if (tf) {
    if (tf.MapPublicIpOnLaunch === true) return 0
    if (tf.MapPublicIpOnLaunch === false) return 1
  }
  return 1
}

// Resource tier from path prefix
const TIER_MAP = [
  ['/aws/NetworkingAndContentDelivery/CloudFront', 0],
  ['/aws/NetworkingAndContentDelivery/Route53', 0],
  ['/aws/AppIntegration/APIGateway', 0],
  ['/aws/Networking-Content-Delivery/API-Gateway', 0],
  ['/aws/NetworkingAndContentDelivery/ElasticLoadBalancing', 1],
  ['/aws/Networking-Content-Delivery/Elastic-Load-Balancing', 1],
  ['/aws/Compute/EC2', 2],
  ['/aws/Compute/Lambda', 2],
  ['/aws/Compute/ECS', 2],
  ['/aws/Containers/Elastic-Container-Service', 2],
  ['/aws/Database', 3],
  ['/aws/Storage/S3', 3],
  ['/aws/Storage/Simple-Storage-Service', 3],
]

const getTier = (path = '') => {
  for (const [prefix, tier] of TIER_MAP) {
    if (path.startsWith(prefix)) return tier
  }
  return 2
}

const byTierThenName = (a, b) => {
  const td = getTier(a.attributes.path) - getTier(b.attributes.path)
  return td !== 0 ? td : (a.attributes.name || a.id).localeCompare(b.attributes.name || b.id)
}

// --- Layout constants ---

const GAP = 30
const HEADER = 60
const GRID_OPTS = {
  columnWidth: 'compact',
  rowHeight: 'compact',
  columnGap: GAP,
  rowGap: GAP,
  marginX: 20,
  marginY: 20,
}

// --- Cascading layout functions ---

function layoutSubnet(subnet) {
  const children = subnet.getEmbeddedCells()
  if (!children.length) return

  const sorted = [...children].sort(byTierThenName)
  layout.GridLayout.layout(sorted, {
    ...GRID_OPTS,
    columns: Math.ceil(Math.sqrt(sorted.length)),
  })
  subnet.fitToChildren({ padding: 20 })
}

function layoutVpc(vpc) {
  const children = vpc.getEmbeddedCells()
  if (!children.length) return

  const subnets = children.filter((c) => c.attributes.type === 'Group' && isSubnetGroup(c))
  const freeNodes = children.filter((c) => c.attributes.type !== 'Group')

  // Layout subnet contents first so sizes are set
  subnets.forEach(layoutSubnet)

  if (!subnets.length) {
    if (freeNodes.length) {
      const sorted = [...freeNodes].sort(byTierThenName)
      layout.GridLayout.layout(sorted, {
        ...GRID_OPTS,
        columns: Math.ceil(Math.sqrt(sorted.length)),
      })
    }
    vpc.fitToChildren({ padding: 40 })
    return
  }

  // Build AZ x type grid
  const azs = [...new Set(subnets.map(getAZ))].sort()

  const colWidths = {}
  const rowHeights = { 0: 0, 1: 0, 2: 0 }
  for (const s of subnets) {
    const az = getAZ(s)
    const type = getSubnetType(s)
    const { width, height } = s.size()
    colWidths[az] = Math.max(colWidths[az] || 0, width)
    rowHeights[type] = Math.max(rowHeights[type], height)
  }

  // Place any VPC-level free nodes in a sorted row at y=0
  const sortedFree = [...freeNodes].sort(byTierThenName)
  sortedFree.forEach((n, i) => n.position(i * (80 + GAP), 0))

  let yPos = HEADER
  for (const type of [0, 1, 2]) {
    if (rowHeights[type] === 0) continue
    let xPos = 0
    for (const az of azs) {
      const subnet = subnets.find((s) => getAZ(s) === az && getSubnetType(s) === type)
      if (subnet) {
        subnet.position(xPos, yPos)
      }
      xPos += (colWidths[az] || 200) + GAP
    }
    yPos += rowHeights[type] + GAP
  }

  vpc.fitToChildren({ padding: 40 })
}

function layoutRegion(region) {
  const children = region.getEmbeddedCells()
  if (!children.length) return

  const vpcs = children.filter((c) => c.attributes.type === 'Group' && isVpcGroup(c))
  const freeNodes = children.filter((c) => c.attributes.type !== 'Group')
  const otherGroups = children.filter(
    (c) => c.attributes.type === 'Group' && !isVpcGroup(c)
  )

  vpcs.forEach(layoutVpc)

  const topRow = [...freeNodes, ...otherGroups].sort(byTierThenName)
  if (topRow.length) {
    layout.GridLayout.layout(topRow, {
      ...GRID_OPTS,
      columns: topRow.length,
    })
  }

  let startY = 20
  if (topRow.length) {
    startY =
      Math.max(...topRow.map((n) => n.getBBox().y + n.getBBox().height), 0) + GAP * 2
  }

  const sortedVpcs = [...vpcs].sort((a, b) =>
    (a.attributes.name || '').localeCompare(b.attributes.name || '')
  )
  let xPos = 20
  for (const vpc of sortedVpcs) {
    const { width } = vpc.size()
    vpc.position(xPos, startY)
    xPos += width + GAP * 2
  }

  region.fitToChildren({ padding: 40 })
}

export function performLayout(graph) {
  const cells = graph.getCells()
  const groups = cells.filter(({ attributes: { type } }) => type === 'Group')

  const regionGroups = groups.filter((g) => !g.getParentCell() && isRegionGroup(g))
  const otherRootGroups = groups.filter((g) => !g.getParentCell() && !isRegionGroup(g))
  const freeNodes = cells
    .filter(({ attributes: { type } }) => type !== 'Group')
    .filter((c) => !c.getParentCell())

  regionGroups.forEach(layoutRegion)

  for (const group of otherRootGroups) {
    if (isVpcGroup(group)) {
      layoutVpc(group)
    } else {
      const children = group.getEmbeddedCells()
      if (children.length) {
        layout.GridLayout.layout(children, {
          ...GRID_OPTS,
          columns: Math.ceil(Math.sqrt(children.length)),
        })
        group.fitToChildren({ padding: 40 })
      }
    }
  }

  const sortedFreeNodes = [...freeNodes].sort(byTierThenName)
  if (sortedFreeNodes.length) {
    layout.GridLayout.layout(sortedFreeNodes, {
      ...GRID_OPTS,
      columns: sortedFreeNodes.length,
    })
  }

  const freeNodesBottom =
    sortedFreeNodes.length > 0
      ? Math.max(...sortedFreeNodes.map((n) => n.getBBox().y + n.getBBox().height), 0)
      : 0

  const regionRowY = freeNodesBottom > 0 ? freeNodesBottom + GAP * 3 : 0

  const sortedRegions = [...regionGroups].sort((a, b) =>
    (a.attributes.location || a.attributes.name || '').localeCompare(
      b.attributes.location || b.attributes.name || ''
    )
  )

  let currentX = 0
  for (const region of sortedRegions) {
    region.position(currentX, regionRowY)
    currentX += region.getBBox().width + GAP * 3
  }
  for (const group of otherRootGroups) {
    group.position(currentX, regionRowY)
    currentX += group.getBBox().width + GAP * 3
  }

  return exportData(graph.toJSON().cells)
}
