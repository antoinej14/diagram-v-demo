import { makeGroup } from '../shapes/group'
import { makeNode } from '../shapes/node'
import { makeTextBox } from '../shapes/textbox'
import { makeEdge } from '../shapes/edge'

export default (json) => {
  const { groups, nodes, edges } = json
  const finalGroups = {}
  let cells = []

  const addToGroup = (id, parent) => {
    const group = finalGroups[parent]
    let { embeds } = group
    if (!embeds) {
      embeds = []
    }
    embeds.push(id)
    finalGroups[parent] = {
      ...group,
      embeds
    }
  }

  groups.forEach((group) => {
    const newGroup = makeGroup(group)
    finalGroups[newGroup.id] = newGroup
  })

  nodes.forEach((node) => {
    const newNode =
      node.type === 'TextBox' || node.type === 'text-box' ? makeTextBox(node) : makeNode(node)
    const { id, parent, notes } = newNode
    if (parent) {
      addToGroup(id, parent)
    }
    if (notes === 'empty') {
      newNode.attrs['.'] = { display: 'none' }
    }
    cells.push(newNode)
  })

  edges.forEach((edge) => {
    const validSource = cells.find(({ id }) => id === edge.source) !== undefined
    const validTarget = cells.find(({ id }) => id === edge.target) !== undefined
    if (validSource && validTarget) {
      cells.push(makeEdge(edge))
    }
  })

  for (const id in finalGroups) {
    const group = finalGroups[id]
    const { parent } = group
    if (parent) {
      addToGroup(id, parent)
    }
  }

  cells = cells.concat(Object.values(finalGroups))

  return { cells, edges }
}
