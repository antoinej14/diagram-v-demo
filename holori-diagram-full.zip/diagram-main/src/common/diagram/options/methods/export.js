const cleanDirty = (item) => {
  delete item.x
  delete item.y
  delete item.style
  delete item.width
  delete item.height

  return item
}

export default (elements) => {
  const data = {
    groups: [],
    nodes: [],
    edges: []
  }

  for (const element of elements) {
    const { type } = element

    if (type === 'Group') {
      data.groups.push(cleanDirty(element))
    } else if (type === 'Node' || type === 'TextBox') {
      data.nodes.push(cleanDirty(element))
    } else {
      data.edges.push({
        ...element,
        source: element.source.id,
        target: element.target.id
      })
    }
  }

  return data
}
