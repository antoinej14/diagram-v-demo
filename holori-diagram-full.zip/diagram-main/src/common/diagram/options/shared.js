import { parse, stringify } from 'svgson'
import { anonymous_instance } from '@/api/index'

export const padding = 10
export const nodeSize = 50
export const loadingIcon = 'data:image/gif;base64,R0lGODdhAQABAIABALy8vP///ywAAAAAAQABAAACAkQBADs='
export const groupIcon =
  'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMSwxVjVIMlYxOUgxVjIzSDVWMjJIMTlWMjNIMjNWMTlIMjJWNUgyM1YxSDE5VjJINVYxTTUsNEgxOVY1SDIwVjE5SDE5VjIwSDVWMTlINFY1SDVNNiw2VjE0SDlWMThIMThWOUgxNFY2TTgsOEgxMlYxMkg4TTE0LDExSDE2VjE2SDExVjE0SDE0IiAvPjwvc3ZnPgo='
export const pinIcon =
  'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMTIsMTEuNUEyLjUsMi41IDAgMCwxIDkuNSw5QTIuNSwyLjUgMCAwLDEgMTIsNi41QTIuNSwyLjUgMCAwLDEgMTQuNSw5QTIuNSwyLjUgMCAwLDEgMTIsMTEuNU0xMiwyQTcsNyAwIDAsMCA1LDlDNSwxNC4yNSAxMiwyMiAxMiwyMkMxMiwyMiAxOSwxNC4yNSAxOSw5QTcsNyAwIDAsMCAxMiwyWiIgLz48L3N2Zz4K'

export const colors = {
  fill: '#ffffff',
  text: '#000000',
  stroke: '#bdc3c7',
  shadow: 'transparent',
  selected: '#5a40ec',
  highlighted: '#5f95ff80',
  added: '#2ecc71',
  removed: '#e74c3c',
  updated: '#f1c40f'
}

export const defaultStyle = {
  stroke: colors.stroke,
  lineWidth: 2,
  fill: colors.fill,
  radius: [5, 5],
  shadowBlur: 5,
  shadowColor: colors.shadow
}

export const arrowStyle = {
  type: 'path',
  d: 'M 10 -5 0 0 10 5 z'
}

export const getAnchorPoints = () => [
  [0.5, 0],
  [1, 0],
  [1, 0.5],
  [1, 1],
  [0.5, 1],
  [0, 1],
  [0, 0.5],
  [0, 0]
]

export const getNodeMeta = (path, createNode, terraformCallback) => {
  let obj = {}

  // TODO why not use DiagramApi.get()
  anonymous_instance
    .get(`/diagram${path}.json`)
    .then((res) => {
      obj = res.data || obj

      const terraformPath = obj.terraform_path

      if (Array.isArray(terraformPath)) {
        obj.terraform_path = terraformPath[0]
      }

      // Create an empty object for Terraform.
      if (terraformPath) {
        obj.terraform = {}
        terraformCallback(terraformPath)
      }
    })
    .catch(() => {
      console.debug('No JSON file for ' + path)
    })
    .finally(() => {
      createNode(obj)
    })
}

export const makeBorder = (cfg) => {
  const { borderStyle, borderColor, borderWidth } = cfg

  const ret = {
    stroke: borderColor || colors.stroke,
    lineWidth: borderWidth || defaultStyle.lineWidth
  }

  switch (borderStyle) {
    case 'dashed':
      ret.lineDash = [5, 5]
      break
    case 'dotted':
      ret.lineDash = [2, 2]
      break
    case 'solid':
    default:
      ret.lineDash = 0
      break
  }

  return ret
}

// https://stackoverflow.com/a/30106551
const b64EncodeUnicode = (str) => {
  // first we use encodeURIComponent to get percent-encoded Unicode,
  // then we convert the percent encodings into raw bytes which
  // can be fed into btoa.
  return btoa(
    encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function toSolidBytes(_match, p1) {
      return String.fromCharCode('0x' + p1)
    })
  )
}

export const getImage = (path, size, createImage) => {
  const success = (res) => {
    parse(res.data).then((json) => {
      json.attributes.width = size
      json.attributes.height = size

      const svg = stringify(json)

      createImage(`data:image/svg+xml;base64,${b64EncodeUnicode(svg)}`)
    })
  }

  const fail = () => {
    anonymous_instance.get('/diagram/holori/logo.svg').then((res) => success(res))
  }

  anonymous_instance
    .get(`/diagram/diagram${path}.svg`)
    .then((res) => success(res))
    .catch(fail)
}
