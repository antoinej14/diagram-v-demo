import { dia } from '@joint/plus'
import { borderStyleToDasharray } from './group.js'
import shared, { wrapLabel } from '@/common/diagram/options/shapes/shared'

const Node = dia.Element.define(
  'Node',
  {
    size: {
      width: 50,
      height: 50
    },
    attrs: {
      shape: {
        width: 50,
        height: 50,
        rx: 5,
        stroke: '#000000',
        strokeWidth: 2,
        fill: '#ffffff'
      },
      image: {
        width: 40,
        height: 40,
        x: 5,
        y: 5
      },
      label: {
        fill: '#000000',
        paintOrder: 'stroke',
        stroke: '#ffffff',
        strokeWidth: 2,
        strokeLinecap: 'butt',
        strokeLinejoin: 'miter',
        x: 25,
        y: 68,
        textAnchor: 'middle'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'rect',
        selector: 'shape'
      },
      {
        tagName: 'image',
        selector: 'image'
      },
      {
        tagName: 'text',
        selector: 'label'
      }
    ],
    ...shared
  },
  {
    attrs: {
      shape: {
        width: 50,
        height: 50
      }
    }
  }
)

const makeNode = (node) => {
  const {
    id,
    name,
    groupId,
    parent,
    notes,
    path,
    terraform_path: terraformPath,
    terraform,
    x,
    y,
    z,
    position,
    image,
    backgroundColor,
    borderColor,
    borderWidth,
    borderStyle,
    scalewayInstanceType,
    scalewayRegion
  } = node

  const strokeDasharray = borderStyleToDasharray(borderStyle)

  let finalName = name

  if (path?.startsWith('/aws/Compute/EC2')) {
    const tags = terraform.tags || terraform.Tags
    if (Array.isArray(tags)) {
      const tagName = tags.find(({ Key }) => Key === 'Name')
      if (tagName) {
        finalName = tagName.Value
      }
    }
  }

  return {
    id,
    type: 'Node',
    name: finalName,
    parent: groupId || parent,
    notes,
    path: path || '',
    terraform_path: terraformPath,
    terraform,
    x,
    y,
    z: z || 1,
    position: {
      x: (x !== undefined ? x : position?.x) || 0,
      y: (y !== undefined ? y : position?.y) || 0
    },
    size: {
      width: 50,
      height: 50
    },
    backgroundColor,
    borderColor,
    borderWidth,
    borderStyle,
    image,
    scalewayInstanceType,
    scalewayRegion,
    attrs: {
      shape: {
        stroke: borderColor,
        strokeDasharray,
        strokeWidth: borderWidth,
        fill: backgroundColor
      },
      image: {
        href: image
      },
      label: {
        text: wrapLabel(finalName)
      }
    }
  }
}

export default Node
export { makeNode }
