import { dia } from '@joint/plus'
import { groupIcon, pinIcon } from '../shared'
import shared from '@/common/diagram/options/shapes/shared'

const getHref = (image, location) => {
  if (image) {
    return image
  }

  if (location) {
    return pinIcon
  }

  return groupIcon
}

const Group = dia.Element.define(
  'Group',
  {
    attrs: {
      shape: {
        width: 'calc(w)',
        height: 'calc(h)',
        rx: 5,
        stroke: '#000000',
        strokeWidth: 2,
        fill: '#ffffff'
      },
      labelBox: {
        width: 'calc(w - 20)',
        height: 30,
        x: 'calc(x + 10)',
        y: 'calc(y - 15)',
        stroke: '#000000',
        strokeWidth: 2,
        fill: '#ffffff',
        rx: 5
      },
      labelContainer: {
        width: 'calc(w - 55)',
        height: 20,
        x: 'calc(x + 40)',
        y: 'calc(y - 10)'
      },
      image: {
        width: 20,
        height: 20,
        x: 'calc(x + 15)',
        y: 'calc(y - 10)',
        href: groupIcon
      }
    }
  },
  {
    markup: [
      {
        tagName: 'rect',
        selector: 'shape'
      },
      {
        tagName: 'rect',
        selector: 'labelBox'
      },
      {
        tagName: 'foreignObject',
        selector: 'labelContainer',
        children: [
          {
            tagName: 'div',
            namespaceURI: 'http://www.w3.org/1999/xhtml',
            selector: 'label',
            style: {
              color: '#000',
              height: '100%',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }
          }
        ]
      },
      {
        tagName: 'image',
        selector: 'image'
      }
    ],
    ...shared
  }
)

const borderStyleToDasharray = (style) => {
  if (style === 'dashed') {
    return 6
  } else if (style === 'dotted') {
    return 2
  }
  return 0
}

const makeGroup = (group) => {
  const {
    id,
    name,
    duplicates,
    x,
    y,
    z,
    position,
    parentId,
    parent,
    image,
    backgroundColor,
    borderColor,
    borderWidth,
    borderStyle,
    location,
    path,
    size,
    style,
    terraform_path: terraformPath,
    terraform
  } = group

  const width = size?.width || style?.width || 250
  const height = size?.height || style?.height || 150

  const strokeDasharray = borderStyleToDasharray(borderStyle)

  const finalX = (x || position?.x) - (style?.width ? width / 2 : 0)
  const finalY = (y || position?.y) - (style?.height ? height / 2 : 0)

  return {
    id,
    type: 'Group',
    parent: parentId || parent,
    name,
    duplicates,
    image,
    location,
    path,
    terraform_path: terraformPath,
    terraform,
    borderStyle,
    borderWidth,
    borderColor,
    backgroundColor,
    position: {
      x: !isNaN(finalX) ? finalX : 0,
      y: !isNaN(finalY) ? finalY : 0
    },
    z: z || 1,
    size: {
      width,
      height
    },
    attrs: {
      shape: {
        stroke: borderColor,
        strokeDasharray,
        strokeWidth: borderWidth,
        fill: backgroundColor
      },
      labelBox: {
        stroke: borderColor,
        strokeWidth: borderWidth,
        fill: backgroundColor
      },
      image: {
        href: getHref(image, location)
      }
    }
  }
}

export default Group
export { borderStyleToDasharray, makeGroup }
