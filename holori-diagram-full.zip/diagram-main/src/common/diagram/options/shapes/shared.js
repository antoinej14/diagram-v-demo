import { dia } from '@joint/plus'

export function wrapLabel(label, long = false, direct = false) {
  if (!label) {
    return ''
  }

  let splitLabel

  if (long) {
    splitLabel = label?.match(/[\s\S]{1,40}/g)
  } else {
    splitLabel = label?.match(/[\s\S]{1,17}/g)
  }

  if (direct) {
    return splitLabel.join('\n')
  }

  return splitLabel[0] + (splitLabel.length > 1 ? '...' : '')
}

export default {
  initialize(model) {
    dia.Element.prototype.initialize.apply(this, arguments)
    setTimeout(() => {
      this.setLabel(model.name, model.type)
    }, 200)
  },
  setLabel(label, type = 'Node') {
    const view = this.findView(window.paper || window['paper' + this.graph.attributes.number])
    const finalLabel = wrapLabel(label, type === 'Group')

    if (view) {
      const div = view.el.querySelector('div')
      const textBox = view.el.querySelector('text')
      if (div) {
        div.innerHTML = finalLabel
      } else if (textBox) {
        textBox.innerHTML = finalLabel
      } else {
        // Try again after some time.
        if (!textBox) {
          setTimeout(() => this.setLabel(label, type), 200)
        }
      }
    }
  }
}
