import { colors } from '../shared'

const makeHighlighter = (color) => ({
  name: 'stroke',
  options: {
    padding: 10,
    rx: 5,
    ry: 5,
    attrs: {
      stroke: color,
      strokeWidth: 4,
      fill: color,
      opacity: 0.5
    }
  }
})

const added = makeHighlighter(colors.added)
const removed = makeHighlighter(colors.removed)
const updated = makeHighlighter(colors.updated)

export default {
  added,
  removed,
  updated
}
