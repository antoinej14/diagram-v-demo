import { dia } from '@joint/plus'

const Edge = dia.Link.define(
  'Edge',
  {
    attrs: {
      line: {
        connection: true,
        stroke: '#333333',
        strokeWidth: 2,
        strokeLinejoin: 'round',
        targetMarker: {
          type: 'path',
          d: 'M 10 -5 0 0 10 5 z'
        }
      },
      wrapper: {
        connection: true,
        strokeWidth: 10,
        strokeLinejoin: 'round'
      }
    }
  },
  {
    markup: [
      {
        tagName: 'path',
        selector: 'wrapper',
        attributes: {
          fill: 'none',
          cursor: 'pointer',
          stroke: 'transparent'
        }
      },
      {
        tagName: 'path',
        selector: 'line',
        attributes: {
          fill: 'none',
          'pointer-events': 'none'
        }
      }
    ]
  }
)

const lineTypeOptions = {
  linear: 'normal',
  smooth: 'manhattan',
  ortho: 'orthogonal'
}

const lineStyleOptions = {
  solid: 0,
  dashed: 8,
  dotted: 2
}

const makeEdge = (edge) => {
  const { id, label, source, target, vertices, lineColor, lineStyle, lineType, z } = edge

  return {
    id,
    type: 'Edge',
    label,
    vertices,
    lineColor,
    lineStyle,
    lineType,
    z: z || 1,
    router: {
      name: lineTypeOptions[lineType || 'linear'],
      args: {}
    },
    source: {
      id: source
    },
    target: {
      id: target
    },
    connector: {
      name: 'jumpover',
      args: {
        size: 10
      }
    },
    attrs: {
      line: {
        stroke: lineColor,
        strokeDasharray: lineStyleOptions[lineStyle]
      }
    }
  }
}

export default Edge
export { makeEdge, lineTypeOptions, lineStyleOptions }
