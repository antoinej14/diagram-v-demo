import { dia } from '@joint/plus'

const TextBox = dia.Element.define(
  'TextBox',
  {
    size: {
      width: 100,
      height: 30
    },
    attrs: {
      labelContainer: {
        width: 'calc(w)',
        height: 'calc(h)',
        rx: 5,
        stroke: '#000000',
        strokeWidth: 2,
        fill: '#ffffff'
      },
      label: {
        width: 'calc(w - 10)',
        height: 'calc(h - 10)',
        x: 5,
        y: 20
      }
    }
  },
  {
    markup: [
      {
        tagName: 'rect',
        selector: 'labelContainer'
      },
      {
        tagName: 'text',
        selector: 'label'
      }
    ],
    updateNotes(notes) {
      const lines = notes.split('\n')
      let width = 100

      for (const line of lines) {
        width = Math.max(width, line.length * 9 + 10)
      }

      const height = Math.max(lines.length * 18 + 10, 30)
      this.size({ width, height })
      this.attr('label/text', notes)
    },
    initialize(model) {
      dia.Element.prototype.initialize.apply(this, arguments)
      this.updateNotes(model.notes)
      this.on('change:notes', (_el, notes) => this.updateNotes(notes))
    }
  }
)

const makeTextBox = (textBox) => {
  const {
    id,
    name,
    notes,
    x,
    y,
    z,
    position,
    groupId,
    parent,
    backgroundColor,
    borderColor,
    borderWidth,
    size,
    style
  } = textBox

  const width = size?.width || style?.width || 100
  const height = size?.height || style?.height || 100

  return {
    id,
    type: 'TextBox',
    parent: groupId || parent,
    name,
    notes,
    borderWidth,
    borderColor,
    backgroundColor,
    position: {
      x: (x || position?.x) - (style?.width ? width / 2 : 0),
      y: (y || position?.y) - (style?.height ? height / 2 : 0)
    },
    z: z || 1,
    size: {
      width,
      height
    },
    attrs: {}
  }
}

export default TextBox
export { makeTextBox }
