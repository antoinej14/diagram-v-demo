import { ref } from 'vue'
import { useRoute } from 'vue-router'

export function usePagination(limit, loadingRef, loadPageCallback, updateCallback, sourceRef) {
  const route = useRoute()

  const currentPage = ref(route.query.page || 1)

  let offsets = {}

  let pageContents = {}

  function reset() {
    currentPage.value = 1

    offsets = {}

    pageContents = {}
  }

  function update() {
    const rows = sourceRef.value

    pageContents[currentPage.value] = rows

    function addToOffset(key) {
      if (!(key in offsets)) {
        offsets[key] = 0
      }

      offsets[key]++
    }

    for (const row of rows) {
      const key = row.account?.id || row.accountID

      addToOffset(key)
    }

    loadingRef.value = false
  }

  function loadPage(promises = [], forceUpdate = false) {
    const page = currentPage.value

    if (!(page in pageContents) || forceUpdate) {
      loadingRef.value = true

      Promise.allSettled([...promises, loadPageCallback(offsets, limit)]).then(() => {
        updateCallback(sourceRef.value)

        update()
      })
    } else {
      sourceRef.value = pageContents[page]
    }
  }

  function loadMore(direction = 1) {
    currentPage.value += direction

    loadPage()
  }

  return {
    currentPage,
    reset,
    loadPage,
    loadMore
  }
}
