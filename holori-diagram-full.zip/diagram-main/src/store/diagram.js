import terraformImportApi from '@/api/modules/public/mapping/terraform'
import { MIGRATION_VERSION } from '@/common/diagram/migration'
import { defineStore } from 'pinia'
import { useProjectStore } from './project'
import mappingApi from '@/api/modules/public/mapping'

const originalData = {
  groups: [],
  edges: [],
  nodes: [],
  version: MIGRATION_VERSION
}

export const originalSelection = {
  groups: [],
  edges: [],
  nodes: []
}

const initialState = {
  data: originalData,
  selection: originalSelection,
  uniqueSelection: {
    group: null,
    edge: null,
    node: null
  },
  addingNodePath: '',
  canUndo: false,
  canRedo: false,
  saving: false,
  saved: true,
  undoSize: 0,
  redoSize: 0,
  terraformFields: {},
  locations: [],
  companies: [],
  detailsTab: 'general',
  layouting: false,
  comparing: false,
  comparingRow: null,
  updatedTerraformKeys: {},
  settings: {},
  resourcesCategories: { resources: true, regions: true, tags: true },
  resourcesFilters: {}
}

export const useDiagramStore = defineStore({
  id: 'diagram',

  state: () => initialState,

  persist: {
    storage: localStorage,
    paths: ['resourcesCategories', 'resourcesFilters']
  },

  getters: {
    getNodes: ({ data: { nodes } }) => nodes,
    getEdges: ({ data: { edges } }) => edges,
    getData: (state) => state.data,
    getGlobalSelection: ({ selection: { groups, edges, nodes } }) => [
      ...groups,
      ...edges,
      ...nodes
    ],
    isSelected() {
      return (id) => this.getGlobalSelection.find((item) => item.id === id) !== undefined
    },
    findById:
      ({ data: { groups, nodes } }) =>
      (id) => {
        const data = [...groups, ...nodes]
        let found = null

        for (const item of data) {
          if (item.id === id) {
            found = item
            break
          }
        }

        return found
      },
    /**
     * Returns the total length of the selection.
     * @returns
     */
    getGlobalSelectionCount() {
      return this.getGlobalSelection.length
    },
    hasUniqueSelection: ({ uniqueSelection: { group, edge, node } }) => !!group || !!edge || !!node,
    getSelectedGroup({ uniqueSelection, selection }) {
      if (!this.hasUniqueSelection) {
        return selection.groups[0]
      }
      return uniqueSelection.group
    },
    getSelectedEdge({ uniqueSelection, selection }) {
      if (!this.hasUniqueSelection) {
        return selection.edges[0]
      }
      return uniqueSelection.edge
    },
    getSelectedNode({ uniqueSelection, selection }) {
      if (!this.hasUniqueSelection) {
        return selection.nodes[0]
      }
      return uniqueSelection.node
    },
    getSelectedItem() {
      return this.getSelectedNode || this.getSelectedGroup
    },
    getSelectedAnything() {
      return this.getSelectedEdge || this.getSelectedItem
    },
    getItemTerraform: (state) => (id, type) =>
      state.data[type + 's'].find((node) => node.id === id).terraform,
    getUsedLocations: (state) =>
      state.data.groups
        .filter((group) => group.location !== undefined)
        .map((group) => group.location),
    canLeave: (state) => state.undoSize === 0 && state.saved && !state.saving,
    getElementsNumber: ({ data: { nodes, groups, edges } }) =>
      groups.length + edges.length + nodes.length,

    isComparing: (state) => state.comparing,
    getUpdatedTerraformKey: (state) => (id, key) => {
      const forID = state.updatedTerraformKeys[id]
      if (forID) {
        const hasValue = key in forID
        if (hasValue) {
          const val = forID[key]

          // Previous value was undefined, return an empty string.
          if (val === undefined) {
            return '<no value>'
          }

          return val
        }
      }
      return undefined
    }
  },

  actions: {
    setSelection(selection) {
      this.selection = selection
    },
    clearSelection() {
      this.selection = originalSelection
    },
    setUniqueSelection(selection) {
      this.uniqueSelection = selection
    },
    clearUniqueSelection() {
      this.uniqueSelection = {
        group: null,
        edge: null,
        node: null
      }
    },
    setData(data) {
      this.data = {
        ...data,
        version: data.version || MIGRATION_VERSION
      }
    },
    saveData(data) {
      this.saveOriginalData(data)
      this.setSaved(false)
    },
    saveOriginalData(data) {
      this.data = JSON.parse(data)
    },
    setSaved(saved) {
      this.saved = saved
    },
    reset() {
      this.data = originalData
    },
    saveDiagram(organizationID, thumbnail) {
      return new Promise((resolve, reject) => {
        const diagram = JSON.stringify(this.data)

        this.saving = true

        const projectStore = useProjectStore()

        const projectChanges = {
          ...projectStore.project,
          diagram,
          thumbnail,
          importing: null // reset import flag when saving a new diagram to the server
        }

        this.setSaved(true)

        projectStore
          .editProject(organizationID, projectStore.projectID, projectChanges)
          .then(() => {
            this.saving = false
            projectStore.setProjectDiagram(diagram)
            resolve()
          })
          .catch(reject)
      })
    },
    setCanUndo(canUndo) {
      this.canUndo = canUndo
    },
    setCanRedo(canRedo) {
      this.canRedo = canRedo
    },
    setUndoSize(undoSize) {
      this.undoSize = undoSize
    },
    setRedoSize(redoSize) {
      this.redoSize = redoSize
    },
    setAddingNodePath(path) {
      this.addingNodePath = path
    },
    getTerraformFields(path) {
      if (!(path in this.terraformFields)) {
        this.fetchTerraformFields(path)
      }
    },
    fetchTerraformFields(path) {
      terraformImportApi
        .get(path)
        .catch((error) => {
          console.warn('unable to load terraform fields :', error)
        })
        .then(({ data }) => {
          this.setTerraformFields({
            path,
            fields: data
          })
        })
    },
    setLocations(locations) {
      this.locations = locations
    },
    loadCompanies() {
      return new Promise((resolve) => {
        mappingApi
          .getPublic('mapping/providers.json')
          .catch((error) => {
            console.warn('unable to load provider list :', error)
            this.setCompanies([])
            resolve([])
          })
          .then(({ data }) => {
            const companies = Object.keys(data)
              .filter((key) => key !== '')
              .map((name) => ({
                name,
                pretty: data[name].name
              }))

            this.setCompanies(companies)

            resolve(companies)
          })
      })
    },
    setTerraformFields(payload) {
      this.terraformFields = {
        ...this.terraformFields,
        [payload.path]: payload.fields
      }
    },
    setCompanies(companies) {
      this.companies = companies
    },
    setDetailsTab(tab) {
      this.detailsTab = tab
    },
    setLayouting(layouting) {
      this.layouting = layouting
    },
    setComparing(comparing) {
      this.comparing = comparing

      if (!comparing) {
        this.cleanUpdatedTerraformKeys()
      }
    },
    setComparingRow(comparingRow) {
      this.comparingRow = comparingRow
    },
    cleanUpdatedTerraformKeys() {
      this.updatedTerraformKeys = []
    },
    addUpdatedTerraformKey({ id, key, value }) {
      this.updatedTerraformKeys[id] = {
        ...this.updatedTerraformKeys[id],
        [key]: value
      }
    },
    setSettings(settings) {
      this.settings = settings
    },
    toggleResourcesCategories(category) {
      this.resourcesCategories = {
        ...this.resourcesCategories,
        [category]: !this.resourcesCategories[category]
      }
    },
    setResourcesFilters(key, filters) {
      this.resourcesFilters = {
        ...this.resourcesFilters,
        [key]: filters
      }
    }
  }
})
