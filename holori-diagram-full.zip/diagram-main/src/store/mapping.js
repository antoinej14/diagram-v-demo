import mappingApi from '@/api/modules/public/mapping'
import { defineStore } from 'pinia'

export const useMappingStore = defineStore({
  id: 'mapping',

  state: () => ({
    mapping: {},
    providersData: {},
    ssoProviders: [],
    regions: [],
    regionsReady: false,
    offers: {}
  }),

  getters: {
    /**
     * "Converts" a provider version of location, to a Holori version of location.
     * @param {Object} state
     * @returns {String} The corresponding value, or <empty string> if not found.
     */
    findHoloriValueForLocation:
      ({ regions }) =>
      ({ location, provider }) => {
        if (!location || !provider) {
          return ''
        }

        const regionsForProvider = regions.find((reg) => reg.provider === provider)

        if (!regionsForProvider) {
          return ''
        }

        const foundRegion = regionsForProvider.regions.find(
          (region) => region.providerValue === location
        )

        if (!foundRegion) {
          return ''
        }

        return foundRegion.holoriValue
      },

    getHoloriValues: ({ regions }) =>
      regions
        .map((obj) => obj.regions.map(({ holoriValue }) => holoriValue))
        .reduce((prev, curr) => prev.concat(curr), [])
  },

  actions: {
    /**
     * Loads the providers data from the JSON file.
     */
    getProvidersData() {
      this.providersData = {}

      return new Promise((resolve) => {
        mappingApi
          .get('providers.json')
          .catch(function (error) {
            console.warn('unable to load providers :', error)
            resolve({})
          })
          .then(({ data }) => {
            this.providersData = data
            resolve(data)
          })
      })
    },

    /**
     * Loads the SSO providers from the JSON file.
     */
    getSSOProviders() {
      this.ssoProviders = {}

      return mappingApi
        .get('sso.json')
        .catch(function (error) {
          console.warn('unable to load sso providers :', error)
        })
        .then(({ data }) => {
          this.ssoProviders = data
        })
    },

    /**
     * TODO
     *
     * @param {*} providers
     * @returns
     */
    async getAllRegions(providers) {
      this.regionsReady = false
      this.regions = []

      if (!providers) {
        console.warn('empty provider list given as parameter to getAllRegions()')
        this.regionsReady = true
        return
      }

      const promises = providers
        .filter((provider) => provider)
        .map(({ name: providerName }) => {
          return this.get(`${providerName}/configuration.json`)
            .catch((error) => {
              console.warn('unable to load provider configuration :', error)
            })
            .then((data) => {
              if (!data || typeof data === 'string') {
                this.regions.push({
                  provider: providerName,
                  regions: []
                })
                return
              }

              const regions = Object.keys(data.regions)
                .map((providerValue) => ({
                  holoriValue: data.regions[providerValue],
                  providerValue: isNaN(providerValue) ? providerValue : data.regions[providerValue],
                  providerName // We need to repeat it to store it on the location group later.
                }))
                .sort((a, b) => (a.providerValue < b.providerValue ? -1 : 1))

              this.regions.push({
                provider: providerName,
                regions
              })
            })
        })

      await Promise.all(promises)

      this.regions = this.regions.sort((a_1, b_1) => {
        if (a_1.provider === 'aws' && b_1.provider !== 'aws') {
          return -1
        } else if (a_1.provider === 'azure' && !['aws', 'azure'].includes(b_1.provider)) {
          return -1
        } else if (
          ['gcp', 's3ns'].includes(a_1.provider) &&
          ['aws', 'azure', 'gcp', 's3ns'].includes(b_1.provider)
        ) {
          return -1
        }

        return 1
      })

      this.regionsReady = true
    },

    /**
     * Retrieves a JSON file from the mapping part.
     * @param {String} url The JSON path to retrieve.
     * @returns {Object} The JSON data you wanted.
     */
    get(url) {
      return new Promise((resolve) => {
        const found = this.mapping[url]

        if (found) {
          resolve(found)
          return
        }

        this.mapping[url] = {}

        mappingApi
          .get(url)
          .catch(function (error) {
            console.warn('unable to load mapping file :', error)
            resolve({})
          })
          .then(({ data }) => {
            this.mapping[url] = data
            resolve(data)
          })
      })
    },

    /**
     * Retrieves a list of JSON files from the mapping part, and gives the merge of all of them.
     * @param {Array<String>} urls The list of JSON paths to retrieve.
     * @returns {Object} The merge of all JSON data you wanted.
     */
    getAll(urls, merge = true) {
      return new Promise((resolve) => {
        Promise.all(urls.map(this.get)).then(() => {
          let data = {}

          urls.forEach((url) => {
            if (merge) {
              data = {
                ...data,
                ...this.mapping[url]
              }
            } else {
              data = {
                ...data,
                [url]: this.mapping[url]
              }
            }
          })

          resolve(data)
        })
      })
    },

    getTemplates() {
      return new Promise((resolve) => {
        mappingApi
          .getPublic('templates/list.json')
          .catch(function (error) {
            console.warn('unable to load templates :', error)
            resolve([])
          })
          .then(({ data }) => {
            const keys = Object.keys(data)
            const templates = keys.map((id) => ({
              id,
              ...data[id],
              thumbnail: `/templates/${id}/thumbnail.png`
            }))
            resolve(templates)
          })
      })
    },

    getTemplate(template) {
      return new Promise((resolve) => {
        mappingApi
          .getPublic(`templates/${template}/diagram.json`)
          .catch(function (error) {
            console.warn('unable to load template diagram :', error)
          })
          .then(({ data }) => {
            mappingApi
              .getPublic(`templates/${template}/thumbnail.png`, { responseType: 'blob' })
              .catch(function (error) {
                console.warn('unable to load template thumbnail :', error)
              })
              .then((res) => {
                const reader = new FileReader()
                reader.onloadend = function () {
                  resolve({
                    ...data,
                    thumbnail: reader.result
                  })
                }
                reader.readAsDataURL(res.data)
              })
          })
      })
    },

    /**
     * TODO
     * @param {*} id
     * @param {*} data
     * @returns
     */
    findFirstLocation(id, data) {
      if (!id) {
        return ''
      }

      const model =
        data !== undefined
          ? data.groups.find((group) => group.id === id)
          : window.graph.getCell(id).attributes

      const { location, provider, parentId } = model

      if (location) {
        return this.findHoloriValueForLocation({ location, provider })
      }

      if (parentId) {
        return this.findFirstLocation(parentId)
      }

      return ''
    },

    /**
     * TODO
     * @param {*} id
     * @param {*} data
     * @returns
     */
    findFirstLocationForDisplay(id, data) {
      if (!id) {
        return ''
      }

      const model =
        data !== undefined
          ? data.groups.find((group) => group.id === id)
          : window.graph.getCell(id).attributes

      const { location, parentId } = model

      if (location) {
        return location
      }

      if (parentId) {
        return this.findFirstLocationForDisplay(parentId)
      }

      return ''
    },

    /**
     * Returns the product name and provider name from a node's path.
     * @param {String} path The node's path
     * @returns { String, String, String }
     */
    splitPath(path) {
      const splittedPath = path.split('/')

      if (path.startsWith('/')) {
        splittedPath.shift()
      }

      const providerName = splittedPath[0]
      const productName = splittedPath.pop()

      return { productName, providerName }
    }
  }
})
