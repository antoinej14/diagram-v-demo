import projectsApi from '@/api/modules/main-server/organizations/projects'
import { calculatePagination } from '@/common/paginate'
import { defineStore } from 'pinia'

export const useProjectStore = defineStore({
  id: 'project',

  state: () => ({
    projects: [],

    project: null,
    projectDiagram: null,
    autosave: true,
    autosaveDelay: 30,

    loading: false,
    pagination: {
      total: 0,
      offset: 0,
      limit: 10,
      current: 1,
      sortBy: 'desc(last_modified)'
    },

    filters: {},

    comparingProjectID: null,

    history: {
      data: [],
      offset: 0,
      total: 0,
      limit: 20,
      current: 1
    }
  }),

  getters: {
    /* TODO */
    projectID: ({ project }) => project?.id
  },

  actions: {
    setProjects(projects) {
      this.projects = projects
    },

    setProject(project) {
      this.project = project
    },

    setFilters(filters) {
      this.filters = filters
    },

    changePage(newPage) {
      this.pagination.offset = (newPage - 1) * this.pagination.limit
    },

    setPageSize(limit) {
      this.pagination.limit = limit
    },

    setSortBy(sortBy) {
      this.pagination.sortBy = sortBy
    },

    /**
     * TODO
     * 
     * @param {*} organizationID 
     * @returns 
     */
    getProjects(organizationID) {
      this.loading = true
      return new Promise((resolve) => {
        const { offset, limit, sortBy } = this.pagination
        const filters = {
          ...this.filters,
          sort_by: sortBy
        }

        projectsApi.getProjects(organizationID, offset, limit, filters).then((res) => {
          this.projects = res.data
          this.pagination = {
            ...this.pagination,
            ...calculatePagination(res.headers)
          }
          this.loading = false
          resolve(this.projects)
        })
      })
    },

    /**
     * TODO
     * 
     * @param {*} organizationID 
     * @param {*} projectID 
     * @returns 
     */
    getProject(organizationID, projectID) {
      this.project = null
      this.projectDiagram = null

      return new Promise((resolve, reject) => {
        projectsApi.getProject(organizationID, projectID).then(
          ({ data }) => {
            this.project = data
            resolve(data)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Get the project diagram.
     * @param {Number} organizationID The organization ID.
     * @param {Number} projectID The project ID.
     * @returns {Promise<String>}
     */
    getProjectDiagram(organizationID, projectID) {
      this.projectDiagram = null

      return new Promise((resolve, reject) => {
        projectsApi.getProjectDiagram(organizationID, projectID).then(
          ({ data }) => {
            // FOR LEGACY REASONS...
            let diagram = data.diagram || '{ "nodes": [], "edges": [], "groups": [] }'
            const parsed = JSON.parse(diagram)
            if (!('combos' in parsed)) {
              this.projectDiagram = diagram
            }
            resolve(diagram)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * TODO
     *
     * @param {*} projectDiagram
     */
    setProjectDiagram(projectDiagram) {
      this.projectDiagram = projectDiagram
    },

    /**
     * TODO
     *
     * @param {*} organizationID
     * @param {*} projectID
     * @returns
     */
    getProjectThumbnail(organizationID, projectID) {
      return projectsApi.getProjectThumbnail(organizationID, projectID)
    },

    /**
     * Get the project history.
     * @param {Number} organizationID The organization ID.
     * @param {Number} projectID The project ID.
     * @returns {Promise<AxiosResponse>}
     */
    getProjectHistory(organizationID, projectID) {
      this.history.data = []

      return new Promise((resolve, reject) => {
        const { offset, limit } = this.history
        projectsApi.getProjectHistory(organizationID, projectID, { offset, limit }).then(
          (res) => {
            this.history = {
              ...this.history,
              data: res.data.map(({ diagram, ...rest }) => ({
                ...rest,
                diagram: diagram.replace('"combos":', '"groups":')
              })),
              ...calculatePagination(res.headers)
            }
            resolve(res.data)
          },
          () => reject(new Error('Could not get project history.'))
        )
      })
    },

    /**
     * TODO
     *
     * @param {*} page
     */
    setHistoryOffset(page) {
      this.history.offset = (page - 1) * this.history.limit
    },

    /**
     * TODO
     *
     * @param {*} comparingProjectID
     */
    setComparingProjectID(comparingProjectID) {
      this.comparingProjectID = comparingProjectID
    },

    /**
     * Create a new project in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Object} data `diagram`, `thumbnail`, `name`, `notes`
     * @returns {Promise<AxiosResponse>}
     */
    createProject(organizationID, data) {
      return projectsApi.createProject(organizationID, data)
    },

    /**
     * Edit a project in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} projectID The project ID.
     * @param {Object} data `diagram`, `thumbnail`, `name`, `notes`
     * @returns {Promise<AxiosResponse>}
     */
    editProject(organizationID, projectID, data) {
      return projectsApi.editProject(organizationID, projectID, data)
    },

    /**
     * Delete a project in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} projectID The project ID.
     * @returns {Promise<AxiosResponse>}
     */
    deleteProject(organizationID, projectID) {
      return projectsApi.deleteProject(organizationID, projectID)
    },

    /**
     * TODO
     * 
     * @param {*} autosave 
     */
    setAutosave(autosave) {
      this.autosave = autosave
    },

    /**
     * TODO
     * 
     * @param {*} autosaveDelay 
     */
    setAutosaveDelay(autosaveDelay) {
      this.autosaveDelay = autosaveDelay
    }
  }
})
