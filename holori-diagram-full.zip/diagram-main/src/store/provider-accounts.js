import providerAccountsApi from '@/api/modules/main-server/organizations/provider-accounts'
import { defineStore } from 'pinia'
import { anonymous_instance } from '@/api/index.js'
import moment from 'moment'
import MergeDiagramsWorker from '@/workers/merge-diagrams.js?worker'
import { calculatePagination } from '@/common/paginate.js'
import { API_DIMENSIONS } from '@/common/enums.js'
import { useAppStore } from './app'

const initialState = {
  providerAccounts: [],
  subdivisions: {},
  total: 0,
  providerAccount: null,

  synchronizations: [],
  synchronizationPagination: {
    current: 1,
    total: 0
  },
  synchronizationDiagram: null,
  synchronizationThumbnail: null,

  loading: {
    synchronizations: false,
    synchronizationDiagram: false,
    synchronizationThumbnail: false,
    providerAccounts: {}
  }
}

const emptyDiagram = { nodes: [], edges: [], groups: [] }

export const useProviderAccountsStore = defineStore({
  id: 'provider-account',

  state: () => initialState,

  getters: {
    /* TODO */
    lastSynchronizationDate: ({ synchronizations }) => synchronizations[0]?.imported,

    /* TODO */
    getAccountByID:
      ({ providerAccounts }) =>
        (id) =>
          providerAccounts.find((providerAccount) => providerAccount.id === id)
  },

  actions: {
    /**
     * Get a list of provider accounts in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Object} filters `name`, `provider_name`, `enabled`, `created_since`, `created_until`, `offset`, `limit`
     * @returns {Promise<Array<Object>>}
     */
    getProviderAccounts(organizationID, filters = {}) {
      if ('provider_name' in filters) {
        this.loading.providerAccounts[filters.provider_name] = true
      }
      return new Promise((resolve, reject) => {
        providerAccountsApi.getProviderAccounts(organizationID, filters).then(
          (res) => {
            if ('provider_name' in filters) {
              this.loading.providerAccounts[filters.provider_name] = false
            }

            this.providerAccounts = res.data
            this.total = Number(res.headers['content-range'].split('/')[1])
            resolve(res.data)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Create a new provider account in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Object} data `name`, `enabled`, `provider_name`, `authentication_data`
     * @returns {Promise<AxiosResponse>}
     */
    createProviderAccount(organizationID, data) {
      this.providerAccount = null

      return new Promise((resolve, reject) => {
        providerAccountsApi.createProviderAccount(organizationID, data).then(
          (res) => {
            this.providerAccount = res.data
            resolve(res)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Edit a provider account in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Object} data `name`, `enabled`, `provider_name`, `authentication_data`
     * @returns {Promise<AxiosResponse>}
     */
    editProviderAccount(organizationID, accountID, data) {
      return new Promise((resolve, reject) => {
        providerAccountsApi.editProviderAccount(organizationID, accountID, data).then(
          (res) => resolve(res),
          (err) => reject(err)
        )
      })
    },

    /**
     * TODO
     * 
     * @param {*} account 
     */
    setProviderAccount(account) {
      this.providerAccount = account
    },

    /**
     * Get a provider account in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @returns {Promise<AxiosResponse>}
     */
    getProviderAccount(organizationID, accountID) {
      return new Promise((resolve, reject) => {
        providerAccountsApi.getProviderAccount(organizationID, accountID).then(
          ({ data }) => {
            this.providerAccount = data
            resolve(data)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Delete a provider account in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @returns {Promise<AxiosResponse>}
     */
    deleteProviderAccount(organizationID, accountID) {
      return new Promise((resolve, reject) => {
        providerAccountsApi.deleteProviderAccount(organizationID, accountID).then(
          () => {
            resolve()
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Verify a provider account in this organization.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @returns {Promise<AxiosResponse>}
     */
    verifyProviderAccount(organizationID, accountID) {
      return new Promise((resolve, reject) => {
        providerAccountsApi.verifyProviderAccount(organizationID, accountID).then(
          (res) => {
            resolve(res.data)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Get synchronizations for provider account.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Object} params Offset/limit.
     * @returns {Promise<Array<Object>>}
     */
    getSynchronizations(organizationID, accountID, params = {}) {
      this.synchronizations = []
      this.loading.synchronizations = true

      return new Promise((resolve) => {
        providerAccountsApi.getSynchronizations(organizationID, accountID, params).then((res) => {
          const { headers, data } = res
          this.synchronizations = data
          this.loading.synchronizations = false
          this.synchronizationPagination = calculatePagination(headers)
          resolve(data)
        })
      })
    },

    /**
     * Get the latest synchronization from a provider account.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @returns {Promise<Object>}
     */
    getLastSynchronization(organizationID, accountID) {
      this.synchronizations = []
      this.loading.synchronizations = true

      return new Promise((resolve) => {
        providerAccountsApi.getLastSynchronization(organizationID, accountID).then(({ data }) => {
          const sync = data[0]
          this.synchronizations = data
          this.loading.synchronizations = false
          resolve(sync)
        })
      })
    },

    /**
     * Update the synchronizations.
     * @param {Array<Object>} synchronizations
     */
    setSynchronizations(synchronizations) {
      this.synchronizations = synchronizations
    },

    /**
     * Get a synchronization entry.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Number} synchronizationID The synchronization ID.
     * @returns {Promise<Object>}
     */
    getSynchronization(organizationID, accountID, synchronizationID) {
      return new Promise((resolve, reject) => {
        providerAccountsApi.getSynchronization(organizationID, accountID, synchronizationID).then(
          ({ data }) => {
            resolve(data)
          },
          () => reject(new Error('Could not get synchronization.'))
        )
      })
    },

    /**
     * Get the diagram for a synchronization entry.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Number} synchronizationID The synchronization ID.
     * @returns {Promise<String>}
     */
    getSynchronizationDiagram(organizationID, accountID, synchronizationID) {
      this.synchronizationDiagram = null
      this.loading.synchronizationDiagram = true

      return new Promise((resolve, reject) => {
        providerAccountsApi
          .getSynchronizationDiagram(organizationID, accountID, synchronizationID)
          .then(
            ({ data }) => {
              let { diagram } = data
              if (!diagram) {
                diagram = JSON.stringify(emptyDiagram)
              }
              this.synchronizationDiagram = diagram
              this.loading.synchronizationDiagram = false
              resolve(diagram)
            },
            () => reject(new Error('Could not get synchronization diagram.'))
          )
      })
    },

    /**
     * Set the synchronization diagram.
     * @param {Object} synchronizationDiagram The diagram data.
     */
    setSynchronizationDiagram(synchronizationDiagram) {
      this.synchronizationDiagram = synchronizationDiagram
    },

    /**
     * Get the thumbnail for a synchronization entry.
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Number} synchronizationID The synchronization ID.
     * @returns {Promise<Object>}
     */
    getSynchronizationThumbnail(organizationID, accountID, synchronizationID) {
      this.synchronizationThumbnail = null
      this.loading.synchronizationThumbnail = true

      return new Promise((resolve, reject) => {
        providerAccountsApi
          .getSynchronizationThumbnail(organizationID, accountID, synchronizationID)
          .then(
            ({ data }) => {
              this.synchronizationThumbnail = data.thumbnail
              this.loading.synchronizationThumbnail = false
              resolve(data.thumbnail)
            },
            () => reject(new Error('Could not get synchronization thumbnail.'))
          )
      })
    },

    /**
     * TODO
     * 
     * @param {*} synchronizationThumbnail 
     */
    setSynchronizationThumbnail(synchronizationThumbnail) {
      this.synchronizationThumbnail = synchronizationThumbnail
    },

    /**
     * Edit a synchronization.
     * @param {Number} organizationID
     * @param {Number} accountID
     * @param {Number} synchronizationID
     * @param {{ thumbnail: String, diagram: String }} payload
     * @returns {Promise<AxiosResponse<any>>}
     */
    editSynchronization(organizationID, accountID, synchronizationID, payload) {
      return providerAccountsApi.editSynchronization(
        organizationID,
        accountID,
        synchronizationID,
        payload
      )
    },

    /**
     * Convert cost results to the selected currency
     *
     * It mutates the response data
     * @param {*} promise
     * @returns
     */
    convertCurrencyCost(promise, costFieldName = 'cost', useOriginalCurrency = false) {
      const appStore = useAppStore()

      return new Promise((resolve, reject) => {
        promise.then(
          async (response) => {
            const endDate =
              response.config?.params.end_date || new Date().toISOString().slice(0, 10)

            for (const row of response.data || []) {
              if (useOriginalCurrency) {
                // might be a second conversion,
                //   use original_currency as currency
                row.currency = row.original_currency
              }

              // remember the original values
              row['original_' + costFieldName] = row[costFieldName]
              row.original_currency = row.currency

              // do the conversion
              row[costFieldName] = await appStore.convertCurrency(
                row[costFieldName],
                row.currency,
                row.date || endDate
              )
              row.currency = appStore.selectedCurrency
            }

            resolve(response)
          },
          (err) => reject(err)
        )
      })
    },

    /**
     * Get cost
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountOrID The provider account ID.
     * @param {Object} parameters `granularity`, `filters`, `group_by`, `start_date`, `end_date`
     * @param {Object} filterRules TODO
     * @returns {Promise<AxiosResponse>}
     */
    getCost(organizationID, accountOrID, parameters = {}, filterRules = {}) {
      const account =
        typeof accountOrID === 'object' ? accountOrID : this.getAccountByID(accountOrID)

      if (parameters.group_by && !Object.values(API_DIMENSIONS).includes(parameters.group_by)) {
        // remove invalid group by (ex. invalid dimension or provider or account or segment)
        delete parameters.group_by
      }

      const promise = providerAccountsApi.getCost(
        organizationID,
        account.id,
        parameters,
        filterRules
      )

      return this.convertCurrencyCost(promise)
    },

    /**
     * Get usage
     * @param {Number} organizationID The organization ID.
     * @param {Number} accountID The provider account ID.
     * @param {Object} parameters `granularity`, `filters`, `group_by`, `start_date`, `end_date`
     * @param {Object} filterRules
     * @param {Boolean} granular Whether or not we want granularity.
     * @returns {Promise<AxiosResponse>}
     */
    getUsage(organizationID, accountID, parameters = {}, filterRules = {}) {
      const account = typeof accountID === 'object' ? accountID : this.getAccountByID(accountID)

      if (parameters.group_by && !Object.values(API_DIMENSIONS).includes(parameters.group_by)) {
        // remove invalid group by (ex. invalid dimension or provider or account or segment)
        delete parameters.group_by
      }

      return providerAccountsApi.getUsage(organizationID, account.id, parameters, filterRules)
    },

    /**
     * Get list of dimensions
     * @param {*} organizationID
     * @param {*} accountID
     * @param {*} dimension
     * @param {*} countDimension
     * @param {*} filters
     * @param {*} rules
     * @returns
     */
    getDimension(organizationID, accountID, dimension, filters, rules = {}) {
      const account = typeof accountID === 'object' ? accountID : this.getAccountByID(accountID)

      if (filters.group_by && !Object.values(API_DIMENSIONS).includes(filters.group_by)) {
        // remove invalid group by (ex. invalid dimension or provider or account or segment)
        delete filters.group_by
      }

      return new Promise((resolve) => {
        providerAccountsApi
          .getDimension(organizationID, account.id, dimension, filters, rules)
          .then(
            ({ data }) => {
              resolve(data)
            },
            (err) => {
              if (err?.message && err.message !== 'canceled') {
                console.error(`Could not get dimension ${dimension} for account ${account.name}.`)
              }

              resolve([])
            }
          )
      })
    },

    /**
     * Get number of dimensions
     * @param {*} organizationID
     * @param {*} accountID
     * @param {*} dimension
     * @param {*} countDimension
     * @param {*} filters
     * @param {*} rules
     * @returns
     */
    getDimensionCount(organizationID, accountID, dimension, groupBy, filters, rules = {}) {
      const account = typeof accountID === 'object' ? accountID : this.getAccountByID(accountID)

      return new Promise((resolve) => {
        providerAccountsApi
          .getDimensionCount(organizationID, account.id, dimension, groupBy, filters, rules)
          .then(
            ({ data }) => {
              resolve(data)
            },
            (err) => {
              if (err?.message && err.message !== 'canceled') {
                console.error(
                  `Could not get dimension count ${dimension} for account ${account.name}.`
                )
              }

              resolve([])
            }
          )
      })
    },

    /**
     * TODO
     * @param {*} organizationID
     * @param {*} provider
     * @param {*} strict
     * @returns
     */
    getProviderDiagram(organizationID, provider, strict = true) {
      const appendMetadata = (accountID) => {
        return (el) => ({
          ...el,
          accountID,
          provider
        })
      }

      return new Promise((bigResolve, bigReject) => {
        providerAccountsApi
          .getProviderAccounts(organizationID, { provider_name: provider })
          .then(({ data: accounts }) => {
            if (!accounts.length) {
              bigReject(`No matching accounts for provider ${provider}.`)
              return
            }

            const accountsPromises = accounts.map((account) => {
              const { id: accountID } = account
              return new Promise((resolveAccount) => {
                providerAccountsApi
                  .getLastSynchronization(organizationID, accountID)
                  .then(({ data: synchronizations }) => {
                    const [lastSynchronization] = synchronizations
                    // No last synchronization, resolve empty data.
                    if (!lastSynchronization) {
                      resolveAccount(emptyDiagram)
                    } else {
                      providerAccountsApi
                        .getSynchronizationDiagram(
                          organizationID,
                          accountID,
                          lastSynchronization.id
                        )
                        .then(({ data: { diagram } }) => {
                          if (!diagram) {
                            return resolveAccount(emptyDiagram)
                          }
                          const jsonDiagram = JSON.parse(diagram)
                          const { nodes, edges, groups } = jsonDiagram
                          const transformedNodes = nodes.map(appendMetadata(accountID))
                          const transformedEdges = edges.map(appendMetadata(accountID))
                          const transformedGroups = groups.map(appendMetadata(accountID))
                          const allElements = [
                            ...transformedNodes,
                            ...transformedGroups,
                            ...transformedEdges
                          ]
                          let transformedDiagram = JSON.stringify({
                            nodes: transformedNodes,
                            edges: transformedEdges,
                            groups: transformedGroups
                          })
                          // Gather all the IDs of the elements...
                          const allIDs = allElements.map(({ id }) => id)

                          // Then replace them everywhere.
                          for (const id of allIDs) {
                            const transformedID = id + '-' + accountID
                            transformedDiagram = transformedDiagram.replaceAll(id, transformedID)
                          }

                          resolveAccount(JSON.parse(transformedDiagram))
                        })
                    }
                  })
              })
            })

            Promise.allSettled(accountsPromises).then((results) => {
              const diagrams = results.map(({ value }) => value)
              if (!strict) {
                const result = { nodes: [], edges: [], groups: [] }
                for (const diagram of diagrams) {
                  result.nodes = result.nodes.concat(diagram.nodes)
                  result.edges = result.edges.concat(diagram.edges)
                  result.groups = result.groups.concat(diagram.groups)
                }
                bigResolve(result)
              } else {
                const worker = new MergeDiagramsWorker()
                worker.onmessage = function (e) {
                  bigResolve(e.data)
                }
                worker.postMessage(diagrams)
              }
            })
          })
      })
    },

    /**
     * Get AWS resource details.
     * @param {Number} organizationID The ID of the organization.
     * @param {Number} accountID The ID of the provider account.
     * @param {String} resourceID Resource ID from the provider.
     * @returns {Promise<AxiosResponse<any>>}
     */
    awsSearch(organizationID, accountID, resourceID) {
      return providerAccountsApi.awsSearch(organizationID, accountID, resourceID)
    },

    /**
     * Get Azure resource details.
     * @param {Number} organizationID The ID of the organization.
     * @param {Number} accountID The ID of the provider account.
     * @param {String} resourceID Resource ID from the provider.
     * @returns {Promise<AxiosResponse<any>>}
     */
    azureDetails(organizationID, accountID, resourceID) {
      return providerAccountsApi.azureDetails(organizationID, accountID, resourceID)
    },

    /**
     * Get OCI resource details.
     * @param {Number} organizationID The ID of the organization.
     * @param {Number} accountID The ID of the provider account.
     * @param {String} resourceID Resource ID from the provider.
     * @returns {Promise<AxiosResponse<any>>}
     */
    ociSearch(organizationID, accountID, resourceID) {
      return providerAccountsApi.ociSearch(organizationID, accountID, resourceID)
    },

    /**
     * TODO
     * @param {*} skipThumbnail
     * @returns
     */
    loadDemoDetails(skipThumbnail = false) {
      return new Promise((resolve) => {
        // TODO create exampleApi.get() ?
        anonymous_instance.get('/example-infrastructures/aws.json').then(({ data }) => {
          this.setProviderAccount({
            id: 'demo',
            name: 'Demo Account',
            autosync: false
          })
          this.setSynchronizationDiagram(data.diagram)

          if (!skipThumbnail) {
            this.setSynchronizationThumbnail(data.thumbnail)
          }

          this.setSynchronizations([
            {
              imported: moment().format('YYYY-MM-DD')
            }
          ])

          resolve()
        })
      })
    }
  }
})
