import { defineStore } from 'pinia'
import moment from 'moment'

import mappingApi from '@/api/modules/public/mapping'

import { DIMENSIONS } from '@/common/enums.js'

/**
 * Default period is "This month"
 */
const defaultDateRange = [moment().startOf('month'), moment().endOf('month')]

/**
 * TODO
 *
 * @param {*} param0
 * @returns
 */
export function stripAccount({ id, organization_id, name, provider_name }) {
  return { id, organization_id, name, provider_name }
}

const sampleAccount = {
  id: 'demo',
  provider_name: 'aws',
  name: 'Holori Demo AWS'
}

export const defaultSelectedView = {
  name: '',
  rules: {}
}

export const supportedProviders = [
  'aws',
  'azure',
  'gcp',
  's3ns',
  'oci',
  'scaleway',
  'datadog',
  'cloudflare',
  'ovh',
  'focus'
]

const useDashboardStore = defineStore('dashboard', {
  state: () => ({
    datePeriod: '',
    dateRange: defaultDateRange,
    compareDateRange: [],

    allResourcesData: {
      resource_id: [],
      region: [],
      service: [],
      tag: []
    },
    resourcesData: {},
    moreResourcesData: {},

    loading: {
      allResourcesData: false
    },
  }),

  getters: {
    /**
     *
     * @param {*} param0
     * @returns
     */
    getNumberOfDays: ({ dateRange }) => {
      const [start, end] = dateRange.map((d) => moment(d))
      return end.diff(start, 'days') + 1
    },

    /**
     *
     * @param {*} param0
     * @returns
     */
    getDateRange: ({ dateRange }) => {
      return dateRange
    },

    /**
     *
     * @param {*} param0
     * @returns
     */
    comparing: ({ compareDateRange }) => compareDateRange.length === 2
  },

  actions: {
    /**
     *
     * @param {*} period
     */
    setDatePeriod(period) {
      this.datePeriod = period.label
      const [start, end] = period.range.map((m) => m.toDate())
      this.dateRange = [start, end]
    },

    /**
     *
     * @param {*} dateRange
     */
    setDateRange(dateRange) {
      this.datePeriod = ''
      this.dateRange = dateRange
    },

    /**
     *
     * @param {*} compareDateRange
     */
    setCompareDateRange(compareDateRange) {
      this.compareDateRange = compareDateRange
    },

    getAllResourcesSampleData() {
      this.allResourcesData.resource_id = []
      this.loading.allResourcesData = true

      return new Promise((bigResolve) => {
        const promise = new Promise((resolve) => {
          mappingApi.getPublic('product-tour-data/cost-resource.json').then(({ data }) => {
            mappingApi
              .getPublic('product-tour-data/resources-data.json')
              .then(({ data: resourcesData }) => {
                this.resourcesData = resourcesData
                resolve({ provider: sampleAccount.provider_name, account: sampleAccount, data })
              })
          })
        })

        const promises = [promise]

        Promise.allSettled(promises).then(
          this._saveInventoryData(bigResolve, DIMENSIONS.RESOURCE_ID)
        )
      })
    },

    /**
     *
     * @param {*} item
     * @param {*} provider
     * @param {*} account
     * @param {*} groupBy
     * @returns
     */
    getElementLinkToInventory(item, provider, account, groupBy = null) {
      if (!item || provider === 'datadog') {
        return ''
      }

      const query = {}

      if (this.selectedSegment) {
        query.segment = this.selectedSegment
      }

      if (groupBy === DIMENSIONS.ACCOUNT_ID) {
        return {
          name: 'InventoryDashboard',
          query: {
            ...query,
            account: account.id,
            account_id: item
          }
        }
      }

      if (groupBy === DIMENSIONS.SEGMENT) {
        return {
          name: 'InventoryDashboard',
          query: {
            segment: item
          }
        }
      }

      if (groupBy === DIMENSIONS.RESOURCE_ID) {
        return {
          name: 'InventoryResourceDetail',
          params: {
            providerID: account.id,
            resourceID: item
          }
        }
      }

      if (
        [
          DIMENSIONS.SERVICE,
          DIMENSIONS.REGION,
          DIMENSIONS.K8S_CLUSTER,
          DIMENSIONS.K8S_NAMESPACE,
          DIMENSIONS.K8S_WORKLOAD_NAME,
          DIMENSIONS.K8S_WORKLOAD_TYPE
        ].includes(groupBy)
      ) {
        return {
          name: 'InventorySubpage',
          params: {
            type: groupBy,
            provider: provider,
            item: item
          },
          query: {
            ...query,
            by: groupBy.startsWith('k8s_') ? DIMENSIONS.K8S_NAMESPACE : undefined
          }
        }
      }

      return ''
    }
  }
})

export { useDashboardStore }
