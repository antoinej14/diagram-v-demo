import { defineStore } from 'pinia'

import instance from '@/api/index.js'
import mainServerUrl from '@/api/modules/main-server/index.js'

export const useAppStore = defineStore({
  id: 'app',

  state: () => ({
    loading: {
      max: 0,
      val: 0
    },
    selectedCurrency: 'USD',
    conversionRates: {},
    networkErrors: [],
    includeTax: false,
    darkTheme: false
  }),

  getters: {
    currencies: ({ conversionRates }) => {
      const todayDate = new Date().toISOString().split('T', 1)[0]

      const currentConverionRates = conversionRates[todayDate]

      let currencies = ['USD']

      if (currentConverionRates) {
        currencies = currencies.concat(...Object.keys(currentConverionRates))
      }

      return currencies.sort()
    }
  },

  persist: {
    storage: localStorage,
    paths: ['conversionRates', 'includeTax', 'darkTheme', 'selectedCurrency']
  },

  actions: {
    /**
     * TODO
     */
    resetLoading() {
      this.loading = {
        max: 0,
        val: 0
      }
    },

    /**
     * TODO
     *
     * @param {*} inc
     */
    increaseMaxLoading(inc = 1) {
      this.loading.max += inc
    },

    /**
     * TODO
     *
     * @param {*} inc
     */
    increaseValLoading(inc = 1) {
      this.loading.val += inc
    },

    /**
     * TODO
     *
     * @param {*} date
     * @returns
     */
    loadConversionRates(date = null) {
      if (!date) {
        date = new Date().toISOString().split('T', 1)[0]
      }

      return new Promise((resolve, reject) => {
        // We already have the conversion rates, resolve them directly.
        if (date in this.conversionRates && this.conversionRates[date]) {
          return resolve(this.conversionRates[date])
        }

        instance.post(mainServerUrl + `conversion_rates?date=${date}`).then(
          ({ data }) => {
            this.conversionRates[date] = data
            resolve(data)
          },
          () => reject('Could not load conversion rates.')
        )
      })
    },

    /**
     * Convert a value from one currency to another
     *
     * We use an intermediate USD value as
     * conversion rates are from USD to a X currency
     *
     * @param {*} value
     * @param {*} fromCurrency
     * @param {*} date
     * @returns
     */
    async convertCurrency(value, fromCurrency, date) {
      const { conversionRates, selectedCurrency } = this

      // ensure value is correct
      if (!value) {
        value = 0
      }

      // if no currency given, assume it is USD
      fromCurrency = fromCurrency || 'USD'

      if (fromCurrency === selectedCurrency) {
        // no conversion needed
        return value
      }

      // if no date given, or a future one, make it yesterday instead
      const yesterday = new Date()

      yesterday.setDate(yesterday.getDate() - 1)

      if (!date || date > yesterday.toISOString().split('T', 1)[0]) {
        date = yesterday.toISOString().split('T', 1)[0]
      }

      switch (date.length) {
        case 4:
          // "year"
          // use last day of the last month of the year
          date += '-12-31'
          break
        case 7:
          // "year-mm"
          // use last day of the month
          date = new Date(+date.split('-')[0], +date.split('-')[1]).toISOString().split('T', 1)[0]
          break
        case 10:
          // "year-mm-dd"
          // this is OK
          break
        default:
          console.error('invalid date as parameter for loadConversionRate', date)
          return
      }

      if (!(date in conversionRates)) {
        await this.loadConversionRates(date)
      }

      if (!(date in conversionRates)) {
        // not loaded, give up and return original value
        console.error('unable to loadConversionRate for', date)
        return value
      }

      // find the conversion rate from fromCurrency to USD
      let rateToUSD = 1 // by default assume it is USD

      if (fromCurrency !== 'USD') {
        // not already USD, try to find the rate to USD
        rateToUSD = conversionRates[date][fromCurrency] || 1
      }

      if (rateToUSD == null) {
        // undefined rate
        console.error('unable to loadConversionRate for source', fromCurrency, 'at', date)
        delete conversionRates[date]
        return value
      }

      const valueInUSD = value / rateToUSD

      // find the conversion rate from USD to SelectedCurrency
      let rateToSelectedCurrency = 1

      if (selectedCurrency !== 'USD') {
        rateToSelectedCurrency = conversionRates[date][selectedCurrency]
      }

      if (rateToSelectedCurrency == null) {
        // undefined rate
        console.error('unable to loadConversionRate for selected', selectedCurrency, 'at', date)
        delete conversionRates[date]
        return valueInUSD
      }

      const valueInSelectedCurrency = valueInUSD * rateToSelectedCurrency

      console.debug(
        'converting',
        value,
        fromCurrency,
        'at',
        date,
        'rate (',
        rateToSelectedCurrency,
        '), result :',
        valueInSelectedCurrency,
        selectedCurrency
      )

      return valueInSelectedCurrency
    },

    /**
     * Generate a label for a (number) value.
     *
     * @param {*} value
     * @returns
     */
    makeNumberLabel(value) {
      function makeFormatterNumber() {
        return new Intl.NumberFormat(undefined, {
          maximumFractionDigits: 2
        })
      }

      return makeFormatterNumber().format(value)
    },

    /**
     * Generate a label for a percentage value.
     *
     * @param {*} value
     * @returns
     */
    makePercentageLabel(value) {
      function makeFormatterPercentage() {
        return new Intl.NumberFormat(undefined, {
          maximumFractionDigits: 2,
          style: 'percent'
        })
      }

      return makeFormatterPercentage().format(value)
    },

    /**
     * Generate a label for a value with currency.
     *
     * @param {*} amount
     * @returns
     */
    makeCurrencyLabel(amount) {
      const { selectedCurrency } = this

      function makeFormatterSelectedCurrency() {
        return new Intl.NumberFormat(undefined, {
          maximumFractionDigits: 2,
          style: 'currency',
          currency: selectedCurrency,
          currencyDisplay: 'narrowSymbol'
        })
      }

      return makeFormatterSelectedCurrency().format(amount)
    },

    /**
     * TODO
     *
     * @param {*} selectedCurrency
     */
    setSelectedCurrency(selectedCurrency) {
      this.selectedCurrency = selectedCurrency
    },

    /**
     * Generate a label for an usage with an unit.
     *
     * @param {*} amount
     * @param {*} unit
     * @returns
     */
    makeUsageLabel(amount, unit) {
      function makeUsageFormatter() {
        return new Intl.NumberFormat(undefined, {
          maximumFractionDigits: 2,
          style: 'decimal' // because the units we get are never standards ...
        })
      }

      return `${makeUsageFormatter().format(amount)} ${unit || ''}`
    }
  }
})
