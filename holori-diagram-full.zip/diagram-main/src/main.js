import { createApp } from 'vue'

import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'

import Oruga from '@oruga-ui/oruga-next'
import { bulmaConfig } from '@oruga-ui/theme-bulma'

import './css/dropdown-utils.css'
import './css/joint.css'
import './css/main.css'
import './css/mdi.css'
import './css/transitions.css'
import './holori.customize.scss'

import '@joint/plus/joint-plus.css'

import App from './App.vue'
import router from './router'

import { setupCurrentUser, setupInterceptor } from '@/api/interceptor'

import keyboardShortcutDirective from '@/common/keyboard-shortcut-directive'

import moment from 'moment'

import posthogPlugin from './plugins/posthog'

const orugaConfig = Object.assign(bulmaConfig, {
  modal: {
    ...bulmaConfig.modal,
    canCancel: ['escape', 'outside', 'button']
  }
})

// TODO: Change this according to the user's locale.
// Reminder: `dow` is an Integer, representing the first day of the week.
// `1` means Monday, `0` means Sunday.
const USER_LOCALE = new Intl.NumberFormat().resolvedOptions().locale.substring(0, 2)

moment.locale(USER_LOCALE)
moment.updateLocale(moment.locale(), {
  week: {
    dow: 1
  }
})

window.abortControllers = {}
window.cancelledRequests = []

const app = createApp(App)

const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)
app.use(pinia)

setupInterceptor()
await setupCurrentUser()

app.use(router)
app.use(Oruga, orugaConfig)

if (import.meta.env.PROD && location.hostname === 'app.holori.com') {
  app.use(posthogPlugin)

  await import('crisp-sdk-web').then(({ Crisp }) => {
    Crisp.configure(import.meta.env.VITE_CRISP_WEBSITE_ID)
  })
}

app.directive('keyboard-shortcut', keyboardShortcutDirective)

app.mount('#app')
