<script setup>
import { RouterView, useRoute } from 'vue-router'
import { useOrganizationStore } from '@/store/organization.js'
import { computed } from 'vue'

const props = defineProps({
  organizationID: {
    type: Number,
    required: true
  }
})

const route = useRoute()

const organizationStore = useOrganizationStore()

const isPayingOrganization = computed(
  () => organizationStore.getCurrentOrganization && organizationStore.isOrganizationAllowed
)

const isInProjects = computed(() => route.name.startsWith('Projects'))
</script>

<template>
  <RouterView v-if="isPayingOrganization || isInProjects" v-slot="{ Component }">
    <component :is="Component" :organizationID="props.organizationID" />
  </RouterView>
</template>
