<script setup>
import { computed, ref } from 'vue'
import moment from 'moment'
import {
  OButton,
  ODropdown,
  ODropdownItem,
  OIcon,
  OInput,
  OModal,
  OSkeleton,
  OTable,
  OTableColumn,
  OTooltip,
  useOruga
} from '@oruga-ui/oruga-next'
import { useDashboardStore } from '@/store/dashboard.js'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import CreateBusinessMetric from '@/components/modal/BusinessMetric.vue'
import ConfirmationModal from '@/components/modal/Confirmation.vue'
import { useMixins } from '@/common/mixins.js'
import { SEGMENT_SEPARATOR } from '@/common/cost-allocation/tree-view.js'

const oruga = useOruga()
const { organizationID } = useOrganizationMembership(loadData)
const { toast } = useMixins()

const query = ref('')

const views = ref({})

const defaultBusinessMetric = {
  name: '',
  metrics: {
    metrics: [],
    views: [],
    unit_scale: ''
  }
}

const createBusinessMetricOpen = ref(false)
const selectedBusinessMetric = ref(defaultBusinessMetric)

const dashboardStore = useDashboardStore()

const businessMetrics = computed(() =>
  dashboardStore.businessMetrics.filter((tag) =>
    tag.name.toLowerCase().includes(query.value.toLowerCase())
  )
)

function createBusinessMetric() {
  dashboardStore.loadFilters(organizationID)
  selectedBusinessMetric.value = defaultBusinessMetric
  createBusinessMetricOpen.value = true
}

function loadData() {
  dashboardStore.getBusinessMetrics(organizationID).then((newBusinessMetrics) => {
    const viewNames = new Set()
    for (const businessMetric of newBusinessMetrics) {
      for (const viewName of businessMetric.metrics.views) {
        viewNames.add(viewName)
      }
    }

    for (const viewName of viewNames) {
      dashboardStore.getFilter(organizationID, viewName).then(
        ({ data }) => {
          views.value[viewName] = data
        },
        () => {
          views.value[viewName] = null
        }
      )
    }
  })
}

function editBusinessMetric(businessMetric) {
  selectedBusinessMetric.value = {
    ...businessMetric,
    metrics: {
      ...businessMetric.metrics,
      metrics: businessMetric.metrics.metrics.map(({ date, value }) => ({
        date: new Date(date),
        value
      }))
    }
  }
  createBusinessMetricOpen.value = true
}

async function deleteBusinessMetric(businessMetric) {
  const { id, name } = businessMetric
  const message = `The business metric "${name}" will be deleted.`

  const instance = oruga.modal.open({
    component: ConfirmationModal,
    props: {
      title: 'Deleting business metric',
      message,
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Delete',
      yesIcon: 'delete',
      invertColors: true
    },
    trapFocus: true
  })
  const result = await instance.promise
  if (result === true) {
    dashboardStore.deleteBusinessMetric(organizationID, id).then(
      () => {
        toast({
          variant: 'success',
          message: 'Business metric deleted.'
        })
        loadData()
      },
      () => {
        toast({
          variant: 'warning',
          message: 'Could not delete business metric.'
        })
      }
    )
  }
}

function finishCreateBusinessMetric(load) {
  createBusinessMetricOpen.value = false

  if (load) {
    loadData()
  }
}

function formatDate(date) {
  return moment(date).format('MMM DD, YYYY HH:mm:ss')
}

function rowClick(row, cell) {
  if (cell.field === 'name') {
    editBusinessMetric(row)
  }
}

function goToCostDashboardWithView(view) {
  return {
    name: 'CostDashboard',
    query: {
      view
    }
  }
}

function goToCostDashboardWithSegment(segment) {
  return {
    name: 'CostDashboard',
    query: {
      segment
    }
  }
}
</script>

<template>
  <main class="p-5">
    <o-modal v-model:active="createBusinessMetricOpen" @close="createBusinessMetricOpen = false">
      <CreateBusinessMetric
        v-if="createBusinessMetricOpen"
        v-model="selectedBusinessMetric"
        @close="finishCreateBusinessMetric"
      />
    </o-modal>

    <div class="is-flex is-align-items-center is-justify-content-space-between is-gap-5 mb-5">
      <div>
        <p class="is-size-5 mb-3">Business Metrics</p>
        <p>Assign business metrics to views to see unit cost.</p>
      </div>

      <o-button variant="primary" icon-left="plus" @click="createBusinessMetric"
        >New business metrics</o-button
      >
    </div>

    <section class="p-5 has-background-white is-border-radius-md">
      <o-input
        v-model="query"
        class="mb-5"
        type="search"
        icon="magnify"
        placeholder="Search by name, creator"
        rounded
        clearable
      />

      <o-table :data="businessMetrics" hoverable @cell-click="rowClick">
        <template #empty>
          <p class="has-text-centered p-5">No business metrics.</p>
        </template>

        <o-table-column
          v-slot="{ row }"
          field="name"
          label="Name"
          :td-attrs="() => ({ class: 'is-clickable clickable-table-row' })"
        >
          {{ row.name }}
        </o-table-column>
        <o-table-column v-slot="{ row }" field="assigned_views" label="Assigned views">
          <span class="is-flex is-align-items-center is-gap-1">
            <span
              v-for="viewName in row.metrics.views"
              :key="viewName"
              class="view-name is-inline-flex is-align-items-center"
            >
              <o-skeleton v-if="!(viewName in views)" width="50" />
              <template v-else>
                <o-tooltip
                  v-if="views[viewName] !== null"
                  label="Go to cost dashboard with this view"
                >
                  <router-link
                    :to="goToCostDashboardWithView(viewName)"
                    class="is-inline-flex is-align-items-center is-gap-2"
                  >
                    <o-icon icon="layers-triple-outline" size="small" />
                    {{ viewName }}
                  </router-link>
                </o-tooltip>
                <o-tooltip v-else label="Missing view">
                  <o-icon icon="alert" size="small" />
                </o-tooltip>
              </template>
            </span>
          </span>
        </o-table-column>
        <o-table-column v-slot="{ row }" field="segment" label="Assigned segment">
          <o-tooltip
            v-if="row.metrics.segment"
            label="Go to Cost Dashboard with this segment"
            position="top"
          >
            <router-link
              :to="goToCostDashboardWithSegment(row.metrics.segment)"
              class="is-inline-flex is-align-items-center is-gap-2"
            >
              <o-icon icon="share-variant-outline" size="small" />
              {{ row.metrics.segment.replaceAll(SEGMENT_SEPARATOR, ' / ') }}
            </router-link>
          </o-tooltip>
        </o-table-column>
        <o-table-column v-slot="{ row }" field="created" label="Created">
          {{ formatDate(row.created) }}
        </o-table-column>
        <o-table-column v-slot="{ row }" field="last_updated" label="Last updated">
          {{ row.last_modified ? formatDate(row.last_modified) : '' }}
        </o-table-column>
        <o-table-column v-slot="props" width="30">
          <o-dropdown position="bottom-right" teleport>
            <template #trigger>
              <o-button
                variant="secondary"
                class="px-3"
                icon-left="dots-horizontal"
                size="small"
                rounded
              />
            </template>

            <o-dropdown-item @click="editBusinessMetric(props.row)"> Edit</o-dropdown-item>
            <o-dropdown-item class="has-text-danger" @click="deleteBusinessMetric(props.row)">
              Delete
            </o-dropdown-item>
          </o-dropdown>
        </o-table-column>
      </o-table>
    </section>
  </main>
</template>

<style scoped>
.view-name:not(:last-child):after {
  content: ', ';
}
</style>
