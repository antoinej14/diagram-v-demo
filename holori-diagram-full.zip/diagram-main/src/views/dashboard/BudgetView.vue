<script setup>
import { computed, nextTick, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { OButton, OTabItem, OTabs, OTooltip, useOruga } from '@oruga-ui/oruga-next'
import moment from 'moment'

import BudgetSummary from '@/components/budget/Summary.vue'
import BudgetValuesGraph from '@/components/budget/BudgetValuesGraph.vue'
import AllBudgetsTable from '@/components/budget/AllBudgetsTable.vue'
import CreateBudgetModal from '@/components/modal/CreateBudget.vue'
import MonthSelector from '@/components/MonthSelector.vue'
import ConfirmationModal from '@/components/modal/Confirmation.vue'

import { useOrganizationMembership } from '@/common/organization-membership.js'
import { useMixins } from '@/common/mixins.js'
import { GRANULARITIES } from '@/common/enums.js'
import { SEGMENT_SEPARATOR, useCostAllocationTreeView } from '@/common/cost-allocation/tree-view.js'
import { hierarchyToJoint } from '@/common/cost-allocation/hierarchy-to-joint.js'
import { constructTreeFromReports } from '@/common/cost-allocation/joint-to-hierarchy.js'
import { REQUEST } from '@/common/cost-dashboard/dates.js'

import { useCostAllocationStore } from '@/store/cost-allocation.js'
import { useBudgetStore } from '@/store/budget.js'
import { useAppStore } from '@/store/app'

const route = useRoute()
const oruga = useOruga()

const { organizationID } = useOrganizationMembership(load)
const { updateQueryJS, toast } = useMixins()

const appStore = useAppStore()
const budgetStore = useBudgetStore()
const costAllocationStore = useCostAllocationStore()

const periodType = ref(route.query.periodType ? route.query.periodType : 'monthly')
const period = ref(moment.utc(route.query.period || new Date()).toDate())

const displayedTab = ref('all')
const loading = ref(true)

const jointData = ref({})
const treeViewRef = ref(null)

const { init, clear, performLayout } = useCostAllocationTreeView({
  treeViewRef,
  loadingRef: loading,
  onSegmentClick: (path) => {
    if (path) {
      editBudget(path, true)
    }
  }
})

const simpleBudgets = ref([])
const segmentBudgets = ref([])

const segments = ref(null)
const flattenUsedSegments = computed(() => {
  const segmentArray = []

  function flattenChildren(children) {
    let childrenArray = []

    for (const child of children) {
      // add this one if it has a budget
      if (child.budget) {
        childrenArray.push(child)
      }

      childrenArray = childrenArray.concat(flattenChildren(child.segments))
    }

    return childrenArray
  }

  // add root segment if it has a budget
  if (segments.value.budget) {
    segmentArray.push(segments.value)
  }

  // add its children
  return segmentArray.concat(flattenChildren(segments.value.segments))
})

const periodTarget = computed(() => {
  switch (periodType.value) {
    case GRANULARITIES.YEARLY:
      return 'year'

    case GRANULARITIES.MONTHLY:
      return 'month'
  }

  return null
})

const periodStart = computed(() => {
  const m = moment(period.value).startOf(periodTarget.value)

  return m.toDate()
})

const periodEnd = computed(() => {
  const m = moment(period.value).endOf(periodTarget.value)

  return m.toDate()
})

const startDate = computed(() => moment(periodStart.value).format(REQUEST))

const endDate = computed(() => moment(periodEnd.value).format(REQUEST))

const numberOfMonth = computed(
  () => moment(periodEnd.value).diff(moment(periodStart.value), 'month') + 1
)

const allBudgets = computed(() => [...simpleBudgets.value, ...segmentBudgets.value])

const summaryBudgetData = computed(() => {
  const summaryBudgets = [...simpleBudgets.value]

  // only grab the root segment
  if (segments.value) {
    summaryBudgets.push(segments.value?.budget || 0)
  }

  return summaryBudgets
})

async function newBudget(budget = null) {
  const instance = oruga.modal.open({
    component: CreateBudgetModal,
    trapFocus: true,
    props: {
      budget: budget,
      segments: flattenUsedSegments.value
    }
  })

  const result = await instance.promise

  if (result === true) {
    load()
  }
}

// TODO allow to edit a particular month budget ?
function editBudget(name, segment = false) {
  budgetStore
    .getBudgetsGroupedByName(organizationID, name)
    .then(async (budget) => {
      const instance = oruga.modal.open({
        component: CreateBudgetModal,
        trapFocus: true,
        props: {
          budget: budget,
          segments: flattenUsedSegments.value,
          edit: true
        }
      })

      const result = await instance.promise

      if (result === true) {
        load()
      }
    })
    .catch(() => {
      console.info('this budget does not exists, creating a new one instead')
      newBudget({
        name,
        type: segment ? 'segment' : 'simple',
        mode: 'recurring'
      })
    })
}

async function deleteBudget(name) {
  const instance = oruga.modal.open({
    component: ConfirmationModal,
    trapFocus: true,
    props: {
      title: 'Deleting budget',
      message: `Do you want to delete the budget "${name}"?`,
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Delete',
      yesIcon: 'delete',
      invertColors: true
    }
  })

  const result = await instance.promise

  if (result === true) {
    budgetStore.deleteBudgetsByName(organizationID, name).then(
      () => {
        toast({
          variant: 'success',
          message: `Budget "${name}" was successfully deleted.`
        })

        load()
      },
      (err) => {
        toast({
          variant: 'warning',
          message: `Error while deleting budget "${name}": ${err}`
        })
      }
    )
  }
}

function* getMonthDates() {
  const loopMonth = new Date(periodStart.value)

  while (loopMonth <= periodEnd.value) {
    yield new Date(loopMonth)

    loopMonth.setMonth(loopMonth.getMonth() + 1)
  }
}

async function loadSimpleBudgets() {
  simpleBudgets.value = []

  const filters = {
    type: 'simple'
  }

  // load first recurring budgets
  filters['is_recurrent'] = true

  appStore.increaseMaxLoading()
  const recurringBudgets = await budgetStore.getBudgets(organizationID, filters)
  appStore.increaseValLoading()

  appStore.increaseMaxLoading(recurringBudgets.length)

  // get cost for each budget
  const promises = []
  for (const entry of recurringBudgets) {
    // mulitply the month threshold by number of month
    entry.threshold *= numberOfMonth.value

    // get cost for the period
    promises.push(
      budgetStore
        .getBudgetCost(organizationID, entry, startDate.value, endDate.value)
        .finally(() => appStore.increaseValLoading())
    )
  }

  for (const promise of promises) {
    await promise
  }

  // load monthly budgets
  filters['is_recurrent'] = false

  const dates = getMonthDates()
  let monthBudgets = []
  const budgets = {}

  // iterate over target months
  appStore.increaseMaxLoading(dates.length)
  for (const date of dates) {
    filters['target_month'] = moment(date).format(REQUEST)

    const results = await budgetStore.getBudgets(organizationID, filters)
    appStore.increaseValLoading()

    // get cost for each budget
    for (const entry of results) {
      if (entry.name in budgets) {
        budgets[entry.name].threshold += entry.threshold

        if (entry.target_month < budgets[entry.name].startDate) {
          budgets[entry.name].startDate = entry.target_month
        }

        if (entry.target_month > budgets[entry.name].endDate) {
          budgets[entry.name].endDate = entry.target_month
        }
      } else {
        budgets[entry.name] = {
          ...entry,
          startDate: entry.target_month,
          endDate: entry.target_month
        }
      }
    }

    monthBudgets = [...monthBudgets, ...results]
  }

  appStore.increaseMaxLoading(Object.keys(budgets).length)
  for (const budgetName in budgets) {
    const budget = budgets[budgetName]

    // budget startDate is always start of a month
    const startDate = budget.startDate

    // we need to grab the last day of the month as endDate
    const endDate = moment(budget.endDate).endOf('month').toDate().toISOString().split('T', 1)[0]

    // get cost for the period
    await budgetStore.getBudgetCost(organizationID, budget, startDate, endDate)
    appStore.increaseValLoading()
  }

  simpleBudgets.value = [...recurringBudgets, ...Object.values(budgets)]
}

async function loadCostAllocations() {
  segments.value = null

  let reports = await costAllocationStore.getReports(organizationID, {
    target_month_since: startDate.value,
    target_month_until: endDate.value
  })

  if (!reports || reports.length < 1) {
    console.warn('no report for this period, trying to get a previous one')

    const previousReport = await costAllocationStore.getReportOrPrevious(
      organizationID,
      endDate.value
    )

    if (!previousReport) {
      segments.value = null

      return
    }

    reports = [previousReport]
  }

  segments.value = constructTreeFromReports(reports)
}

async function loadSegmentBudgets() {
  segmentBudgets.value = []

  // we allow only recurring budget for segments
  const filters = {
    type: 'segment',
    is_recurrent: true
  }

  appStore.increaseMaxLoading(2)

  const budgetResults = await budgetStore.getBudgets(organizationID, filters)
  appStore.increaseValLoading()

  await loadCostAllocations()
  appStore.increaseValLoading()

  function findSegment(segment, path, budget) {
    if (!segment) {
      // no segment
      return null
    }

    if (segment.name == path) {
      // found, this is this segment

      // write segment cost in budget
      budget.cost = segment.cost

      // remember segment into the budget
      budget.segment = segment

      // save budget value in segment
      segment.threshold = budget.threshold

      // remember budget in segment
      segment.budget = budget

      return segment
    }

    // not this segment, but maybe it is a parent
    const pathStart = segment.name + SEGMENT_SEPARATOR

    if (!path.startsWith(pathStart)) {
      // this segment is not a correct parent for this path
      return null
    }

    // this is a valid parent
    // try to find the correct segment in children
    const childrenPath = path.substring(pathStart.length)

    for (const child of segment.segments) {
      // keep searching by descending in child segment
      const found = findSegment(child, childrenPath, budget)

      if (found) {
        // found in children

        // add the child budget to the parent
        segment.threshold = (segment.threshold || 0) + found.threshold

        // return found segment
        return found
      }
    }

    // not found
    return null
  }

  // get cost for each budget
  for (const entry of budgetResults) {
    // mulitply the month threshold by number of month
    entry.threshold *= numberOfMonth.value

    // budget name is its path
    entry.path = entry.name

    // find related segment
    const found = findSegment(segments.value, entry.path, entry)

    if (!found) {
      // set cost to 0 if null
      entry.cost = entry?.cost || 0

      console.warn('this segment does not exist', entry.name)
    }
  }

  segmentBudgets.value = [...budgetResults]

  jointData.value = hierarchyToJoint(segments.value)
}

async function load() {
  appStore.resetLoading()
  loading.value = true

  appStore.increaseMaxLoading(2)

  await loadSimpleBudgets()
  appStore.increaseValLoading()

  await loadSegmentBudgets()
  appStore.increaseValLoading()

  loading.value = false

  if (displayedTab.value === 'hierarchical') {
    displayHierarchicalBudgets()
  }
}

function displayHierarchicalBudgets() {
  clear()

  setTimeout(() => {
    window.scrollTo({
      top: treeViewRef.value.getBoundingClientRect().top,
      behavior: 'smooth'
    })

    init(jointData.value, false)

    setTimeout(() => {
      performLayout()
    }, 200)
  }, 50)
}

watch(period, () => {
  updateQueryJS({ period: moment(period.value).format(REQUEST) })

  load()
})

watch(periodType, (newVal) => {
  updateQueryJS({ periodType: newVal })
})

watch(displayedTab, (newVal) => {
  if (newVal === 'hierarchical') {
    nextTick(() => displayHierarchicalBudgets())
  }
})
</script>

<template>
  <main class="p-5 is-flex is-flex-direction-column is-gap-5">
    <div class="is-flex is-justify-content-space-between">
      <div class="is-flex is-gap-5">
        <div class="is-flex">
          <o-button
            :variant="periodType === GRANULARITIES.MONTHLY ? 'primary' : 'secondary'"
            class="is-border-left-radius-full is-border-right-radius-none"
            @click="periodType = GRANULARITIES.MONTHLY"
          >
            Monthly
          </o-button>
          <o-button
            :variant="periodType === GRANULARITIES.YEARLY ? 'primary' : 'secondary'"
            class="is-border-right-radius-full is-border-left-radius-none ml-_1"
            @click="periodType = GRANULARITIES.YEARLY"
          >
            Yearly
          </o-button>
        </div>

        <MonthSelector v-model="period" :limit="false" :type="periodType" />
      </div>

      <o-tooltip label="Create a new budget" position="left">
        <o-button variant="primary" icon-left="plus" @click="newBudget" :disabled="loading">
          Create new budget
        </o-button>
      </o-tooltip>
    </div>

    <BudgetSummary v-model="summaryBudgetData" :loading="loading" />

    <div class="is-flex is-gap-5" v-if="displayedTab == 'all'">
      <BudgetValuesGraph v-model="allBudgets" :loading="loading" class="is-flex-1" />
    </div>

    <o-tabs v-model="displayedTab" content-class="has-background-white is-border-bottom-radius-md">
      <o-tab-item
        value="all"
        label="All budgets"
        item-header-class="is-border-top-radius-md p-4"
        item-header-active-class="tab-active-"
      >
        <AllBudgetsTable
          :loading="loading"
          :data="allBudgets"
          @edit-budget="editBudget"
          @delete-budget="deleteBudget"
        />
      </o-tab-item>

      <o-tab-item value="hierarchical" label="Hierarchical budgets">
        <p class="has-text-centered has-text-weight-bold mb-3">
          Costs according to your allocation rules &amp; Budget
        </p>

        <div ref="treeViewRef" class="tree-view" />
      </o-tab-item>
    </o-tabs>
  </main>
</template>

<style scoped>
.tree-view {
  height: 72vh;
}
</style>
