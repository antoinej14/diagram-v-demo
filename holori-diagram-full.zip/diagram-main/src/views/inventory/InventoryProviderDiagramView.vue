<script setup>
import { computed, ref } from 'vue'
import { storeToRefs } from 'pinia'
import { OSwitch } from '@oruga-ui/oruga-next'

import { useProviderAccountsStore } from '@/store/provider-accounts.js'
import { useDiagramStore } from '@/store/diagram.js'

import { useOrganizationMembership } from '@/common/organization-membership.js'
import readG6Diagram from '@/common/diagram/options/methods/read.js'
import { performLayout } from '@/common/diagram/options/methods/layout.js'
import exportData from '@/common/diagram/options/methods/export.js'
import { useMixins } from '@/common/mixins.js'

import { useZoom } from '@/components/diagram/hooks/zoom.js'
import { useInitDiagram } from '@/components/diagram/hooks/init.js'
import DiagramDetails from '@/components/diagram/Details.vue'
import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import Diagram3DView from '@/components/diagram/Diagram3DView.vue'
import { useHighlight } from '@/components/diagram/hooks/highlight.js'

const props = defineProps({
  provider: {
    type: String,
    required: true
  }
})

const { organizationID } = useOrganizationMembership(load)
const { toast, notFound } = useMixins()

const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()

const loading = ref(true)
const leftPanelVisible = ref(true)
const rightPanelVisible = ref(true)
const use3dView = ref(false)

const canvasRef = ref(null)
const leftSidebarRef = ref(null)

const { getGlobalSelectionCount } = storeToRefs(diagramStore)

const detailsVisible = computed(() => getGlobalSelectionCount.value > 0 && rightPanelVisible.value)

const { zoomIn, zoomOut } = useZoom()
const { initDiagram } = useInitDiagram({
  canvasRef,
  zoomIn,
  zoomOut
})
const { highlight, removeHighlight } = useHighlight(loading)

function load() {
  window.lockedMode = true

  providerAccountsStore.getProviderDiagram(organizationID, props.provider).then(
    (diagram) => {
      initDiagram()

      const { graph, paper } = window

      readG6Diagram(diagram, graph, paper)
      performLayout(graph)
      diagramStore.setData(exportData(graph.toJSON().cells))
      paper.unfreeze()

      leftSidebarRef.value.reloadResources()

      highlight()
    },
    (error) => {
      toast({
        variant: 'warning',
        message: error
      })
      notFound()
    }
  )
}
</script>

<template>
  <section class="hero full-height">
    <o-loading v-model:active="loading" full-page />

    <div v-if="!loading" class="use-3d-view has-background-white is-absolute p-3">
      <o-switch v-model="use3dView">Use 3D view</o-switch>
    </div>

    <div v-show="!use3dView" key="not-3d">
      <div
        id="canvas"
        ref="canvasRef"
        class="is-absolute canvas"
        :class="{ 'canvas--loading': loading }"
      />
      <DiagramLeftSidebar
        ref="leftSidebarRef"
        :visible="leftPanelVisible"
        visualize-mode
        :adding-node="''"
        @toggle-visibility="leftPanelVisible = !leftPanelVisible"
      />
      <DiagramDetails
        :visible="detailsVisible"
        tab="terraform"
        disabled
        hide-style
        hide-project
        @toggle-visibility="rightPanelVisible = !rightPanelVisible"
      />
    </div>
    <Diagram3DView v-if="use3dView" key="is-3d" :provider="props.provider" />
  </section>
</template>

<style scoped>
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: calc(100vh - var(--navbar-height));
  transition: opacity 0.2s ease;
}

.canvas--loading {
  opacity: 0;
}

.use-3d-view {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  right: 0;
  z-index: 2;
}
</style>
