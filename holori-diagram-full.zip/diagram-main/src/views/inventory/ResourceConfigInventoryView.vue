<script setup>
import { computed, nextTick, ref, watch } from 'vue'
import { OInput } from '@oruga-ui/oruga-next'

import { useProviderAccountsStore } from '@/store/provider-accounts.js'

import { useOrganizationMembership } from '@/common/organization-membership.js'

import InfrastructureViewBreadcrumbs from '@/components/inventory/Breadcrumbs.vue'
import AccountsFilter from '@/components/recommendations/AccountsFilter.vue'
import ExportListView from '@/components/diagram/export/ExportListView.vue'

const { organizationID } = useOrganizationMembership(load)

const allDiagrams = ref([])
const allAccounts = ref({})
const selectedAccounts = ref([])
const query = ref('')

const detailsRef = ref(null)

const allItems = computed(() => {
  const groups = {}
  const nodes = {}

  for (const diagram of allDiagrams.value) {
    if (selectedAccounts.value.length === 0 || selectedAccounts.value.includes(diagram.account)) {
      for (const group of diagram.groups) {
        const { id } = group
        if (!(id in groups)) {
          groups[id] = group
        }
      }

      for (const node of diagram.nodes) {
        const { id } = node
        if (!(id in nodes)) {
          nodes[id] = node
        }
      }
    }
  }

  return {
    edges: [],
    nodes: Object.values(nodes),
    groups: Object.values(groups)
  }
})

const flatten = (values) => {
  let result = []

  for (const val of values) {
    if (typeof val === 'object') {
      result.push(flatten(Object.values(val)))
      result.push(flatten(Object.keys(val)))
    } else if (Array.isArray(val)) {
      result.push(val)
    } else {
      result.push(val)
    }
  }

  return result.join(' ')
}

const filteredItems = computed(() => {
  const s = query.value.toLowerCase()
  const all = allItems.value

  if (s.length < 3) {
    return all
  }

  const filter = (item) => {
    const flat = flatten(
      Object.values({
        name: item.name,
        path: item.path,
        terraform: item.terraform
      })
    )

    return flat.toLowerCase().includes(s)
  }

  return {
    groups: all.groups.filter(filter),
    nodes: all.nodes.filter(filter)
  }
})

const providerAccountsStore = useProviderAccountsStore()

function jsonExport() {
  const { nodes, groups } = allItems.value
  const all = [...nodes, ...groups].map((item) => ({
    id: item.name,
    ...item.terraform
  }))

  const str = JSON.stringify(all, null, 2)
  const url = window.URL.createObjectURL(new Blob([str]))
  const a = document.createElement('a')
  a.setAttribute('download', 'export.json')
  a.setAttribute('href', url)
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  window.URL.revokeObjectURL(url)
}

function load() {
  providerAccountsStore.getProviderAccounts(organizationID, { enabled: true }).then((accounts) => {
    for (const account of accounts) {
      const { provider_name } = account
      if (!(provider_name in allAccounts.value)) {
        allAccounts.value[provider_name] = []
      }
      allAccounts.value[provider_name].push(account)
    }

    const promises = accounts.map(
      (account) =>
        new Promise((resolve) => {
          providerAccountsStore.getLastSynchronization(organizationID, account.id).then((sync) => {
            if (!sync) {
              return resolve({ account: account.id, groups: [], nodes: [] })
            }

            providerAccountsStore
              .getSynchronizationDiagram(organizationID, account.id, sync.id)
              .then((diagram) => {
                const { groups, nodes } = JSON.parse(diagram)
                resolve({ account: account.id, groups, nodes })
              })
          })
        })
    )

    Promise.allSettled(promises).then((results) => {
      allDiagrams.value = results.map(({ value }) => value)
    })
  })
}

watch(filteredItems, () => {
  nextTick(() => {
    detailsRef.value.load()
  })
})
</script>

<template>
  <section class="is-flex is-flex-direction-column p-5 is-gap-5">
    <InfrastructureViewBreadcrumbs />

    <AccountsFilter v-model="selectedAccounts" :accounts="allAccounts" />

    <div class="is-flex is-gap-3">
      <o-input
        v-model="query"
        root-class="is-flex-1"
        type="text"
        placeholder="Search by name, service"
        icon="magnify"
        clearable
        rounded
      />
      <o-button variant="secondary" icon-left="export-variant" @click="jsonExport">
        JSON export
      </o-button>
    </div>

    <ExportListView
      ref="detailsRef"
      data-source="props"
      :data="filteredItems"
      :select-first="false"
    />
  </section>
</template>
