<script setup>
import { ref, onMounted } from 'vue'
import { useOrganizationMembership } from '@/common/organization-membership'
import ProviderAccountCard from '@/components/ProviderAccountCard.vue'
import { OSkeleton } from '@oruga-ui/oruga-next'
import { useProviderAccountsStore } from '@/store/provider-accounts.js'
import { storeToRefs } from 'pinia'
import { useMappingStore } from '@/store/mapping.js'

const { organizationID } = useOrganizationMembership()

const providers = ['aws', 'gcp', 's3ns', 'azure']

const slidersRef = ref({})
const providerAccounts = ref({})

const providerAccountsStore = useProviderAccountsStore()
const mappingStore = useMappingStore()

const { loading } = storeToRefs(providerAccountsStore)

onMounted(() => {
  for (const provider of providers) {
    animateLargeSlider(slidersRef.value[provider])
  }
})

function animateLargeSlider(slider) {
  setTimeout(() => {
    const { scrollWidth, offsetWidth } = slider
    if (scrollWidth > offsetWidth) {
      slider.scrollBy({
        left: 50,
        behavior: 'smooth'
      })
      setTimeout(() => {
        slider.scrollBy({
          left: -50,
          behavior: 'smooth'
        })
      }, 1000)
    }
  }, 1000)
}

function load() {
  providers.forEach((provider) => {
    // Get the latest 5 provider accounts.
    providerAccountsStore
      .getProviderAccounts(organizationID, { provider_name: provider, enabled: true })
      .then((accounts) => {
        if (!accounts.length && provider === 'aws') {
          providerAccountsStore.loadDemoDetails()
        }
        providerAccounts.value[provider] = accounts
      })
  })
}

const awsDemoAccount = {
  id: 'demo',
  name: 'Demo Account'
}

load()
</script>

<template>
  <section class="is-flex is-flex-direction-column p-5 is-gap-5">
    <div v-for="provider in providers" :key="provider">
      <h3 class="is-size-5">
        {{ mappingStore.providersData[provider]?.name || provider }} accounts
      </h3>

      <div class="slider-wrapper is-relative">
        <div
          :ref="(el) => (slidersRef[provider] = el)"
          class="slider holori-scrollbar is-flex is-align-items-center my-5 px-5"
        >
          <template v-if="loading.providerAccounts[provider]">
            <o-skeleton width="260" height="260" style="width: 260px" animated />
          </template>

          <template v-if="Array.isArray(providerAccounts[provider])">
            <ProviderAccountCard
              v-for="providerAccount in providerAccounts[provider]"
              :key="providerAccount.id"
              :provider-account="providerAccount"
            />
          </template>

          <ProviderAccountCard
            v-else-if="provider === 'aws'"
            :provider-account="awsDemoAccount"
            use-sync
          />

          <p v-else>You have no connected accounts yet.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.slider {
  height: 270px;
  gap: 1.5rem;
  overflow-x: scroll;
  width: calc(100vw - var(--sidebar-width));
  margin-left: -1.5rem;
  margin-right: -1.5rem;
  position: relative;
}
.slider-wrapper:before,
.slider-wrapper:after {
  content: '';
  pointer-events: none;
  position: absolute;
  top: 0;
  height: 300px;
  width: 1.5rem;
  z-index: 2;
}
.slider-wrapper:before {
  background: linear-gradient(to right, var(--primary-bg), transparent);
  left: -1.5rem;
}
.slider-wrapper:after {
  background: linear-gradient(to left, var(--primary-bg), transparent);
  right: -1.5rem;
}
.card {
  width: 260px;
  max-width: 260px;
  min-width: 260px;

  height: 260px;
  min-height: 260px;
  max-height: 260px;
}

.card:hover {
  box-shadow: 0 0 10px lightgray;
}
</style>
