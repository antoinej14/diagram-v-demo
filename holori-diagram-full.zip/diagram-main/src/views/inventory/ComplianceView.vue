<script setup>
import { ref } from 'vue'
import { OTable, OTableColumn } from '@oruga-ui/oruga-next'

const data = ref([
  {
    provider: 'aws',
    policy: 'Cloudwatch - consider using a retention policy to reduce storage costs',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EBS - consider upgrading gp2 volumes to gp3',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EBS - consider upgrading io1/io2 volumes to gp3',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EBS - consider upgrading io1 volumes to io2',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'S3 - consider using a lifecycle policy to reduce storage costs',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider using latest generation instances for t family instances',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider upgrading hs1 instances to d2',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'EC2 - consider upgrading a1 instances to c7g',
    failingResources: []
  },
  {
    provider: 'aws',
    policy: 'RDS - consider using latest generation instances for m family instances',
    failingResources: []
  }
])
</script>

<template>
  <main>
    <section class="m-5 p-5 has-background-white is-border-radius-md">
      <o-table :data="data" hoverable>
        <o-table-column v-slot="props" label="Vendor" width="70">
          <img
            :src="`/diagram/${props.row.provider}.svg`"
            :alt="props.row.provider"
            class="company-logo-m"
          />
        </o-table-column>

        <o-table-column v-slot="props" label="Policy">
          {{ props.row.policy }}
        </o-table-column>

        <o-table-column
          v-slot="props"
          label="Failing resources"
          :th-attrs="() => ({ class: 'has-text-right' })"
          :td-attrs="() => ({ class: 'has-text-right' })"
        >
          <template v-if="props.row.failingResources.length"> TODO </template>

          <span v-else class="has-text-grey"> None detected </span>
        </o-table-column>
      </o-table>
    </section>
  </main>
</template>
