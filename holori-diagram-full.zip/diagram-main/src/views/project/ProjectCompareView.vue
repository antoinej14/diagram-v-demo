<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { storeToRefs } from 'pinia'
import { useDiagramStore } from '@/store/diagram'

import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import DiagramDetails from '@/components/diagram/Details.vue'
import readG6Diagram from '@/common/diagram/options/methods/read'
import { initOneDiagram } from '@/components/diagram/hooks/init'
import { useZoom } from '@/components/diagram/hooks/zoom'
import { OLoading } from '@oruga-ui/oruga-next'
import { useProjectStore } from '@/store/project.js'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import ProjectCompareNavBar from '@/components/project/ProjectCompareNavBar.vue'

const props = defineProps({
  left: {
    type: Number,
    required: true
  },
  right: {
    type: Number,
    required: true
  }
})

const { organizationID } = useOrganizationMembership(false)

const leftPanelVisible = ref(true)
const rightPanelVisible = ref(true)
const loading = ref({
  canvas1: true,
  canvas2: true
})

const leftSidebarRef = ref(null)
const canvas1Ref = ref(null)
const canvas2Ref = ref(null)

const diagramStore = useDiagramStore()
const projectStore = useProjectStore()

const { getGlobalSelectionCount } = storeToRefs(diagramStore)

const detailsVisible = computed(() => getGlobalSelectionCount.value > 0 && rightPanelVisible.value)

onMounted(() => {
  diagramStore.clearSelection()
  generateDiagrams()

  window.lockedMode = true
  document.body.classList.add('no-bg')
})

onBeforeUnmount(() => {
  document.body.classList.remove('no-bg')
})

const { zoomIn, zoomOut } = useZoom()

function generateDiagrams() {
  initOneDiagram({
    number: 1,
    canvas: canvas1Ref.value,
    zoomIn,
    zoomOut
  })
  initOneDiagram({
    number: 2,
    canvas: canvas2Ref.value,
    zoomIn,
    zoomOut
  })

  const { graph1, graph2, paper1, paper2, scroller1, scroller2 } = window

  if (!props.left || !props.right || !graph1 || !graph2) {
    return
  }

  loading.value = {
    canvas1: true,
    canvas2: true
  }

  let diagramLeft, diagramRight

  const promiseLeft = projectStore.getProjectDiagram(organizationID, props.left).then((diagram) => {
    diagramLeft = JSON.parse(diagram)
    loading.value.canvas1 = false
  })
  const promiseRight = projectStore
    .getProjectDiagram(organizationID, props.right)
    .then((diagram) => {
      diagramRight = JSON.parse(diagram)
      loading.value.canvas2 = false
    })
  Promise.all([promiseLeft, promiseRight]).then(() => {
    const dataLeft = readG6Diagram(diagramLeft, graph1, paper1)
    const dataRight = readG6Diagram(diagramRight, graph2, paper2)

    if (dataLeft && dataRight) {
      const merged = {
        nodes: [...dataLeft.nodes, ...dataRight.nodes],
        groups: [...dataLeft.groups, ...dataRight.groups],
        edges: [...dataLeft.edges, ...dataRight.edges]
      }

      diagramStore.setData(merged)
      leftSidebarRef.value.reloadResources()
    }

    setTimeout(() => {
      scroller1.zoomToFit({ maxScale: 1 })
      scroller2.zoomToFit({ maxScale: 1 })
    })
  })
}
</script>

<template>
  <div class="under-navbar is-relative is-flex">
    <ProjectCompareNavBar />
    <DiagramLeftSidebar
      ref="leftSidebarRef"
      :visible="leftPanelVisible"
      visualize-mode
      :adding-node="''"
      @toggle-visibility="leftPanelVisible = !leftPanelVisible"
    />
    <DiagramDetails
      :visible="detailsVisible"
      disabled
      hide-style
      hide-project
      @toggle-visibility="rightPanelVisible = false"
    />
    <div id="canvas1" ref="canvas1Ref" class="canvas" />
    <div id="canvas2" ref="canvas2Ref" class="canvas" />
    <o-loading :active="loading.canvas1 || loading.canvas2" full-page>
      Please wait while we are making the comparison&hellip;
    </o-loading>
  </div>
</template>

<style scoped>
.canvas:first-child:after {
  content: '';
  background-color: grey;
  height: 100%;
  position: absolute;
  top: 0;
  right: -1px;
  width: 2px;
  z-index: 2;
  transition: opacity 0.3s ease;
}
.canvas:before {
  content: '';
  position: absolute;
  height: 100%;
  top: 0;
  width: 20px;
  z-index: 20;
}
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  width: 50vw;
  height: calc(100vh - var(--navbar-height));
}
#canvas1 {
  left: 0;
}
#canvas2 {
  right: 0;
}
#canvas1:before {
  background: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.15));
  right: 0;
}
#canvas2:before {
  background: linear-gradient(to left, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.15));
  left: 0;
}
</style>
