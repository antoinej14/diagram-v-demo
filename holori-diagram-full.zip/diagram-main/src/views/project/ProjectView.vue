<script setup>
import { ref, watch, onBeforeUnmount, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useOrganizationMembership } from '@/common/organization-membership'
import { useMixins } from '@/common/mixins'
import { storeToRefs } from 'pinia'
import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'
import ProjectHistory from '@/components/modal/ProjectHistory.vue'
import ProjectNavBar from '@/components/project/ProjectNavBar.vue'
import KeyboardShortcuts from '@/components/modal/KeyboardShortcuts.vue'
import { OLoading, OModal } from '@oruga-ui/oruga-next'
import EventBus from '@/common/eventBus.js'
import { MIGRATION_VERSION } from '@/common/diagram/migration.js'

const route = useRoute()
const { organizationID } = useOrganizationMembership()
const { toast } = useMixins()

const props = defineProps({
  id: {
    type: Number,
    required: true
  },
  providerName: {
    type: String,
    required: false,
    default: ''
  },
  installationID: {
    type: String,
    required: false,
    default: ''
  }
})

const loading = ref(true)
const historyOpen = ref(false)
const keyboardShortcutsOpen = ref(false)
const newChanges = ref(false)

const projectStore = useProjectStore()
const diagramStore = useDiagramStore()

const { project, projectDiagram, isLoading } = storeToRefs(projectStore)
const { canLeave, layouting } = storeToRefs(diagramStore)

watch(
  () => route.name,
  (newRoute) => {
    if (newRoute !== 'ProjectDesign') {
      diagramStore.clearSelection()
    }
  }
)

function openHistory() {
  historyOpen.value = true
}

onMounted(() => {
  window.priceFormatter = new Intl.NumberFormat(
    undefined, // undefined to force the browser default locale
    {
      style: 'currency',
      currency: 'USD',
      maximumSignificantDigits: 8,
      maximumFractionDigits: 4
    }
  )
  diagramStore.loadCompanies()
  window.addEventListener('beforeunload', confirmExit)

  const loadingError = () => {
    toast({
      message: 'The project can not be loaded',
      variant: 'danger'
    })
  }

  if (!props.providerName || !props.installationID || props.providerName === 'export') {
    projectStore.getProject(organizationID, props.id).then((project) => {
      projectStore.getProjectDiagram(organizationID, props.id).then((diagram) => {
        const parsed = JSON.parse(diagram)
        if ('combos' in parsed && !('groups' in parsed)) {
          toast({
            variant: 'info',
            message: 'Please wait while we are migrating your diagram to the new version&hellip;'
          })
          const modified = {
            nodes: parsed.nodes.map(({ comboId, ...rest }) => ({
              ...rest,
              parent: comboId
            })),
            groups: parsed.combos,
            edges: parsed.edges,
            version: MIGRATION_VERSION
          }
          projectStore
            .editProject(organizationID, props.id, {
              name: project.name,
              diagram: JSON.stringify(modified)
            })
            .then(() => {
              toast({
                variant: 'success',
                message: 'Migration successful! Now reloading&hellip;'
              })
              setTimeout(() => {
                window.location.reload()
              }, 2000)
            })
        } else {
          loading.value = false
        }
      })
    }, loadingError)
  } else {
    projectStore
      .getFromProvider(props.id, props.providerName, props.installationID)
      .then(() => {}, loadingError)
  }

  EventBus.on('openHistory', openHistory)
})

onBeforeUnmount(() => {
  window.removeEventListener('beforeunload', confirmExit)
  projectStore.setProject(null)
  diagramStore.reset()
  EventBus.remove('openHistory', openHistory)
})

function confirmExit(e) {
  // call when navigation triggered by the browser
  //  i.e. can be closing the tab, back/forward navigation etc...
  // https://developer.mozilla.org/en-US/docs/Web/API/Window/beforeunload_event#examples
  if (!canLeave.value) {
    e.preventDefault()
    e.returnValue = ''
  }
}

// TODO edit and save  project
function saveDiagram(thumbnail) {
  diagramStore.saveDiagram(organizationID, thumbnail).then(
    () => {
      newChanges.value = false
      toast({
        message: 'Project saved',
        variant: 'success'
      })
    },
    ({
      response: {
        data: { detail }
      }
    }) => {
      toast({
        message: `The project can not be saved: ${detail}`,
        variant: 'danger'
      })
    }
  )
}
</script>

<template>
  <section class="hero full-height">
    <o-modal :active="historyOpen" @close="historyOpen = false">
      <ProjectHistory v-if="historyOpen" @close="historyOpen = false" />
    </o-modal>
    <o-modal :active="keyboardShortcutsOpen" @close="keyboardShortcutsOpen = false">
      <KeyboardShortcuts />
    </o-modal>
    <o-loading v-model:active="loading" full-page />
    <ProjectNavBar
      @open-history="historyOpen = true"
      @open-keyboard-shortcuts="keyboardShortcutsOpen = true"
    />
    <template v-if="project && projectDiagram">
      <RouterView v-slot="{ Component }" @save-diagram="saveDiagram">
        <Transition name="fade-x">
          <component :is="Component" />
        </Transition>
      </RouterView>
    </template>
    <o-loading :active="isLoading" full-page />
    <o-loading :active="layouting" full-page>
      <div class="is-relative has-text-centered">
        <progress class="progress is-small is-primary mb-5" max="100">15%</progress>
        <p>Please wait while your diagram is being rearranged&hellip;</p>
        <p>Depending on how big your diagram is, this may take a few seconds.</p>
      </div>
    </o-loading>
  </section>
</template>
