<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { storeToRefs } from 'pinia'
import { useDiagramStore } from '@/store/diagram'
import { useZoom } from '@/components/diagram/hooks/zoom'
import { useInitDiagram } from '@/components/diagram/hooks/init'
import { compareTwoDiagrams } from '@/common/diagram/options/methods/compare'

import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import DiagramDetails from '@/components/diagram/Details.vue'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import { useProjectStore } from '@/store/project.js'
import ProjectCompareNavBar from '@/components/project/ProjectCompareNavBar.vue'

const props = defineProps({
  left: {
    type: Number,
    required: true
  },
  right: {
    type: Number,
    required: true
  }
})

const { organizationID } = useOrganizationMembership(false)

const leftPanelVisible = ref(true)
const rightPanelVisible = ref(false)

const leftSidebarRef = ref(null)
const canvasRef = ref(null)

const diagramStore = useDiagramStore()
const projectStore = useProjectStore()

const { getGlobalSelection } = storeToRefs(diagramStore)

onMounted(() => {
  diagramStore.clearSelection()
  generateDiagram()
  document.body.classList.add('no-bg')
})

onBeforeUnmount(() => {
  document.body.classList.remove('no-bg')
})

const { zoomIn, zoomOut, zoomToFit } = useZoom()
const { initDiagram } = useInitDiagram({
  canvasRef,
  zoomIn,
  zoomOut
})

function generateDiagram() {
  initDiagram()

  const { graph, paper } = window

  if (!props.left || !props.right) {
    return
  }

  let diagramLeft, diagramRight

  const promiseLeft = projectStore.getProjectDiagram(organizationID, props.left).then((diagram) => {
    diagramLeft = JSON.parse(diagram)
  })
  const promiseRight = projectStore
    .getProjectDiagram(organizationID, props.right)
    .then((diagram) => {
      diagramRight = JSON.parse(diagram)
    })

  Promise.all([promiseLeft, promiseRight]).then(() => {
    const { data, highlight } = compareTwoDiagrams(diagramLeft, diagramRight, graph, paper)
    highlight()
    paper.unfreeze()
    diagramStore.setData(data)

    leftSidebarRef.value.reloadDiff()

    setTimeout(() => {
      zoomToFit()
    }, 500)
  })
}

function selectItem(id) {
  const cell = window.graph.getCell(id)
  window.selection.collection.reset([cell])
  window.scroller.centerElement(cell)
}
</script>

<template>
  <div class="under-navbar is-relative is-flex">
    <ProjectCompareNavBar />
    <DiagramLeftSidebar
      ref="leftSidebarRef"
      :visible="leftPanelVisible"
      visualize-mode
      display-diff
      :adding-node="''"
      @toggle-visibility="leftPanelVisible = !leftPanelVisible"
      @select="selectItem"
    />
    <DiagramDetails
      :visible="getGlobalSelection.length > 0"
      disabled
      hide-style
      hide-project
      @toggle-visibility="rightPanelVisible = false"
    />
    <div ref="canvasRef" class="canvas" />
  </div>
</template>

<style scoped>
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: calc(100vh - var(--navbar-height));
}
</style>
