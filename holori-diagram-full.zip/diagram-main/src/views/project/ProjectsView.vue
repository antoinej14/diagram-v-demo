<script setup>
import { useOrganizationMembership } from '@/common/organization-membership'
import { useMixins } from '@/common/mixins.js'

import { useProjectStore } from '@/store/project'

import ProjectsSearch from '@/components/projects/ProjectsSearch.vue'
import ProjectsPageSize from '@/components/projects/ProjectsPageSize.vue'
import ProjectsList from '@/components/projects/ProjectsList.vue'
import ProjectsPagination from '@/components/projects/ProjectsPagination.vue'

const { organizationID } = useOrganizationMembership(loadProjects)
const { toast } = useMixins()

const projectStore = useProjectStore()

function loadProjects() {
  projectStore.getProjects(organizationID)
}

function deletedProject(name) {
  toast({
    variant: 'success',
    message: `The project "${name}" has been deleted.`
  })
  loadProjects()
}
</script>

<template>
  <section class="is-flex-grow-1 is-flex is-flex-direction-column">
    <div class="is-flex-grow-1 is-flex is-flex-direction-column">
      <div class="p-5 projects-heading">
        <div class="is-flex is-justify-content-space-between is-align-items-center">
          <ProjectsSearch />

          <ProjectsPageSize />
        </div>
      </div>

      <ProjectsList @delete="deletedProject" />
      
      <ProjectsPagination />
    </div>
  </section>
</template>

<style scoped>
.projects-heading {
  position: relative;
  z-index: 20;
}
</style>
