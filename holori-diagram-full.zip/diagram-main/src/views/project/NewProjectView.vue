<script setup>
import { ref, computed, watch, nextTick } from 'vue'
import { useMixins } from '@/common/mixins'
import ProjectCard from '@/components/ProjectCard.vue'
import { useProjectStore } from '@/store/project'
import { useMappingStore } from '@/store/mapping'
import { useOrganizationMembership } from '@/common/organization-membership'
import { OField, OIcon, OInput, OTooltip } from '@oruga-ui/oruga-next'

const { organizationID } = useOrganizationMembership()
const { scrollToBottom, navigate } = useMixins()

const props = defineProps({
  type: {
    type: String,
    required: false,
    default: ''
  },
  template: {
    type: String,
    required: false,
    default: ''
  }
})

const options = [
  {
    type: 'blank',
    title: 'Blank diagram',
    icon: 'file-plus-outline',
    titleValid: 'Create a blank diagram'
  },
  {
    type: 'templates',
    title: 'Templates',
    icon: 'file-cloud-outline',
    titleValid: 'Create a diagram from a template'
  }
]

const name = ref('')
const notes = ref('')
const templates = ref({})
const selectedTemplateName = ref(null)
const diagram = ref('')
const thumbnail = ref(undefined)

const nameInputRef = ref(null)

const projectStore = useProjectStore()
const mappingStore = useMappingStore()

const canCreate = computed(() => {
  if (!name.value) {
    return false
  }

  switch (props.type) {
    case 'blank':
      return true
    case 'templates':
      return props.template !== null
    default:
      return false
  }
})

watch(
  () => props.type,
  (newType) => {
    if (newType === 'templates') {
      loadTemplates()
    } else if (newType) {
      focusNameInput()
    }
  }
)

watch(
  () => props.template,
  (newTemplate) => {
    if (newTemplate) {
      loadTemplate(newTemplate)
      focusNameInput()
    }
  }
)

watch(selectedTemplateName, scrollToBottom)

function focusNameInput() {
  setTimeout(() => {
    nextTick(() => {
      nameInputRef.value.focus()
    })
  }, 600)
}

function loadTemplates() {
  mappingStore.getTemplates().then((newTemplates) => {
    templates.value = newTemplates
  })
}

function loadTemplate(template) {
  mappingStore.getTemplate(template).then((data) => {
    name.value = data.name
    notes.value = data.notes
    diagram.value = data.diagram
    thumbnail.value = data.thumbnail
  })
}

function selectProjectType(type) {
  navigate('NewProject', {
    params: { type }
  })
}

function selectTemplate() {
  navigate('NewProject', {
    params: {
      type: 'templates',
      template: selectedTemplateName.value
    }
  })
}

function createProject() {
  if (!canCreate.value) {
    return
  }

  const data = {
    name: name.value,
    notes: notes.value
  }

  if (props.type === 'templates' && diagram.value !== '') {
    data.diagram = diagram.value
    data.thumbnail = thumbnail.value
  }

  projectStore.createProject(organizationID, data).then((res) => {
    const { id } = res.data
    navigate('ProjectDesign', {
      params: { id }
    })
  })
}

if (props.type === 'templates') {
  loadTemplates()
}

if (props.template) {
  loadTemplate(props.template)
}
</script>
<template>
  <section class="is-flex-grow-1 p-5">
    <form class="container px-6 is-max-desktop" @submit.prevent="createProject">
      <TransitionGroup name="fade-x">
        <div v-if="!type" key="project-type" class="is-border-radius-md has-background-white p-5">
          <p class="mb-5">Project type</p>
          <div class="is-flex is-flex-wrap-wrap is-justify-content-center project-types">
            <o-tooltip
              v-for="option in options"
              class="is-flex-1"
              :key="option.icon"
              position="bottom"
              :label="option.titleValid"
            >
              <div
                class="card is-flex is-flex-direction-column is-justify-content-space-around is-border-radius-xl is-clickable is-flex-1 project-type"
                :class="{
                  'has-background-primary has-text-white': type === option.type
                }"
                @click="selectProjectType(option.type)"
              >
                <div class="card-content is-flex is-flex-direction-column full-height">
                  <div
                    class="is-flex is-justify-content-center is-align-items-center is-flex-grow-1"
                  >
                    <o-icon class="vertical-align-middle" size="large" :icon="option.icon" />
                  </div>
                  <p class="mt-4 is-size-5 has-text-weight-normal has-text-centered option-title">
                    {{ option.title }}
                  </p>
                </div>
              </div>
            </o-tooltip>
          </div>
        </div>
        <div
          v-if="type === 'templates' && !template"
          key="project-name"
          class="is-border-radius-md has-background-white p-5"
        >
          <p class="mb-5">Select your template</p>
          <div class="p-1 is-flex is-justify-content-space-around is-flex-wrap-wrap">
            <ProjectCard
              v-for="project in templates"
              :key="project.id"
              class="m-2"
              :project="project"
              hide-footer
              template
              :selected="selectedTemplateName === project.id"
              :open-on-click="false"
              @click="selectedTemplateName = project.id"
            />
          </div>
          <a
            class="footer-button p-3 is-border-bottom-radius-sm has-background-primary has-text-white"
            :class="{ 'create-disabled': !selectedTemplateName }"
            @click="selectTemplate"
          >
            <o-icon icon="file-image-plus-outline" class="mr-3" />
            Select template
          </a>
        </div>
        <div
          v-if="(type && type !== 'templates') || (type === 'templates' && template)"
          key="project-name"
          class="is-border-radius-md has-background-white p-5"
        >
          <p class="mb-5">Details about your project</p>
          <o-field label="Name of the project">
            <o-input
              ref="nameInputRef"
              v-model="name"
              type="text"
              placeholder="This field is required"
              required
              expanded
            />
          </o-field>
          <o-field label="Notes">
            <o-input
              v-model="notes"
              type="textarea"
              placeholder="Notes are not mandatory"
              expanded
            />
          </o-field>
          <button
            class="footer-button p-3 is-border-bottom-radius-sm has-background-primary has-text-white is-clickable"
            :class="{ 'create-disabled': !canCreate }"
            type="submit"
          >
            <o-icon icon="file-image-plus-outline" class="mr-3" />
            Create Project
          </button>
        </div>
      </TransitionGroup>
    </form>
  </section>
</template>

<style scoped>
.project-types {
  gap: 1.5rem;
}
.project-type {
  border: 1px solid #0000001f;
  flex: 0 0 185px;
  transition:
    background-color 0.2s ease,
    color 0.2s ease,
    box-shadow 0.2s ease;
}
.project-type:hover {
  background-color: var(--primary);
  box-shadow: none;
  color: #fff;
}
.option-title {
  align-items: center;
  display: inline-flex;
  justify-content: center;
  min-height: 55px;
}

.create-disabled {
  cursor: not-allowed !important;
  opacity: 0.5;
}
.footer-button {
  border: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1.5rem -1.5rem -1.5rem;
  width: calc(100% + 3rem);
}
</style>
