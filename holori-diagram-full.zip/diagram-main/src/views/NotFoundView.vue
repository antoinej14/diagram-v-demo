<template>
  <main class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center">
    <p>We are deeply sorry, but we could not find this page.</p>
    <p class="mt-5"><a href="/">Go back home</a>.</p>
  </main>
</template>
