<script setup>
import { useMixins } from '@/common/mixins'
import { useAccountStore } from '@/store/account'
import { useOrganizationStore } from '@/store/organization'
import { OIcon } from '@oruga-ui/oruga-next'

const { navigate } = useMixins()

const accountStore = useAccountStore()

if (!accountStore.isLoggedIn) {
  console.log('user is not logged in')

  navigate('Login')
}

console.log('user is already logged in')

const organizationStore = useOrganizationStore()
const organizationID = organizationStore.getCurrentOrganization?.id

if (organizationID) {
  console.log('organization found, opening its dashboard')

  navigate('ProjectsOverview', {
    params: {
      organizationID
    }
  })
} else {
  console.log('no organization found, time to onboard')

  navigate('Onboarding')
}
</script>

<template>
  <main class="is-flex is-flex-direction-column is-align-items-center is-justify-content-center">
    <p class="mb-5">Redirecting you to your organization&hellip;</p>

    <o-icon icon="loading" size="large" spin />
  </main>
</template>
