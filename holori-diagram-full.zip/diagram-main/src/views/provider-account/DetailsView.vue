<script setup>
import { ref, computed, watch } from 'vue'
import { onBeforeRouteLeave, useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import {
  OButton,
  OField,
  OIcon,
  OInput,
  OLoading,
  ONotification,
  OSwitch,
  OTooltip,
  OSkeleton,
  useOruga
} from '@oruga-ui/oruga-next'

import { useMixins, usePreviousRoute } from '@/common/mixins'
import { FILTERS, OPERATORS } from '@/common/enums'

import ExportListView from '@/components/diagram/export/ExportListView.vue'
import ProviderAccountCard from '@/components/ProviderAccountCard.vue'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import ConfirmationModal from '@/components/modal/Confirmation.vue'

import { useDashboardStore } from '@/store/dashboard.js'

const route = useRoute()
const oruga = useOruga()
const { setPageTitle, toast, updateQueryJS } = useMixins()
const { previousRoute } = usePreviousRoute()

onBeforeRouteLeave(() => {
  updateQueryJS({ edit: null })
})

const props = defineProps({
  providerID: {
    type: [Number, String],
    required: true
  }
})

const { organizationID, goTo } = useOrganizationMembership(false)

const loading = ref(true)
const editing = ref(route.query.edit !== undefined)
const saving = ref(false)
const verifying = ref(false)
const name = ref('')
const authenticationData = ref({})
const enabled = ref(false)

const mostExpensiveResourcesLimit = ref(10)

const providerAccountsStore = useProviderAccountsStore()
const dashboardStore = useDashboardStore()

const { providerAccount, lastSynchronizationDate, synchronizationDiagram } =
  storeToRefs(providerAccountsStore)

const displayInfrastructure = computed(
  () =>
    !['gcp', 's3ns'].includes(providerAccount.value?.provider_name) ||
    (['gcp', 's3ns'].includes(providerAccount.value?.provider_name) &&
      !providerAccount.value?.authentication_data?.is_billing_enabled)
)
const buttonLabel = computed(() => (editing.value ? 'Cancel' : 'Edit info'))
const buttonIcon = computed(() => (editing.value ? 'cancel' : 'rename'))

watch(
  () => providerAccount.value?.name,
  (providerAccountName) => {
    if (providerAccountName) {
      setPageTitle(providerAccountName)
      updateDetails()
    }
  }
)

watch(editing, (newVal) => {
  updateQueryJS({ edit: !newVal ? null : true })
})

function load() {
  if (props.providerID === 'demo') {
    providerAccountsStore.loadDemoDetails().then(updateDetails)
  } else {
    updateDetails()
  }
}

function updateDetails() {
  name.value = providerAccount.value.name
  authenticationData.value = providerAccount.value.authentication_data
  enabled.value = providerAccount.value.enabled

  if (props.providerID !== 'demo') {
    // TODO load provider accounts ?

    if (displayInfrastructure.value) {
      // Clear just in case.
      providerAccountsStore.setSynchronizationDiagram(null)
      providerAccountsStore.setSynchronizationThumbnail(null)

      providerAccountsStore
        .getLastSynchronization(organizationID, props.providerID)
        .then((sync) => {
          if (sync) {
            const promises = [
              providerAccountsStore.getSynchronizationDiagram(
                organizationID,
                props.providerID,
                sync.id
              ),
              providerAccountsStore.getSynchronizationThumbnail(
                organizationID,
                props.providerID,
                sync.id
              )
            ]
            Promise.allSettled(promises).then(() => {
              loading.value = false
            })
          } else {
            loading.value = false
          }
        })
    }
  }
}

function save() {
  if (saving.value) {
    return
  }

  saving.value = true

  const account = {
    name: name.value,
    provider_name: providerAccount.value.provider_name,
    authentication_data: authenticationData.value
  }

  providerAccountsStore
    .editProviderAccount(organizationID, props.providerID, account)
    .then((res) => {
      toast({
        variant: 'success',
        message: 'Your account has been successfully saved.'
      })

      providerAccountsStore.setProviderAccount(res.data)

      verify().then(() => {
        saving.value = false
      })
    })
}

async function deleteAccount() {
  const instance = oruga.modal.open({
    component: ConfirmationModal,
    props: {
      title: 'Deleting provider account',
      message: 'Are you sure you want to remove this provider account from this organization?',
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Delete',
      yesIcon: 'delete',
      invertColors: true
    },
    trapFocus: true
  })
  const result = await instance.promise
  if (result === true) {
    providerAccountsStore.deleteProviderAccount(organizationID, props.providerID).then(
      () => {
        toast({
          variant: 'success',
          message: 'Provider account has been deleted.'
        })
        goTo('CloudAccounts')
      },
      () => {
        toast({
          variant: 'danger',
          message: 'Unable to delete provider account. Please contact support.'
        })
      }
    )
  }
}

function updateAuthenticationData(data) {
  authenticationData.value = data
}

function toggleAccount(toggle) {
  if (providerAccount.value.enabled === toggle) {
    return
  }

  providerAccountsStore
    .editProviderAccount(organizationID, props.providerID, {
      ...providerAccount.value,
      enabled: toggle
    })
    .then((res) => {
      enabled.value = res.data.enabled
    })
}

function verify() {
  verifying.value = true

  return providerAccountsStore
    .verifyProviderAccount(organizationID, props.providerID)
    .then(
      () => {
        toast({
          message: 'Authentication data was successfully verified!',
          variant: 'success'
        })

        toggleAccount(true)
      },
      (error) => {
        toast({
          message: `There was an error while verifying your token: ${error.response.data.detail}.<br><br>This cloud account has been disabled while you fix the issue. Once fixed, the account will be automatically enabled again. If you have trouble solving the issue, contact us in live chat or at <a href="mailto:support@holori.com">support@holori.com</a>.`,
          variant: 'danger',
          autoClose: false,
          duration: 30000
        })

        toggleAccount(false)
      }
    )
    .then(() => {
      verifying.value = false
    })
}

load()

function changeEnabled(checked) {
  const val = !checked
  saving.value = true

  if (val === providerAccount.value.enabled) {
    return
  }

  const account = {
    name: name.value,
    provider_name: providerAccount.value.provider_name,
    enabled: val
  }

  providerAccountsStore
    .editProviderAccount(organizationID, props.providerID, account)
    .then((res) => {
      providerAccountsStore.setProviderAccount(res.data)

      toast({
        variant: 'success',
        message: 'Your account has been successfully saved.'
      })

      saving.value = false
    })
}

</script>

<template>
  <section v-if="providerAccount" class="is-flex is-flex-direction-column is-gap-5 p-5">
    <ProvidersBreadcrumbs v-if="previousRoute?.name === 'CloudAccounts'" />
    <InfrastructureViewBreadcrumbs v-else />

    <div class="is-flex is-justify-content-space-between">
      <o-tooltip
        class="is-flex is-align-items-center mr-3"
        label="Enable or disable automatic synchronization for this account"
        position="right"
      >
        <o-switch v-model="enabled" @input="changeEnabled">Enable synchronizations</o-switch>
      </o-tooltip>

      <div class="is-flex is-align-items-center is-gap-3">
        <o-button
          variant="primary"
          :icon-left="verifying ? 'loading' : 'check'"
          :disabled="verifying"
          @click="verify"
        >
          Verify connection
        </o-button>
        <o-button variant="primary" :icon-left="buttonIcon" @click="editing = !editing">
          {{ buttonLabel }}
        </o-button>
      </div>
    </div>

    <transition name="fade-x">
      <div v-if="editing">
        <form
          class="is-flex is-flex-direction-column is-gap-5 box full-width is-relative"
          @submit.prevent="save"
        >
          <o-loading :active="saving" :full-page="false" />
          <component
            :is="inputComponent"
            :values="authenticationData"
            @change="updateAuthenticationData"
          >
            <o-field label="Provider name" class="mb-0">
              <o-input ref="editName" v-model="name" type="text" icon="domain" expanded />
            </o-field>
          </component>

          <component
            :is="prerequisitesComponent"
            v-model:authentication-data="authenticationData"
          />

          <o-button
            variant="primary"
            native-type="submit"
            icon-left="content-save"
            title="Update this account"
            :disabled="saving"
            expanded
          >
            Save and verify
          </o-button>
        </form>
        <div class="box mt-5">
          <o-notification type="warning" variant="warning">
            You can delete this provider account. You will not be able to recover it. You will lose
            all the data associated to this account.
          </o-notification>
          <o-button
            variant="danger"
            native-type="button"
            icon-left="delete"
            title="Delete this account"
            :disabled="saving"
            expanded
            @click="deleteAccount"
          >
            Delete
          </o-button>
        </div>
      </div>
    </transition>
    <div class="is-flex is-flex-grow-1 is-flex-direction-column">
      <template v-if="displayInfrastructure">
        <h2 class="is-flex is-align-items-center is-justify-content-center is-size-4 mb-5">
          <o-icon icon="sync" class="mr-3" />
          Infrastructure visibility
        </h2>

        <div class="is-flex is-align-items-center is-justify-content-center mb-5">
          <ProviderAccountCard v-if="!loading" :provider-account="providerAccount" use-sync />
          <o-skeleton v-else class="w-auto" width="260" height="260" />
        </div>
      </template>

      <MostExpensiveResources
        v-if="providerAccount.enabled"
        v-model="mostExpensiveResources"
        v-model:limit="mostExpensiveResourcesLimit"
        class="m-5"
      />

      <template v-if="displayInfrastructure">
        <o-notification v-if="!loading && !lastSynchronizationDate" variant="info">
          Your infrastructure is still being processed. This may take up to a few hours.
        </o-notification>

        <h2 class="is-flex is-align-items-center is-justify-content-center is-size-4 mb-5">
          <o-icon icon="list-box-outline" class="mr-3" />
          Assets inventory
        </h2>

        <div v-if="synchronizationDiagram" class="px-5 mb-5">
          <ExportListView data-source="provider-account" />
        </div>
      </template>
    </div>
  </section>
</template>
