<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { useRoute } from 'vue-router'
import moment from 'moment'
import { useDiagramStore } from '@/store/diagram'
import { useMappingStore } from '@/store/mapping'
import readG6Diagram from '@/common/diagram/options/methods/read'
import { exportDiagramImage } from '@/common/diagram/utils'
import TerraformDocumentationEntry from '@/components/diagram/export/TerraformDocumentationEntry.vue'
import { OButton, OIcon, OLoading, OModal } from '@oruga-ui/oruga-next'
import { useInitDiagram } from '@/components/diagram/hooks/init.js'
import { useProviderAccountsStore } from '@/store/provider-accounts.js'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import { useCrisp, useMixins } from '@/common/mixins.js'
import { hideEmptyEnvironments, performLayout } from '@/common/diagram/options/methods/layout.js'
import SyncHistory from '@/components/modal/SyncHistory.vue'

const props = defineProps({
  providerID: {
    type: Number,
    required: true
  }
})

const route = useRoute()

const { organizationID } = useOrganizationMembership(false)

const { toast, updateQueryJS } = useMixins()

useCrisp()

const diagramInit = ref(false)
const selectEntryOpen = ref(null)
const thumbnail = ref('')
const data = ref({})
const costs = ref({})
const loadingImages = ref(0)

const selectedSync = ref(null)

const canvasRef = ref(null)

const loadingImagesSteps = 2

const { initDiagram } = useInitDiagram({ canvasRef })

const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()
const mappingStore = useMappingStore()

const { providerAccount } = storeToRefs(providerAccountsStore)

const resources = computed(() => {
  const { nodes, groups } = data.value

  if (Array.isArray(nodes) && Array.isArray(groups)) {
    const noEmptyTextBoxes = nodes.filter(
      (node) => node.type !== 'TextBox' || (node.type === 'TextBox' && node.notes !== '')
    )
    return [...noEmptyTextBoxes, ...groups]
  }

  return []
})

watch(loadingImages, (val) => {
  if (val === loadingImagesSteps) {
    setTimeout(() => {
      loadingImages.value = 0
    }, 200)
  }
})

function loadDocumentation(diagram) {
  data.value = diagram
  data.value.nodes = data.value.nodes
    .sort((a, b) => (a.name < b.name ? -1 : 1))
    .filter((node) => node.type !== 'TextBox')
}

function loadDiagram(syncID) {
  providerAccountsStore.getSynchronizationDiagram(organizationID, props.providerID, syncID).then(
    (newData) => {
      if (newData === JSON.stringify(data.value)) {
        return
      }

      const diagram = JSON.parse(newData)

      loadDocumentation(diagram)
      generateImages(diagram)
    },
    () => {
      toast({
        variant: 'warning',
        message: 'Could not get the diagram for this synchronization.'
      })
    }
  )
}

function load() {
  const syncID = route.query.sync

  const call = syncID
    ? providerAccountsStore.getSynchronization(organizationID, props.providerID, parseInt(syncID))
    : providerAccountsStore.getLastSynchronization(organizationID, props.providerID)

  call.then((sync) => {
    if (!sync) {
      toast({
        variant: 'warning',
        message: 'No synchronization data for this cloud account.'
      })
    } else {
      selectedSync.value = sync
      loadDiagram(sync.id)
    }
  })
}

function generateImages(diagram) {
  document.body.classList.add('is-clipped')

  !diagramInit.value && initDiagram()
  diagramInit.value = true

  let data = readG6Diagram(diagram, window.graph, window.paper)
  window.paper.unfreeze()

  const filters = diagramStore.resourcesFilters['account-' + props.providerID]

  loadingImages.value = 1

  const carryOn = () => {
    exportDiagramImage(
      false,
      'image/png',
      (result) => {
        thumbnail.value = result
        loadingImages.value++
        document.body.classList.remove('is-clipped')
      },
      null,
      false
    )
  }

  if (filters && filters.hideEmpty) {
    hideEmptyEnvironments(window.graph)
    data = performLayout(window.graph)
    loadDocumentation(data)
    setTimeout(carryOn, 3000)
  } else {
    carryOn()
  }
}

function formatDate(date) {
  return moment(date).format('L')
}

function print() {
  window.print()
}

// Created.
diagramStore.loadCompanies().then((companies) => {
  mappingStore.getAllRegions(companies)
})

function setEntry(_, sync) {
  updateQueryJS({ sync: sync.id })
  selectedSync.value = sync
  const diagram = JSON.parse(sync.diagram)
  loadDocumentation(diagram)
  generateImages(diagram)
}

onMounted(load)
</script>

<template>
  <div class="is-relative is-flex-grow-1 is-flex is-flex-direction-column">
    <o-modal :active="selectEntryOpen !== null" @close="selectEntryOpen = null">
      <SyncHistory
        v-if="selectEntryOpen"
        @pick="setEntry(selectEntryOpen, $event)"
        @close="selectEntryOpen = null"
      />
    </o-modal>

    <div class="select-sync has-background-white is-absolute p-3">
      <div class="is-flex is-align-items-center">
        <template v-if="selectedSync?.imported">
          {{ moment(selectedSync.imported).format('L, HH:mm') }}
        </template>
        <o-button
          variant="primary"
          icon-left="history"
          class="ml-2"
          @click="selectEntryOpen = 'sync'"
        />
      </div>
    </div>

    <div class="is-absolute z-1">
      <canvas id="jointjs-canvas" />
      <div ref="canvasRef" class="canvas" />
    </div>

    <div id="to-print" class="p-5">
      <div class="box">
        <div class="my-auto">
          <h1 class="has-text-centered is-size-1 has-text-semibold mb-6">
            {{ providerAccount?.name }}
          </h1>
          <div v-if="selectedSync" class="has-text-centered">
            <strong>Created:</strong>
            {{ formatDate(selectedSync.imported) }}
          </div>
        </div>
      </div>
      <div class="box">
        <h2 class="is-size-3 my-4">Thumbnail</h2>

        <img :src="thumbnail" alt="Project thumbnail" class="is-block max-width-full m-auto" />
      </div>
      <div ref="add-watermark1" class="box is-relative">
        <h2 class="is-size-3 my-4">Resources</h2>
        <table>
          <thead>
            <tr>
              <th style="width: 10%">Image</th>
              <th>Name</th>
              <th style="width: 30%">Location</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="node in resources" :key="node.id">
              <td class="py-2 node-image">
                <img v-if="node.image" :src="node.image" :alt="node.id" class="node-image" />
                <o-icon v-else-if="node.type === 'TextBox'" icon="text" />
                <o-icon
                  v-else-if="node.type === 'Group'"
                  :icon="node.location ? 'map-marker' : 'group'"
                  class="node-image"
                />
              </td>
              <td class="py-2">
                <template v-if="node.type === 'TextBox'"> Text Box</template>
                <component
                  :is="node.terraform ? 'a' : 'span'"
                  v-else
                  :href="node.terraform ? `#${node.id}` : undefined"
                >
                  {{ node.name }}
                </component>
              </td>
              <td class="py-2">
                {{ mappingStore.findFirstLocationForDisplay(node.groupId, data.value) }}
              </td>
              <td class="py-2">
                {{ costs[node.id] }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div ref="add-watermark2" class="box is-relative">
        <h2 class="is-size-3 my-4">Terraform</h2>
        <div v-for="node in resources" :key="node.id">
          <template v-if="node.terraform_path && node.terraform">
            <h3 class="is-size-4 mb-3">
              <a :id="node.id">{{ node.name }}</a>
            </h3>

            <div class="mt-3 mb-5 pl-5">
              <TerraformDocumentationEntry
                v-for="(value, key) in node.terraform"
                :key="`${node.id}-${key}`"
                :field="key"
                :value="value"
                :node="node"
              />
            </div>
          </template>
        </div>
      </div>
    </div>
    <o-button
      variant="primary"
      icon-left="printer"
      class="print-button ml-auto mt-5"
      title="Print documentation"
      @click="print"
    >
      Print
    </o-button>
    <o-loading :active="loadingImages > 0">
      <div class="is-flex is-flex-direction-column is-justify-content-center is-align-items-center">
        <o-icon icon="loading" spin size="large" />
        <p class="my-5">Please wait while we are generating the documentation&hellip;</p>
        <progress class="progress is-primary" :value="loadingImages" :max="loadingImagesSteps" />
      </div>
    </o-loading>
  </div>
</template>

<style scoped>
#to-print {
  margin-top: var(--navbar-height);
  width: 100vw;
}

.box {
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.box:not(:last-child) {
  page-break-after: always;
}

.progress {
  width: 200px;
}

td {
  vertical-align: middle;
}

.node-image {
  width: 30px;
}

.canvas {
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: 100vh;
}

.z-1 {
  transform: translate(-100000px, -100000px);
  z-index: -1;
}

.select-sync {
  top: var(--navbar-height);
  z-index: 2;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
}
</style>

<style>
.print-button {
  position: sticky;
  bottom: 20px;
  right: 20px;
}

@media print {
  body {
    background-color: #fff;
    padding: 0;
  }

  .nav-bar,
  .sidebar,
  .print-button,
  .select-sync,
  .notification,
  .canvas,
  .jointjs-paper {
    display: none !important;
  }

  .under-navbar {
    margin-top: 0 !important;
  }

  #to-print {
    margin-top: 0 !important;
  }

  .p-5 {
    padding: 0 !important;
  }

  .box {
    background-color: transparent;
    box-shadow: none;
    min-height: 100vh;
    padding: 0;
  }

  .box:first-child {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex-direction: column !important;
  }
}
</style>
