<script setup>
import { onBeforeUnmount, onMounted, ref, nextTick } from 'vue'
import { storeToRefs } from 'pinia'
import { useDiagramStore } from '@/store/diagram'
import { useProjectStore } from '@/store/project'
import { generate3DDiagram } from '@/common/3d-view'
import panzoom from 'panzoom'
import { OButton, ODropdown, OIcon, OLoading } from '@oruga-ui/oruga-next'

const formats = {
  'image/png': {
    name: 'PNG',
    icon: 'file-png-box',
    whiteBackground: false
  },
  'image/jpeg': {
    name: 'JPG',
    icon: 'file-jpg-box',
    whiteBackground: true
  },
  'image/svg': {
    name: 'SVG',
    icon: 'svg',
    whiteBackground: false
  }
}

let panzoomInstance = null

const progress = ref('')
const images = ref(null)
const panzoomReady = ref(false)
const cursor = ref('grab')

const canvasRef = ref(null)

const diagramStore = useDiagramStore()
const projectStore = useProjectStore()

const { getData } = storeToRefs(diagramStore)
const { project } = storeToRefs(projectStore)

onMounted(() => {
  generate3DDiagram(
    getData.value,
    (_err, data) => {
      images.value = data

      nextTick(() => {
        panzoomInstance = panzoom(canvasRef.value, {
          smoothScroll: false,
          initialZoom: 1.0
          // maxZoom: 1.0
        })
        panzoomInstance.on('panstart', () => {
          cursor.value = 'grabbing'
        })
        panzoomInstance.on('panend', () => {
          cursor.value = 'grab'
        })
        panzoomInstance.on('zoom', () => {
          cursor.value = 'zoom-in'
        })

        panzoomReady.value = true
      })
    },
    progress
  )
})

onBeforeUnmount(() => {
  if (panzoomInstance) {
    panzoomInstance.dispose()
  }
})
</script>

<template>
  <div>
    <o-loading :active="!images" full-page>
      <o-icon icon="loading" size="large" />

      <p>
        {{ progress || 'Generating your 3D diagram&hellip;' }}
      </p>
    </o-loading>

    <o-dropdown v-if="images" class="download-button" position="top-right">
      <template #trigger="{ active }">
        <o-button
          tag="a"
          variant="primary"
          icon-left="file-download"
          :icon-right="active ? 'chevron-down' : 'chevron-up'"
        >
          Download 3D diagram image
        </o-button>
      </template>

      <o-dropdown-item
        v-for="(format, type) in formats"
        :key="format.name"
        class="is-flex is-align-items-center"
        :value="type"
        tag="a"
        :href="images[type]"
        :download="`${project.name}.${format.name.toLowerCase()}`"
      >
        <o-icon :icon="format.icon" class="mr-2" />
        Export to {{ format.name }}
      </o-dropdown-item>
    </o-dropdown>

    <div ref="canvasRef" class="canvas" :style="{ cursor }">
      <div v-if="!images" class="jointjs-paper" :class="{ 'is-invisible': images }" />
      <img
        v-if="panzoomReady"
        alt="3D diagram"
        :src="images['image/svg']"
        class="is-block m-auto"
      />
    </div>
  </div>
</template>

<style scoped>
.canvas {
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: 100vh;
}
.jointjs-paper {
  position: fixed;
  top: 0;
  left: 0;
}
.download-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 20;
}

.download-button :deep(.dropdown-content) {
  left: auto;
  right: 0;
}
</style>
