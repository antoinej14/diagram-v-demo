<script setup>
import { watch } from 'vue'
import { storeToRefs } from 'pinia'
import { useMixins } from '@/common/mixins'
import { useOrganizationMembership } from '@/common/organization-membership'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import ProviderNavBar from '@/components/providers/ProviderNavBar.vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const { organizationID } = useOrganizationMembership(load)
const { setPageTitle } = useMixins()

const props = defineProps({
  providerID: {
    type: [Number, String],
    required: true
  }
})

const providerAccountsStore = useProviderAccountsStore()

const { providerAccount } = storeToRefs(providerAccountsStore)

watch(() => props.providerID, load)

function load() {
  if (props.providerID !== 'demo') {
    providerAccountsStore.getProviderAccount(organizationID, props.providerID).then((details) => {
      setPageTitle(details.name)
    })
  } else {
    providerAccountsStore.setProviderAccount({
      id: 'demo',
      name: 'Demo Account',
      autosync: false
    })
  }
}
</script>

<template>
  <section class="hero full-height">
    <transition name="fade-y-reverse">
      <ProviderNavBar v-if="route.name !== 'ProviderAccount'" />
    </transition>
    <RouterView v-if="providerAccount" :provider-i-d="props.providerID" />
  </section>
</template>
