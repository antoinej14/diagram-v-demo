<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRoute } from 'vue-router'
import moment from 'moment'
import { useMixins } from '@/common/mixins'
import { useZoom } from '@/components/diagram/hooks/zoom'
import { useInitDiagram } from '@/components/diagram/hooks/init'
import { storeToRefs } from 'pinia'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useDiagramStore } from '@/store/diagram'
import { compareTwoDiagrams } from '@/common/diagram/options/methods/compare'
import EventBus from '@/common/eventBus'

import DiagramDetails from '@/components/diagram/Details.vue'
import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import SyncHistory from '@/components/modal/SyncHistory.vue'
import { OButton, OModal } from '@oruga-ui/oruga-next'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import { performLayout } from '@/common/diagram/options/methods/layout.js'
import { anonymous_instance } from '@/api/index'

const route = useRoute()
const { organizationID } = useOrganizationMembership(false)

const props = defineProps({
  providerID: {
    type: [Number, String],
    required: true
  }
})

const { setPageTitle, toast, updateQueryJS } = useMixins()

const format = 'L HH:mm'

const selectEntryOpen = ref(null)
const leftPanelVisible = ref(true)
const rightPanelVisible = ref(true)
const entryA = ref({
  id: null,
  date: '',
  diagram: '',
  didLayout: false
})
const entryB = ref({
  id: null,
  date: '',
  diagram: '',
  didLayout: false
})
const loaded = ref(false)
const loading = ref({
  canvas1: true,
  canvas2: true
})

const leftSidebarRef = ref(null)
const canvasRef = ref(null)

const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()

const { providerAccount } = storeToRefs(providerAccountsStore)
const { getGlobalSelectionCount } = storeToRefs(diagramStore)

const detailsVisible = computed(() => getGlobalSelectionCount.value > 0 && rightPanelVisible.value)

watch(
  () => entryA.value.id,
  (a) => {
    updateQueryJS({ a })
    generateDiagram()
  }
)

watch(
  () => entryB.value.id,
  (b) => {
    updateQueryJS({ b })
    generateDiagram()
  }
)

onMounted(() => {
  setPageTitle(providerAccount.value.name)
  diagramStore.clearSelection()
  diagramStore.setDetailsTab('terraform')

  if (props.providerID !== 'demo') {
    initDiffDiagram()
  } else {
    // TODO create exampleApi.get() ?
    anonymous_instance
      .get('/example-infrastructures/aws.json')
      .then(({ data: { diagram, last_activity_date, thumbnail, history } }) => {
        providerAccountsStore.setSync({
          last_sync_data: diagram,
          last_sync_date: last_activity_date,
          last_sync_thumbnail: thumbnail,
          history: JSON.parse(history)
        })
        initDiffDiagram()
      })
  }
  document.body.classList.add('no-bg')
})

onBeforeUnmount(() => {
  document.body.classList.remove('no-bg')
})

const { zoomIn, zoomOut } = useZoom()
const { initDiagram } = useInitDiagram({
  canvasRef,
  zoomIn,
  zoomOut
})

function initDiffDiagram() {
  initDiagram()

  const { a, b } = route.query

  const notFound = () => {
    toast({
      variant: 'warning',
      message: 'Could not get history entry.'
    })
  }

  if (a) {
    providerAccountsStore
      .getSynchronization(organizationID, props.providerID, Number(a))
      .then((sync) => {
        const { id, imported: date, thumbnail } = sync

        providerAccountsStore
          .getSynchronizationDiagram(organizationID, props.providerID, id)
          .then((diagram) => {
            setEntry('A', {
              id,
              date,
              diagram,
              didLayout: thumbnail !== undefined
            })
          }, notFound)
      }, notFound)
  }
  if (b) {
    providerAccountsStore
      .getSynchronization(organizationID, props.providerID, Number(b))
      .then((sync) => {
        const { id, imported: date, thumbnail } = sync

        providerAccountsStore
          .getSynchronizationDiagram(organizationID, props.providerID, id)
          .then((diagram) => {
            setEntry('B', {
              id,
              date,
              diagram,
              didLayout: thumbnail !== undefined
            })
          }, notFound)
      }, notFound)
  }

  // No entries, try to get the first two
  if (!a || !b) {
    providerAccountsStore.getSynchronizations(organizationID, props.providerID).then((entries) => {
      if (entries.length < 1) {
        toast({
          variant: 'info',
          message: 'Your account does not have history yet.'
        })

        loading.value.canvas1 = false
        loading.value.canvas2 = false
      } else {
        const [lastEntry, previousEntry] = entries
        providerAccountsStore
          .getSynchronizationDiagram(organizationID, props.providerID, lastEntry.id)
          .then((diagram) => {
            const { id, imported: date, thumbnail } = lastEntry
            setEntry('B', {
              id,
              date,
              diagram,
              didLayout: thumbnail !== undefined
            })
          })

        if (previousEntry) {
          providerAccountsStore
            .getSynchronizationDiagram(organizationID, props.providerID, previousEntry.id)
            .then((diagram) => {
              const { id, imported: date, thumbnail } = previousEntry
              setEntry('A', {
                id,
                date,
                diagram,
                didLayout: thumbnail !== undefined
              })
            })
        }
      }
    })
  }

  generateDiagram()

  window.lockedMode = true
}

function setEntry(entry, obj) {
  if (entry === 'A') {
    entryA.value = obj
  } else {
    entryB.value = obj
  }
}

function finish(highlight) {
  highlight()
  leftSidebarRef.value.reloadResources()
  EventBus.dispatch('reloadDiffList')
}

function generateDiagram() {
  const { graph, paper, scroller } = window

  if (!graph) {
    return
  }

  loaded.value = false

  if (entryA.value.diagram && entryB.value.diagram) {
    const dataA = JSON.parse(entryA.value.diagram)
    const dataB = JSON.parse(entryB.value.diagram)
    const { data, highlight } = compareTwoDiagrams(
      dataB,
      dataA,
      graph,
      paper,
      diagramStore.addUpdatedTerraformKey
    )
    loaded.value = true
    window.paper.unfreeze()
    diagramStore.setData(data)

    if (!(entryA.value.didLayout && entryB.value.didLayout)) {
      performLayout(graph)
      setTimeout(() => {
        finish(highlight)
      }, 300)
    } else {
      finish(highlight)
    }

    setTimeout(() => {
      scroller.zoomToFit()
    }, 500)
  }
}

function selectItem(id) {
  const cell = window.graph.getCell(id)
  window.selection.collection.reset([cell])
  window.scroller.centerElement(cell)
}
</script>
<template>
  <div class="diff-view is-relative">
    <o-modal :active="selectEntryOpen !== null" @close="selectEntryOpen = null">
      <SyncHistory
        :entry="selectEntryOpen"
        @pick="setEntry(selectEntryOpen, $event)"
        @close="selectEntryOpen = null"
      />
    </o-modal>
    <div class="back has-background-white p-3">
      <router-link
        :to="{ name: 'ProviderAccount', params: { providerID: props.providerID } }"
        v-slot="{ href }"
      >
        <o-button tag="a" :href="href" variant="primary" icon-left="arrow-left" size="small">
          Back to account
        </o-button>
      </router-link>
    </div>
    <div class="compare-left has-background-white is-absolute p-3">
      <div class="is-flex is-align-items-center">
        <o-button
          variant="primary"
          icon-left="history"
          class="mr-2"
          @click="selectEntryOpen = 'A'"
        />

        <template v-if="entryA?.date">
          {{ moment(entryA.date).format(format) }}
        </template>
      </div>
    </div>
    <div class="compare-right has-background-white is-absolute p-3">
      <div class="is-flex is-align-items-center">
        <template v-if="entryB?.date">
          {{ moment(entryB.date).format(format) }}
        </template>

        <o-button
          variant="primary"
          icon-left="history"
          class="ml-2"
          @click="selectEntryOpen = 'B'"
        />
      </div>
    </div>
    <DiagramDetails
      :visible="detailsVisible"
      disabled
      hide-style
      hide-project
      @toggle-visibility="rightPanelVisible = !rightPanelVisible"
    />
    <DiagramLeftSidebar
      ref="leftSidebarRef"
      :visible="leftPanelVisible"
      visualize-mode
      display-diff
      :adding-node="''"
      @toggle-visibility="leftPanelVisible = !leftPanelVisible"
      @select="selectItem"
    />
    <div
      id="canvas"
      ref="canvasRef"
      class="is-flex-grow-1 is-relative canvas"
      :class="{ 'canvas--loaded': loaded }"
    />
  </div>
</template>

<style scoped>
.diff-view {
  margin-top: var(--navbar-height);
}
.canvas {
  background-color: #fff;
  height: calc(100vh - var(--navbar-height));
  opacity: 0;
  width: 100vw;
}
.canvas--loaded {
  opacity: 1;
}
.back {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  left: 50%;
  z-index: 20;
  transform: translateX(-50%);
}
.compare-left,
.compare-right {
  top: 0;
  z-index: 2;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
}

.compare-left {
  left: 0;
}

.compare-right {
  right: 0;
}
</style>
