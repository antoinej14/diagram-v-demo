<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { OButton, OLoading, OSwitch, useOruga } from '@oruga-ui/oruga-next'
import { useMixins } from '@/common/mixins'
import { storeToRefs } from 'pinia'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useDiagramStore } from '@/store/diagram'
import readG6Diagram from '@/common/diagram/options/methods/read'

import DiagramDetails from '@/components/diagram/Details.vue'
import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import DiagramToolbar from '@/components/diagram/Toolbar.vue'
import ConfirmationModal from '@/components/modal/Confirmation.vue'

import { useProjectStore } from '@/store/project'

import { useInitDiagram } from '@/components/diagram/hooks/init'
import { useZoom } from '@/components/diagram/hooks/zoom'
import exportData from '@/common/diagram/options/methods/export'
import { useOrganizationMembership } from '@/common/organization-membership.js'
import Diagram3DView from '@/components/diagram/Diagram3DView.vue'
import { useMappingStore } from '@/store/mapping.js'
import { useRoute } from 'vue-router'
import { performLayout, filterNoise } from '@/common/diagram/options/methods/layout.js'
import { generateThumbnail } from '@/common/diagram/utils.js'
import { defaultSettings, useSettings } from '@/components/diagram/hooks/settings.js'
import { useHighlight } from '@/components/diagram/hooks/highlight.js'
import moment from 'moment'
import { COST_TYPES, DIMENSIONS, OPERATORS } from '@/common/enums.js'

const { organizationID } = useOrganizationMembership()
const route = useRoute()
const { setPageTitle, navigate, toast } = useMixins()
const oruga = useOruga()

const props = defineProps({
  providerID: {
    type: [Number, String],
    required: true
  }
})

const loaded = ref(false)
const leftPanelVisible = ref(true)
const rightPanelVisible = ref(true)
const use3dView = ref(false)

const elementsCosts = ref({})

const leftSidebarRef = ref(null)
const canvasRef = ref(null)

const lastMonth = moment().subtract(1, 'month').startOf('month')

const startDate = lastMonth.format('YYYY-MM-DD')
const endDate = lastMonth.endOf('month').format('YYYY-MM-DD')

const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()
const projectStore = useProjectStore()
const mappingStore = useMappingStore()

let account

// Force the tab to be Terraform in infra view
diagramStore.setDetailsTab('terraform')

const { providerAccount, synchronizationDiagram, synchronizationThumbnail } =
  storeToRefs(providerAccountsStore)
const { getGlobalSelectionCount } = storeToRefs(diagramStore)

const detailsVisible = computed(() => getGlobalSelectionCount.value > 0 && rightPanelVisible.value)

const needsLayout = ref(false)
const syncID = ref(null)

onMounted(() => {
  setPageTitle(providerAccount.value?.name)

  document.body.classList.add('no-bg')

  if (props.providerID === 'demo') {
    providerAccountsStore.loadDemoDetails(true).then(generateDiagram)
    return
  }

  diagramStore.loadCompanies().then((companies) => {
    mappingStore.getAllRegions(companies)
  })

  // preload the provider account
  providerAccountsStore.getProviderAccount(organizationID, props.providerID).then((result) => {
    account = result
  })

  providerAccountsStore.getLastSynchronization(organizationID, props.providerID).then((sync) => {
    if (!sync) {
      toast({
        variant: 'warning',
        message: 'No synchronization data for this cloud account.'
      })
      loaded.value = true
    } else {
      providerAccountsStore
        .getSynchronizationThumbnail(organizationID, props.providerID, sync.id)
        .then((thumbnail) => {
          needsLayout.value = !thumbnail
          syncID.value = sync.id

          providerAccountsStore
            .getSynchronizationDiagram(organizationID, props.providerID, sync.id)
            .then(generateDiagram)

          loaded.value = true
        })
    }
  })
})

onBeforeUnmount(() => {
  document.body.classList.remove('no-bg')
})

function selectionChanged({ groups, nodes }) {
  const { hideEdges } = diagramSettings.value

  if (!hideEdges) {
    return
  }

  const items = [...groups, ...nodes]
  const { graph } = window

  for (const item of items) {
    const links = graph.getConnectedLinks(item)
    for (const link of links) {
      link.attr('./display', 'block')
    }
  }
}

const { updateSettings, diagramSettings } = useSettings(null, 'provider-diagram-settings')
const { zoomIn, zoomOut, zoomToFit } = useZoom()
const { initDiagram } = useInitDiagram({
  canvasRef,
  zoomIn,
  zoomOut,
  selectionChanged
})
const { highlight } = useHighlight(loaded, true)

function generateDiagram() {
  const data = JSON.parse(synchronizationDiagram.value)

  initDiagram()

  const { graph, paper } = window

  const exportedData = readG6Diagram(data, graph, paper)
  diagramStore.setData(exportedData)

  window.lockedMode = true

  paper.unfreeze()

  highlight()

  const loadedSettings = JSON.parse(window.localStorage.getItem('provider-diagram-settings'))
  updateSettings({
    ...defaultSettings,
    autosaveDelay: null,
    ...loadedSettings,
    lockedMode: true,
    nodeLabels: true
  })
  window.commandManager.reset()

  if (route.query.view === '3d') {
    use3dView.value = true
  }

  // If the synchronization did not have a thumbnail, we are going to layout, then generate a thumbnail.
  if (!needsLayout.value) {
    loaded.value = true
    leftSidebarRef.value.reloadResources()
    return
  }

  filterNoise(graph)
  performLayout(graph)

  setTimeout(() => {
    generateThumbnail().then((thumbnail) => {
      const cleanData = exportData(graph.toJSON().cells)

      diagramStore.setData(cleanData)

      providerAccountsStore.editSynchronization(organizationID, props.providerID, syncID.value, {
        diagram: JSON.stringify(cleanData),
        thumbnail
      })

      loaded.value = true
      leftSidebarRef.value.reloadResources()
    })
  }, 500)
}

async function createFromInfrastructure() {
  const instance = oruga.modal.open({
    component: ConfirmationModal,
    props: {
      title: 'New project',
      message: 'You are about to create a new project. This will allow you to modify this diagram.',
      no: 'Cancel',
      noIcon: 'cancel',
      yes: 'Create',
      yesIcon: 'plus'
    },
    trapFocus: true
  })

  const result = await instance.promise

  if (result !== true) {
    return
  }

  const name = providerAccount.value.name
  const diagram = JSON.stringify(diagramStore.getData)
  const thumbnail = synchronizationThumbnail.value
  const imported = new Date().toISOString()

  const formData = {
    name,
    notes: `Created from ${name} account.`,
    diagram,
    thumbnail,
    imported
  }

  projectStore.createProject(organizationID, formData).then((res) => {
    const { id } = res.data

    // TODO this help should be handled by the page itself (onMount)
    const val = window.localStorage.getItem('explainCreateFromInfrastructure')
    const explain = val === null || val === 'true'

    navigate('ProjectDesign', {
      params: { id },
      query: { explain }
    })
  })
}

watch(
  () => diagramStore.getSelectedAnything,
  (newEl) => {
    if (!newEl) {
      return
    }

    const parameters = {
      start_date: startDate,
      end_date: endDate,
      cost_type: COST_TYPES.UNBLENDED
    }

    const filterRules = {
      [DIMENSIONS.RESOURCE_ID]: {
        operator: OPERATORS.IS_IN,
        value: [newEl.id]
      }
    }

    providerAccountsStore.getCost(organizationID, account, parameters, filterRules)
  }
)
</script>

<template>
  <div class="diagram-view is-relative">
    <div v-if="loaded" class="back has-background-white p-3">
      <router-link
        :to="{ name: 'ProviderAccount', params: { providerID: props.providerID } }"
        v-slot="{ href }"
      >
        <o-button tag="a" :href="href" variant="primary" icon-left="arrow-left" size="small">
          Back to account
        </o-button>
      </router-link>
    </div>

    <div v-if="loaded" class="use-3d-view has-background-white is-absolute p-3">
      <o-switch v-model="use3dView">Use 3D view</o-switch>
    </div>

    <div v-show="!use3dView" key="not-3d">
      <DiagramDetails
        :visible="detailsVisible"
        disabled
        hide-style
        hide-project
        :costs="elementsCosts"
        @toggle-visibility="rightPanelVisible = !rightPanelVisible"
      />
      <DiagramLeftSidebar
        ref="leftSidebarRef"
        :visible="leftPanelVisible"
        visualize-mode
        :adding-node="''"
        @toggle-visibility="leftPanelVisible = !leftPanelVisible"
      />
      <DiagramToolbar
        visualize-mode
        @zoom-in="zoomIn"
        @zoom-out="zoomOut"
        @reset-zoom="zoomToFit"
        @settings-change="updateSettings"
        @create-from-infrastructure="createFromInfrastructure"
      />
      <div
        id="canvas"
        ref="canvasRef"
        class="is-absolute canvas"
        :class="{ 'canvas--loaded': loaded }"
      />
    </div>

    <Diagram3DView v-if="use3dView" key="is-3d" :provider="providerAccount.provider_name" />

    <o-loading :active="!loaded || diagramStore.layouting" full-page />
  </div>
</template>

<style scoped>
.diagram-view {
  padding-top: var(--navbar-height);
}
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  left: 0;
  width: 100vw;
  height: calc(100vh - var(--navbar-height));
}
.canvas--loaded {
  opacity: 1;
}
.back {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  left: 0;
  z-index: 20;
}
.use-3d-view {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  right: 0;
  z-index: 2;
}
</style>
