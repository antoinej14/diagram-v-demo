<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { storeToRefs } from 'pinia'
import moment from 'moment'
import { useProviderAccountsStore } from '@/store/provider-accounts'
import { useDiagramStore } from '@/store/diagram'
import readG6Diagram from '@/common/diagram/options/methods/read'

import DiagramLeftSidebar from '@/components/diagram/LeftSidebar.vue'
import DiagramDetails from '@/components/diagram/Details.vue'
import SyncHistory from '@/components/modal/SyncHistory.vue'
import { useMixins } from '@/common/mixins'
import { useProviderAccountDiagrams } from '@/components/diagram/hooks/init'
import { OButton, OLoading, OModal } from '@oruga-ui/oruga-next'
import { performLayout } from '@/common/diagram/options/methods/layout.js'
import { anonymous_instance } from '@/api/index'

const { setPageTitle, updateQueryJS } = useMixins()

const props = defineProps({
  providerID: {
    type: [Number, String],
    required: true
  }
})

const leftPanelVisible = ref(true)
const rightPanelVisible = ref(true)
const selectEntryOpen = ref(null)

const canvasesRef = ref({})
const leftSidebarRef = ref(null)

const { initDiagrams, setEntry, entryA, entryB, loading } = useProviderAccountDiagrams(canvasesRef)

const providerAccountsStore = useProviderAccountsStore()
const diagramStore = useDiagramStore()

const { providerAccount } = storeToRefs(providerAccountsStore)
const { getGlobalSelection } = storeToRefs(diagramStore)

const detailsVisible = computed(
  () => getGlobalSelection.value.length > 0 && rightPanelVisible.value
)

watch(
  () => entryA.value.id,
  (a) => {
    updateQueryJS({ a })
    generateDiagrams()
  }
)

watch(
  () => entryB.value.id,
  (b) => {
    updateQueryJS({ b })
    generateDiagrams()
  }
)

onMounted(() => {
  if (props.providerID !== 'demo') {
    initDiagrams()
  } else {
    // TODO create exampleApi.get() ?
    anonymous_instance
      .get('/example-infrastructures/aws.json')
      .then(({ data: { diagram, last_activity_date, thumbnail, history } }) => {
        providerAccountsStore.setSync({
          last_sync_data: diagram,
          last_sync_date: last_activity_date,
          last_sync_thumbnail: thumbnail,
          history: JSON.parse(history)
        })
        initDiagrams()
      })
  }

  window.lockedMode = true
  document.body.classList.add('no-bg')
})

onBeforeUnmount(() => {
  document.body.classList.remove('no-bg')
})

function generateDiagrams() {
  const { graph1, graph2, paper1, paper2, scroller1, scroller2 } = window

  if (!entryA.value || !entryB.value || !graph1 || !graph2) {
    return
  }

  let diagramA = null
  let diagramB = null

  if (entryA.value.diagram) {
    loading.value.canvas1 = true
    diagramA = readG6Diagram(JSON.parse(entryA.value.diagram), graph1, paper1)

    setTimeout(() => {
      if (!entryA.value.didLayout) {
        performLayout(graph1)
        setTimeout(() => {
          scroller1.zoomToFit()
          loading.value.canvas1 = false
        }, 200)
      } else {
        loading.value.canvas1 = false
      }
    }, 500)
  }
  if (entryB.value.diagram) {
    loading.value.canvas2 = true
    diagramB = readG6Diagram(JSON.parse(entryB.value.diagram), graph2, paper2)

    setTimeout(() => {
      if (!entryB.value.didLayout) {
        performLayout(graph2)
        setTimeout(() => {
          scroller2.zoomToFit()
          loading.value.canvas2 = false
        }, 200)
      } else {
        loading.value.canvas2 = false
      }
    }, 500)
  }

  if (diagramA && diagramB) {
    const merged = {
      nodes: [...diagramA.nodes, ...diagramB.nodes],
      groups: [...diagramA.groups, ...diagramB.groups],
      edges: [...diagramA.edges, ...diagramB.edges]
    }

    diagramStore.setData(merged)
    leftSidebarRef.value.reloadResources()
  }
}

diagramStore.clearSelection()
setPageTitle(providerAccount.value.name)
</script>
<template>
  <div class="compare-view is-relative">
    <o-modal :active="selectEntryOpen !== null" @close="selectEntryOpen = null">
      <SyncHistory
        v-if="selectEntryOpen"
        @pick="setEntry(selectEntryOpen, $event)"
        @close="selectEntryOpen = null"
      />
    </o-modal>
    <div class="back has-background-white p-3">
      <router-link
        :to="{ name: 'ProviderAccount', params: { providerID: props.providerID } }"
        v-slot="{ href }"
      >
        <o-button tag="a" :href="href" variant="primary" icon-left="arrow-left" size="small">
          Back to account
        </o-button>
      </router-link>
    </div>
    <div class="compare-left has-background-white is-absolute p-3">
      <div class="is-flex is-align-items-center">
        <o-button
          variant="primary"
          icon-left="history"
          class="mr-2"
          @click="selectEntryOpen = 'A'"
        />
        <template v-if="entryA?.date">
          {{ moment(entryA.date).format('L, HH:mm') }}
        </template>
      </div>
    </div>
    <div class="compare-right has-background-white is-absolute p-3">
      <div class="is-flex is-align-items-center">
        <template v-if="entryB?.date">
          {{ moment(entryB.date).format('L, HH:mm') }}
        </template>
        <o-button
          variant="primary"
          icon-left="history"
          class="ml-2"
          @click="selectEntryOpen = 'B'"
        />
      </div>
    </div>
    <DiagramLeftSidebar
      ref="leftSidebarRef"
      :visible="leftPanelVisible"
      visualize-mode
      :adding-node="''"
      @toggle-visibility="leftPanelVisible = !leftPanelVisible"
    />
    <DiagramDetails
      :visible="detailsVisible"
      disabled
      hide-style
      hide-project
      @toggle-visibility="rightPanelVisible = false"
    />
    <div
      id="canvas1"
      :ref="(el) => (canvasesRef.canvas1 = el)"
      class="canvas"
      :class="{ 'canvas--loaded': !loading.canvas1 }"
    />
    <div
      id="canvas2"
      :ref="(el) => (canvasesRef.canvas2 = el)"
      class="canvas"
      :class="{ 'canvas--loaded': !loading.canvas2 }"
    />
    <o-loading :active="loading.canvas1 || loading.canvas2" full-page>
      Please wait while we are making the comparison&hellip;
    </o-loading>
  </div>
</template>

<style scoped>
.compare-view {
  margin-top: var(--navbar-height);
}
.canvas {
  background-color: #fff;
  height: calc(100vh - var(--navbar-height));
  opacity: 0;
}
.canvas:first-child:after {
  content: '';
  background-color: grey;
  height: 100%;
  position: absolute;
  top: 0;
  right: -1px;
  width: 2px;
  z-index: 2;
  transition: opacity 0.3s ease;
  opacity: 0;
}
.canvas--loaded {
  opacity: 1;
}
.canvas:before {
  content: '';
  position: absolute;
  height: 100%;
  top: 0;
  width: 20px;
  z-index: 20;
}
.canvas {
  background-color: #fff;
  position: absolute;
  top: var(--navbar-height);
  width: 50vw;
  height: calc(100vh - var(--navbar-height));
}
#canvas1 {
  left: 0;
}
#canvas2 {
  right: 0;
}
#canvas1:before {
  background: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.15));
  right: 0;
}
#canvas2:before {
  background: linear-gradient(to left, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.15));
  left: 0;
}
.back {
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
  position: fixed;
  top: var(--navbar-height);
  left: 50%;
  z-index: 20;
  transform: translateX(-50%);
}
.compare-left,
.compare-right {
  top: 0;
  z-index: 2;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  box-shadow: 0 2px 5px lightgray;
}
.compare-left {
  left: 0;
}
.compare-right {
  right: 0;
}
</style>
