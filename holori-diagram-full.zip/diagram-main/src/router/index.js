import { nextTick } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'

import EventBus from '@/common/eventBus'
import { makeTitle } from '@/common/meta'

import { useAccountStore } from '@/store/account'
import { useAppStore } from '@/store/app.js'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'Home',
      component: () => import('../views/HomeView.vue')
    },
    {
      path: '/organizations/:organizationID',
      props: (route) => ({
        organizationID: Number(route.params.organizationID)
      }),
      component: () => import('../views/DashboardView.vue'),
      children: [
        {
          path: 'inventory/diagrams',
          name: 'InventoryDiagramView',
          component: () => import('../views/inventory/InventoryDiagramView.vue'),
          meta: {
            title: 'Inventory Diagram View',
            sidebarVisible: true
          }
        },
        {
          path: 'inventory/diagram/:provider',
          props: true,
          name: 'InventoryProviderDiagramView',
          component: () => import('../views/inventory/InventoryProviderDiagramView.vue'),
          meta: {
            title: 'Provider Diagram',
            sidebarVisible: false
          }
        },
        {
          path: 'compliance',
          name: 'InventoryCompliance',
          component: () => import('../views/inventory/ComplianceView.vue'),
          meta: {
            title: 'Compliance Dashboard',
            sidebarVisible: true
          }
        },
        {
          path: 'projects/new/:type?/:template?',
          name: 'NewProject',
          component: () => import('../views/project/NewProjectView.vue'),
          props: true,
          meta: {
            title: 'New Project',
            sidebarVisible: true
          }
        },
        {
          path: 'project/compare/:left/:right',
          name: 'ProjectCompare',
          props: (route) => ({
            left: Number(route.params.left),
            right: Number(route.params.right)
          }),
          component: () => import('../views/project/ProjectCompareView.vue'),
          meta: {
            title: 'Compare projects',
            hideSidebar: true
          }
        },
        {
          path: 'project/diff/:left/:right',
          name: 'ProjectDiff',
          props: (route) => ({
            left: Number(route.params.left),
            right: Number(route.params.right)
          }),
          component: () => import('../views/project/ProjectDiffView.vue'),
          meta: {
            title: 'Diff projects',
            hideSidebar: true
          }
        },
        {
          path: 'project/:id',
          component: () => import('../views/project/ProjectView.vue'),
          props: (route) => ({
            id: Number(route.params.id)
          }),
          children: [
            {
              path: '',
              name: 'ProjectDesign',
              component: () => import('../components/diagram/Diagram.vue'),
              meta: {
                autoTitle: true
              }
            },
            {
              path: 'export',
              name: 'ProjectExport',
              component: () => import('../components/diagram/export/ExportDocumentation.vue'),
              props: true,
              meta: {
                title: 'Export',
                hideSidebar: true
              }
            }
          ]
        },
        {
          path: 'projects',
          name: 'ProjectsOverview',
          component: () => import('../views/project/ProjectsView.vue'),
          meta: {
            title: 'Projects',
            sidebarVisible: true
          }
        },
        {
          path: 'provider/:providerID',
          component: () => import('../views/provider-account/ProviderAccountView.vue'),
          props: (route) => ({
            providerID:
              route.params.providerID === 'demo' ? 'demo' : Number(route.params.providerID)
          }),
          meta: {
            sidebarVisible: true
          },
          children: [
            {
              path: '',
              name: 'ProviderAccount',
              component: () => import('../views/provider-account/DetailsView.vue')
            },
            {
              path: 'visualize',
              name: 'ProviderAccountVisualize',
              component: () => import('../views/provider-account/ProviderAccountVisualizeView.vue'),
              meta: {
                sidebarVisible: false
              }
            },
            {
              path: 'compare',
              name: 'ProviderAccountCompare',
              component: () => import('../views/provider-account/ProviderAccountCompareView.vue'),
              meta: {
                sidebarVisible: false
              }
            },
            {
              path: 'diff',
              name: 'ProviderAccountDiff',
              component: () => import('../views/provider-account/ProviderAccountDiffView.vue'),
              meta: {
                sidebarVisible: false
              }
            },
            {
              path: 'export',
              name: 'ProviderAccountExport',
              component: () => import('../views/provider-account/ProviderAccountExport.vue'),
              meta: {
                sidebarVisible: false
              }
            }
          ]
        }
      ]
    },
    {
      path: '/not-found',
      name: 'NotFound',
      meta: {
        title: 'Oops!'
      },
      component: () => import('../views/NotFoundView.vue')
    },
    {
      path: '/:pathMatch(.*)*', // catch any unknown routes
      meta: {
        title: 'Oops!'
      },
      component: () => import('../views/NotFoundView.vue')
    }
  ]
})

const loggedInRoutes = [
  'Home',
  'Onboarding',
  'InventoryDiagramView',
  'Projects',
  'Project',
  'ProjectDesign',
  'ProjectExport',
  'Dashboard',
  'NewProject',
  'ProviderAccount',
  'ProviderAccountVisualize',
  'ProviderAccountCompare',
  'ProviderAccountDiff',
  'ProjectDiffVisualize',
  'ProjectDiffCompare',
  'ProjectDiffDiff'
]

export function abortAllRequests() {
  window.cancelledRequests = []

  for (const url in window.abortControllers) {
    window.abortControllers[url].abort()
    delete window.abortControllers[url]
    window.cancelledRequests.push(url)
  }
}

router.beforeEach(async (to, from, next) => {
  const appStore = useAppStore()
  appStore.resetLoading()

  if (to.path !== from.path) {
    EventBus.dispatch('setPageTitle', '')
  }

  abortAllRequests()

  const logInRequired = loggedInRoutes.includes(to.name)

  const accountStore = useAccountStore()

  let isAuthenticated = accountStore.isLoggedIn

  if (!logInRequired) {
    return next()
  }

  if (isAuthenticated && (to.name === 'Login' || to.name === 'ConnectSSO')) {
    return next({
      name: 'ProjectsOverview',
      query: from.query
    })
  }

  if (to.name === 'Authorize') {
    // SSO uses a cloud provider auth page to get authorization code
    // then once back to Authorize page, we get a token and
    // let redirect to the destination hold in the authorization state
    return next()
  } else if (logInRequired && !isAuthenticated) {
    next({
      name: to.fullPath.endsWith('invitation') ? 'Register' : 'Login',
      query: {
        ...to.query,
        // remember from where we logged out in the url
        redirect:
          to.fullPath !== '/' && loggedInRoutes.includes(to.name) ? to.fullPath.substring(1) : ''
      }
    })
  } else {
    // all is in order, continue
    next()
  }
})

router.afterEach((to) => {
  const { autoTitle, title } = to.meta
  if (!autoTitle) {
    nextTick(() => {
      let finalTitle = title || 'Home'
      const vars = finalTitle.match(/\$([A-Za-z]+)/g)
      if (Array.isArray(vars)) {
        for (const v of vars) {
          const varName = v.replace('$', '')
          finalTitle = finalTitle.replace(v, to.params[varName])
        }
      }
      document.title = makeTitle(finalTitle)
    })
  }
})

export default router
