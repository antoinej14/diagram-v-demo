import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
  server: {
    port: 5174,
    strictPort: true,
    proxy: {
      '^/api/main-server': {
        target: 'http://127.0.0.1:8088',
        rewrite: (path) => path.replace('/api/main-server', ''),
        // --
        secure: false,
        changeOrigin: true,
        logLevel: 'debug'
      }
    }
  },
  plugins: [vue()],
  base: '/diagram/',
  resolve: {
    alias: [
      {
        find: '@',
        replacement: fileURLToPath(new URL('./src', import.meta.url))
      }
    ]
  },
  build: {
    sourcemap: true,
    target: 'ES2022'
  },
  esbuild: {
    drop: ['console', 'debugger']
  }
})
