# Diagram frontend

[![App update on release](https://github.com/TheDevCompany/diagram/actions/workflows/app-update.yml/badge.svg)](https://github.com/TheDevCompany/diagram/actions/workflows/app-update.yml)
[![Dev update on main push](https://github.com/TheDevCompany/diagram/actions/workflows/dev-update.yml/badge.svg)](https://github.com/TheDevCompany/diagram/actions/workflows/dev-update.yml)

The repository for the diagram separated from our main frontend.

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Customize configuration

See [Vite Configuration Reference](https://vitejs.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
